/*
 * hwcfg.h
 *
 *  Created on: Jun 8, 2015
 *      Author: khgoh
 */

#ifndef INCLUDE_HWCFG_H_
#define INCLUDE_HWCFG_H_





#endif /* INCLUDE_HWCFG_H_ */
