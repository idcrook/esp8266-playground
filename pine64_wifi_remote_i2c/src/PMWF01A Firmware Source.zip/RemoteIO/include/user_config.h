#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

/*
 * Set WiFi Mode, STATION_MODE,SOFTAP_MODE and STATIONAP_MODE
 */
#define USE_WIFI_MODE		STATIONAP_MODE

//#define FORCE_DEF_CFG

//#define OFFICE_WIFI
#define PRODUCT_WIFI

#ifdef PRODUCT_WIFI
#define WIFI_CLIENTSSID		"wifitesting"
#define WIFI_CLIENTPASSWORD	"123456789"
#define TCPSERVERIP		"192.168.0.100"

#elif defined OFFICE_WIFI
#define WIFI_CLIENTSSID		"Myggns_WiFi"
#define WIFI_CLIENTPASSWORD	"ggns54321"
#define TCPSERVERIP		"192.168.0.111"

#else
#define WIFI_CLIENTSSID		"Goh_AP"
#define WIFI_CLIENTPASSWORD	"ebdtronics.my"
#define TCPSERVERIP		"192.168.0.90"
#endif

//#define DEBUGMODE

//-------------------------------------------------------
//     Firmware Version
//-------------------------------------------------------
#define FWV_YY           0x16 //0x15
#define FWV_MM           0x05 //0x11
#define FWV_DD           0x12 //0x25
#define FWV_REV			 0x01

#define FWID			0x1A01

#endif
