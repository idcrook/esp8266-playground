#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_interface.h"
#include "uart.h"
#include "board.h"
#include "user_config.h"
#include "dPrint.h"


void ICACHE_FLASH_ATTR WifiUpDownCB(uint8_t state)
{
	static uint8_t firsttime=1;

	if (state)
	{
		dPrintText("Wifi Link Connected\n");
	}
	else
	{
		dPrintText("Wifi Link Down.....\n");
	}
}

void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
	system_phy_set_rfoption(1);
}

void ICACHE_FLASH_ATTR SystemReadyCB(void)
{
	wifictrl_init(&WifiUpDownCB);
	SLink_init();
	dPrintText("Wifi Init done, System Ready!\n");
}


void ICACHE_FLASH_ATTR user_init(void)
{
	struct station_config stcfg;

	os_delay_us(200000);
	Board_Init(); //must call first before other.
	//Once system bottom layer is ready, it will call
	//SystemReadyCB to setup rest of the application module.
	system_init_done_cb(&SystemReadyCB);
	wifi_set_opmode(STATION_MODE); //station mode
	wifi_station_set_auto_connect(1);
	dPrintText("Board Init Done!\n");
}
