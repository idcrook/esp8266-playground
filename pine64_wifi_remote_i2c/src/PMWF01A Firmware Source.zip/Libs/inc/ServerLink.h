/*
 * ServerLink.h
 *
 *  Created on: Apr 21, 2015
 *      Author: khgoh
 */

#ifndef INCLUDE_SERVERLINK_H_
#define INCLUDE_SERVERLINK_H_
#include "ets_sys.h"
#include "osapi.h"

void ICACHE_FLASH_ATTR SLink_init(void);
void ICACHE_FLASH_ATTR SLink_stop(void);
uint16_t ICACHE_FLASH_ATTR SLink_PushLinkDirect(uint8_t *pPkt, uint16_t size);
uint16_t ICACHE_FLASH_ATTR SLink_IsLinkUp(void);
#endif /* INCLUDE_SERVERLINK_H_ */
