/*
 * debugPrint.h
 *
 *  Created on: Apr 7, 2015
 *      Author: khgoh
 */

#ifndef INCLUDE_DPRINT_H_
#define INCLUDE_DPRINT_H_
#include "user_interface.h"
#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_config.h"

#ifdef DEBUGMODE
#define dPrintText(fmt,...) do {\
		ets_uart_printf("|");\
		ets_uart_printf((fmt),##__VA_ARGS__);\
	}while(0)
#define dPrintContinue(fmt,...) do {\
		ets_uart_printf((fmt),##__VA_ARGS__);\
	}while(0)
#define dPrintByte(pByte,size) do{\
	int c;\
	ets_uart_printf("|");\
	for(c=0;c<(size);c++) ets_uart_printf("%02x",(pByte)[c]);\
	}while(0)
#else
#define dPrintText(a, ... )
#define dPrintContinue(a, ... )
#define dPrintByte(pByte,size)
#endif

#endif /* INCLUDE_DEBUGPRINT_H_ */
