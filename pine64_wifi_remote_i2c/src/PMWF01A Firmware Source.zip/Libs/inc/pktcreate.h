/*
 * pktcreate.h
 *
 *  Created on: Apr 20, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_PKTCREATE_H_
#define SHAREINCLUDE_PKTCREATE_H_
#include "ets_sys.h"
#include "osapi.h"

/*
 * Packet format
 * STX(1byte), Len(1byte), Cnt(1byte), MacAddr(6byte), Result(1byte), Cmd(1byte),Data(Variable), CRC(2byte)
 * Index Data
 * 0	STX
 * 1	Len
 * 2	Cnt
 * 3	Mac
 * 9	Result
 * 11 	CMD/Data
 * Len-2 CRC(L)
 * Len-1 CRC(H)
 */
#define STXBYTE			(0x02)

#define PKTINDEX_LEN		(1)
#define PKTINDEX_Cnt		(2)
#define PKTINDEX_MAC		(3)
#define PKTINDEX_RSSI		(9)
#define PKTINDEX_Result		(10)
#define PKTINDEX_DATA		(11)

//extra byte other then the CMD/data
// Which include, STR(1B), Len(1B), Cnt(1B), Mac(6B),Result(1B), RSSI(1B)
#define TXPKT_ExtraPayloadByte (13)

/*
 * Call to request memory to create the reply or push packet
 * Will return the pointer to memory to keep the payload D0..Dn.
 * datasize -> data size to send, D0 to Dn (Excluding Cmd byte)
 * return true if memory is ready
 */
uint8_t ICACHE_FLASH_ATTR pktc_request(uint8_t **pMemorySpace,uint16_t datasize);
/*
 * Call the calculate and create the packet for sending.
 */
void ICACHE_FLASH_ATTR pktc_create(uint8_t result,uint8_t Cmd);
/*
 * Call after pktc_create to get the created packet for sending out.
 */
uint8_t ICACHE_FLASH_ATTR *pktc_Get(uint16_t *pPktSize);
/*
 * Call after finish sending the packet. no more needing the data.
 */
void ICACHE_FLASH_ATTR pktc_done(void);

/*
 * 			Require to create a return packet
 * 							|
 *          ## Call pktc_request to get the memory space to kept the tx data
 * 							|
 * 			Fill in the CMD D0..Dn into the memory space
 * 							|
 * 			## Call create to finish the packet creating process
 * 							|
 * 				## Call pktc_Get to get the packet pointer
 * 							|
 * 				Send out the packet
 * 							|
 * 				## Call pktc_done to free the memory
 *
 */



/*
 * Do a CRC check and decrypt the Rx data if it is encrypted.
 * return true if the data is ready for process.
 * will also return the pointer to the CMD byte in the packet.
 *   CMD SCMD D0...Dn
 */
uint8_t ICACHE_FLASH_ATTR pktc_rxPecket(uint8_t *pData, uint8_t **pResult, uint8_t **pCmdData, uint16_t *pSize);

#endif /* SHAREINCLUDE_PKTCREATE_H_ */
