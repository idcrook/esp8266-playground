/*
 * tcpCmdMgt.h
 *
 *  Created on: Mar 8, 2016
 *      Author: khgoh
 */

#ifndef INC_TCPCMDMGT_H_
#define INC_TCPCMDMGT_H_

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"
#include "pktcreate.h"
#include "tcpCommandList.h"





//direct reply during the data received callback
#define TcpReplyWithACK() do{\
		uint8_t *ptmp;\
		if (pktc_request(&ptmp,0)) {\
			tcpCmdMgt_SendReply_SendNow(TCP_ACK);\
		}\
	}while(0)

#define TcpReplyWithNACK() do{\
		uint8_t *ptmp;\
		if (pktc_request(&ptmp,0)) {\
			tcpCmdMgt_SendReply_SendNow(TCP_NACK);\
		}\
	}while(0)

void tcpCmdMgt_init(void);

/*
 * Callback function when connected to a remote connection
 */
void ICACHE_FLASH_ATTR tcpCmdMgt_Connected(void *pTcpConn);
/*
 * Callback function when received a tcp packet
 */
void ICACHE_FLASH_ATTR tcpCmdMgt_Rx(void *pTcpConn,char *pdata, unsigned short len);

/*
 * Call to send the data.
 */
uint8_t ICACHE_FLASH_ATTR tcpCmdMgt_SendReply_SendNow(tcpAckState tcpAckResult);
#endif /* INC_TCPCMDMGT_H_ */
