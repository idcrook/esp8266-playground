/*
 * tcpCommandList.h
 *
 *  Created on: May 16, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_TCPCOMMANDLIST_H_
#define SHAREINCLUDE_TCPCOMMANDLIST_H_

typedef enum {
	TCP_ACK=0x80,	//Return result Ack
	TCP_NACK=0x81,	//Return result NACK
	TCP_ACKRT2=0x90,	//Client Push Command to Server
}tcpAckState;

/*
 * TCP Command List
 */
//System Command

#define Cmd01_Nop					(0x01)
#define Cmd02_HWINFO				(0x02)
#define Cmd03_HWSTATUS				(0x03)

#define Cmd11_I2CPOLL				(0x11)
//	Data: Addr
#define Cmd12_I2CREAD				(0x12)
//	Data: Addr, Location, Len
#define Cmd13_I2CWRITE				(0x13)
//	Data: Addr, Location, Len, Data
#define Cmd14_I2CENABLE				(0x14) //i2cstart
#define Cmd15_I2cDisable			(0x15)
#define Cmd16_I2cIntr				(0x16)

#define Cmd20_PWMENABLE				(0x20)
#define Cmd21_PWMCFG				(0x21)

#define Cmd30_SET_IO				(0x30)
#define Cmd31_RELAY					(0x31)
#define Cmd32_CFG_PORT				(0x32)
#define Cmd33_PUSH_IP_STATUS 		(0x33)
// Data: PortSetting

#define Cmd40_SPIENABLE				(0x40)
#define Cmd41_SPICFG				(0x41)
#define Cmd42_SPIRXTX				(0x42)


typedef enum {
	cmd_nop=Cmd01_Nop,
	cmd_i2cpoll=Cmd11_I2CPOLL,
	cmd_i2cread=Cmd12_I2CREAD,
	cmd_i2cwrite=Cmd13_I2CWRITE,
	cmd_i2cenable=Cmd14_I2CENABLE,
	cmd_i2cdisable=Cmd15_I2cDisable,

	cmd_pwmenable=Cmd20_PWMENABLE,
	cmd_pwmcfg=Cmd21_PWMCFG,

	cmd_setio=Cmd30_SET_IO,
	cmd_relay=Cmd31_RELAY,
	cmd_cfgport=Cmd32_CFG_PORT,

	cmd_spienable=Cmd40_SPIENABLE,
	cmd_spicfg=Cmd41_SPICFG,
	cmd_spirxtx=Cmd42_SPIRXTX,

}tcpCmd;

#endif /* SHAREINCLUDE_TCPCOMMANDLIST_H_ */
