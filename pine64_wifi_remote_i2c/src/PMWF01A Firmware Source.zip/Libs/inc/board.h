/*
 * board.h
 *
 *  Created on: Apr 24, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_BOARD_H_
#define SHAREINCLUDE_BOARD_H_
#include "os_type.h"
#include "user_config.h"
#include "gpio16.h"
#include "ezgpio.h"

#define RELAY_IO_NUM		16
#define RELAY_IO_FUNC 		FUNC_GPIO0

#define LED_IO_NUM			0
/*
 * Bit0 : GPIO5/nINT
 * Bit1 : GPIO2/SDA
 * Bit2 : GPIO14/SCL
 * Bit3 : GPIO15
 * Bit4 : GPIO13
 * Bit5 : GPIO12
 */

#define GPIO_nINT		5
#define GPIO_SDA		2
#define GPIO_SCL		14

//SPI Port GPIO Pin Number
//SPI Clock is share with I2C SCL
#define GPIO_SPISCK		14
#define GPIO_SPIMISO	12
#define GPIO_SPIMOSI	13
#define GPIO_SPICS		15
#define GPIO_SW			4

/*
 * LED Output require to include ezgpio.h
 */
#define LED_CONFIG() do{\
		EzGpio_pinMode(LED_IO_NUM,EZGPIO_NOPULL,EZGPIO_OUTPUT);\
		GPIO_OUTPUT_SET(LED_IO_NUM,1);\
	}while(0)
#define LED_ON() do{\
		GPIO_OUTPUT_SET(LED_IO_NUM,0);\
	}while(0)
#define LED_OFF() do{\
		GPIO_OUTPUT_SET(LED_IO_NUM,1);\
	}while(0)

/*
 * Relay Output Configuration, require gpio16.h
 */
#define RELAY_CONFIG() do{gpio16_output_conf();}while(0)
#define RELAY_ON() do{gpio16_output_set(1);}while(0)
#define RELAY_OFF() do{gpio16_output_set(0);}while(0)


/*
 * Reset output pin, require to include ezgpio.h
 */

#define UART0_GPIO_Config() do{\
	GPIO_OUTPUT_SET(1,1);\
	EzGpio_pinMode(1,EZGPIO_PULLUP,EZGPIO_OUTPUT);\
	}while(0)

typedef enum {
	LED_IDLE,
	LED_REBOOTING,
	LED_LINK_DOWN,
	LED_WIFI_UP,
	LED_SERVER_UP,
	LED_SERVER_DOWN,
	LED_CTRL_CFGMODE,
}ledmode_t;

/*
 * Init the board Mainly on the hardware side
 * Call this first before any other functions.
 */
void ICACHE_FLASH_ATTR Board_Init(void);

/*
 * Call to restart the board.
 */
void ICACHE_FLASH_ATTR Board_SystemRestart(void);

/*
 * Call to change the LED indication display mode
 */
void ICACHE_FLASH_ATTR Board_LedControl(ledmode_t mode);
/*
 * Call to blink Off the LED Once
 */
void ICACHE_FLASH_ATTR Board_LedBlinkOff(void);

#define BlinkSendingData() do{Board_LedBlinkOff();}while(0)

/*
 * if 0=set to output port, 1=set to input port
 */
uint8_t ICACHE_FLASH_ATTR Board_ConfigGPIO(uint8_t mask,uint8_t status,uint8_t currCfgStatus)
;
/*
 * if there is changes, it will return true.
 */
uint8_t ICACHE_FLASH_ATTR Board_DetectInputPortChanges(uint8_t *mask, uint8_t *currPortStatus);
#endif /* SHAREINCLUDE_BOARD_H_ */
