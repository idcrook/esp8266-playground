/*
 * tcpdriver.h
 *
 *  Created on: Apr 2, 2015
 *      Author: khgoh
 */

#ifndef INCLUDE_TCPDRIVER_H_
#define INCLUDE_TCPDRIVER_H_
#include "os_type.h"
#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"
#include "espconn.h"

struct tcpconnstruct;
typedef struct tcpconnstruct TcpConn_t;

//keep the type of connection
typedef struct {
	uint8_t enabled;
	uint8_t connToRemote;


	struct espconn espconn;
	esp_tcp ConnTcp;
	void (*cbConnected)(void *pTcpConn);
	void (*cbDisconnected)(void *pTcpConn);
	void (*cbDataReceived)(void *pTcpConn, char *pdata, unsigned short len);
	void (*cbWriteFinish)(void *pTcpConn);
	void (*cbReconnect)(void *pTcpConn);
	void (*cbKeepAlive)(void *pTcpConn);
}TcpLinkProp_t;


//keep the property of each connection
struct tcpconnstruct{
	struct espconn *pespconn;
	//uint8_t tcpLinkIndex; //indicated the index of the TcpLinkProp_t.
	TcpLinkProp_t *pLinkRef; //link back to TcpLinkProp_t structure
	uint8_t linkUp;
	uint8_t *pSendBuf; //keeping the sending data
	uint16_t sendBufLen; //size of data in the buffer.
	uint8_t *pSendingBuf; //keeping data that current sending.
	uint16_t sendingBufLen; //byte size of the buf.
	uint8_t sendBusy;	//indicated not finish sending the data yet.
	//uint32_t keepAlive_timestamp;
	//uint32_t retryConn_timestamp;
	uint8_t retryCount;
	uint8_t retryPause;
	int remote_port;
	int local_port;
};

/*
 * Call once during system startup.
 */
void ICACHE_FLASH_ATTR tcpdriver_init(uint16_t extraDelay);

/*
 * call to setup a new connection to remote host
 * On success, will return the pLinkRef  to the connection
 * else will will return 0.
 *
 * After setup, caller must register their own call back.
 */
TcpLinkProp_t ICACHE_FLASH_ATTR *tcpdriver_ConnRemoteSetup(uint32_t Remote_IP, int port);

/*
 * Stop the connection
 */
void  ICACHE_FLASH_ATTR tcpdriver_ConnStop(TcpLinkProp_t *pLinkRef);
/*
 * Stop all tcp connection
 */
void ICACHE_FLASH_ATTR tcpdriver_ConnStop_All(void);
/*
 * Start the connection
 */
void  ICACHE_FLASH_ATTR tcpdriver_ConnStart(TcpLinkProp_t *pLinkRef);
/*
 * Just disconnect the link, the link is still enable.
 */
void ICACHE_FLASH_ATTR tcpdriver_Disconnect(TcpLinkProp_t * pLinkRef);
/*
 * Get the LinkUp state.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_isLinkUp(TcpLinkProp_t *pLinkRef);
/*
 * Register Reconnection once detected link is diconnected.
 * The tcpdriver will do the auto reconnect if it is at client connect to a server.
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_Reconnect(TcpLinkProp_t *pLinkRef, void (*cb)(void *pTcpConn));
/*
 * Register write finish callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_write_finish(TcpLinkProp_t *pLinkRef, void (*cb)(void *pTcpConn));
/*
 * Register data received callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_receive(TcpLinkProp_t *pLinkRef, void (*cb)(void *pTcpConn,char *pdata, unsigned short len));
/*
 * Register link connected callback
*/
void ICACHE_FLASH_ATTR tcpdriver_RegCB_connected(TcpLinkProp_t *pLinkRef,void (*cb)(void *pTcpConn));
/*
 * Register link disconnected callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_disconnected(TcpLinkProp_t *pLinkRef,void (*cb)(void *pTcpConn));
/*
 * Call to send the data out to destination refer by the TcpConn.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendByConn(TcpConn_t *pTcpConn,uint8_t *pdata, uint16_t len);

/*
 * Send message refer by pLinkRef.
 * If the link is Server link, it will send the message out to all the currently connected
 * client.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendByLink(TcpLinkProp_t *pLinkRef,uint8_t *pdata, uint16_t len);
/*
 * Call to request connect now all the connection
 */
void ICACHE_FLASH_ATTR tcpdriver_connectnow(void);

#endif /* INCLUDE_TCPDRIVER_H_ */
