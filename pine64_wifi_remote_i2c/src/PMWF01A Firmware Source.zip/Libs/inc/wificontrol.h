/*
 * wificontrol.h
 *
 *  Created on: Apr 4, 2015
 *      Author: khgoh
 */

#ifndef INCLUDE_WIFICONTROL_H_
#define INCLUDE_WIFICONTROL_H_
#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_interface.h"

extern Event_StaMode_Connected_t connectedAPInfo;
extern Event_StaMode_Got_IP_t connectedIPInfo;

/*
 * Call Once during startup, register Wifi Up/Down Status Change callback
 */
void ICACHE_FLASH_ATTR wifictrl_init(void (*LinkUpDownCallback) (uint8_t s));

/*
 * Call to configure the wifi hardware
 * Must provide the require setting to setup the wifi
 * set not use variable to Null
 */
void ICACHE_FLASH_ATTR wifictrl_StartSta(struct station_config *pSTCfg);

/*
 * return = 1, wifi link is up
 */
uint8_t ICACHE_FLASH_ATTR wifictrl_IsLinkUp(void);
#endif /* INCLUDE_WIFICONTROL_H_ */
