
#ifndef __CRC_UPDATE_H__
#define __CRC_UPDATE_H__
#include "ets_sys.h"
#include "osapi.h"
#include "user_config.h"

/*
 * Support 3 type of CRC calculation, CRC CCITT, CRC16 and CRC XModem (default)
 */

#if defined CRC_CCITT
#define crc_update(crc,data) crc_ccitt_update(crc,data)
uint16_t  ICACHE_FLASH_ATTR crc_ccitt_update (uint16_t crc, uint8_t data);


#elif defined CRC16
#define crc_update(crc,data) crc16_update(crc,data)
uint16_t ICACHE_FLASH_ATTR crc16_update(uint16_t crc, uint8_t a);

#else
#define crc_update(crc,data) crc_xmodem_update(crc,data)
uint16_t ICACHE_FLASH_ATTR crc_xmodem_update (uint16_t crc, uint8_t data);
#endif

/*
 * Cal the crc and put it at the end of the packet.
 * size if the total data size including the CRC byte.
 */
void ICACHE_FLASH_ATTR CalCRC(uint8_t *pData, uint16_t size);
/*
 * Cal the crc and put it at pcrc.
 * size if the total data size Not including CRC byte.
 */
void ICACHE_FLASH_ATTR CalCRC_Location(uint8_t *pData, uint16_t size, uint8_t *pcrc);

/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
uint16_t ICACHE_FLASH_ATTR CheckCRC(uint8_t *data, uint16_t size);
/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
uint16_t ICACHE_FLASH_ATTR CheckCRC_Location(uint8_t *data, uint16_t size, uint8_t *pcrc);

#endif
