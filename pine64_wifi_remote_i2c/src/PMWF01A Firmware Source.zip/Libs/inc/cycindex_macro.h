#ifndef __CYCINDEX_MACRO_H__
#define __CYCINDEX_MACRO_H__

//#define NOFREERTOS

//#ifndef NOFREERTOS
//#   include "FreeRTOS.h"
//#   include "task.h"
//#else
#include "ets_sys.h"
#include "osapi.h"
//#include "inttypes.h"
//typedef  uint32_t uint32_t;
//#endif
//This micro provide a very simple cycle index. Index size can be
//2, 4, 8, 16, 32, 64, 128 ,256, ... up to 65536 bytes.
//The App. will create the actual structure require to keep the data
//the cycindex macro will help to provide the index management to 
//create the cycle buffer from the App. structure.



typedef struct 
{
  //controller Structure.
  volatile uint32_t  TailIndex;
  volatile uint32_t  HeadIndex;
  uint32_t Index_Mask;
} cycindex_t;

typedef struct 
{
  //controller Structure.
  uint32_t  TailIndex;
  uint32_t  HeadIndex;
  uint32_t Index_Mask;
} cycindex_nor_t;


//Concept
//New data will always be place to the TailIndex. When requesting data 
// from the buffer, the data will always retrive from the TailIndex.
// if TailIndex == TailIndex, no data in the buffer.
// if (TailIndex+ The NextIndex) == TailIndex, the buffer is full.

//**********************************************************************
//  buffer handling macro
  
#define CYCINDEX_NEXTINDEX(I,Index_Mask) ((I+1) & Index_Mask)

//reset the Rx cycbuf structure.
//Need to call during init setup.
#define CYCINDEX_RST_INDEXCTRL(CycBuf_PTR,Buf_Size) do{\
    (CycBuf_PTR)->TailIndex=0;\
    (CycBuf_PTR)->HeadIndex=0;\
    (CycBuf_PTR)->Index_Mask=(uint16_t)(Buf_Size-1);\
  }while(0)

//Flush the Rx buffer.
#define CYCINDEX_FLUSH(CYCINDEX_PTR) do{\
    (CYCINDEX_PTR)->TailIndex=0;\
    (CYCINDEX_PTR)->HeadIndex=0;\
  }while(0)
  
//Return the current data byte from Rx buffer (point by the TailIndex+1)
//need to make sure there is data before requesting it.
#define CYCINDEX_GETRETURNINDEX(CYCINDEX_PTR) (\
      ((CYCINDEX_PTR)->TailIndex=CYCINDEX_NEXTINDEX((CYCINDEX_PTR)->TailIndex,(CYCINDEX_PTR)->Index_Mask))\
  )

//Get the tail index  without change the ptr
#define CYCINDEX_GETNEXT_RETURNINDEX(CYCINDEX_PTR) (\
      (CYCINDEX_NEXTINDEX((CYCINDEX_PTR)->TailIndex,(CYCINDEX_PTR)->Index_Mask))\
  )
//return number of panding index.
#define CYCINDEX_CNTINDEX(CYCINDEX_PTR) (\
    ((CYCINDEX_PTR)->TailIndex>(CYCINDEX_PTR)->HeadIndex)?\
      (CYCINDEX_PTR)->Index_Mask-(CYCINDEX_PTR)->TailIndex+(CYCINDEX_PTR)->HeadIndex+1:\
      (CYCINDEX_PTR)->HeadIndex-(CYCINDEX_PTR)->TailIndex\
    )

//Get the index that going to keep on the next Keepindex without change the ptr
#define CYCINDEX_GETNEXT_KEEPINDEX(CYCINDEX_PTR) (\
      (CYCINDEX_NEXTINDEX((CYCINDEX_PTR)->HeadIndex,(CYCINDEX_PTR)->Index_Mask))\
  )
  
///Get the index that going to keep on the next Keepindex and change the index at the same time.
#define CYCINDEX_KEEPINDEX(CYCINDEX_PTR) (\
      ((CYCINDEX_PTR)->HeadIndex=CYCINDEX_NEXTINDEX((CYCINDEX_PTR)->HeadIndex,(CYCINDEX_PTR)->Index_Mask))\
  )


//Check if the Rx Buffer is empty, if yes will return true.
#define CYCINDEX_ISEMPTY(CYCINDEX_PTR) (\
    ((CYCINDEX_PTR)->HeadIndex==(CYCINDEX_PTR)->TailIndex)?1:0\
  )

//Check if the Rx Buffer is full, if yes will return true.
#define CYCINDEX_ISFULL(CYCINDEX_PTR) (\
    (CYCINDEX_NEXTINDEX((CYCINDEX_PTR)->HeadIndex,(CYCINDEX_PTR)->Index_Mask)==(CYCINDEX_PTR)->TailIndex)?1:0\
  )

//return number of space let in the buffer
#define CYCINDEX_SPACELEFT(CYCINDEX_PTR) (\
			((CYCINDEX_PTR)->HeadIndex>=(CYCINDEX_PTR)->TailIndex)?\
	  	((CYCINDEX_PTR)->Index_Mask-(CYCINDEX_PTR)->HeadIndex+(CYCINDEX_PTR)->TailIndex):\
	  	((CYCINDEX_PTR)->TailIndex-(CYCINDEX_PTR)->HeadIndex-1) \
	  )


//-----------------------------------------------------------------------------------------
//wrapper to get and update to the next Return index.
//return true if cycbuf is not empty.

inline uint16_t GetReturnUpdateNextIndex(cycindex_nor_t *ctrl,uint32_t *Index){
  uint16_t result=0;
  
//#ifndef NOFREERTOS
//  vTaskSuspendAll();
//#endif
  if (!CYCINDEX_ISEMPTY(ctrl)) {
    (*Index)=CYCINDEX_GETRETURNINDEX(ctrl);
    result=1;
  }
//#ifndef NOFREERTOS
//  xTaskResumeAll();
///#endif
  return(result);
}  
//wrapper to get and update to the next Keep index.
//return true if cycbuf is not full.
inline uint16_t GetKeepUpdateNextIndex(cycindex_nor_t *ctrl,uint32_t *Index){
  uint16_t result=0;
  
//#ifndef NOFREERTOS
//  vTaskSuspendAll();
//#endif
  if (!CYCINDEX_ISFULL(ctrl)) {
    (*Index)=CYCINDEX_KEEPINDEX(ctrl);
    result=1;
  }
//#ifndef NOFREERTOS
//  xTaskResumeAll();
//#endif
  return(result);
}  


#endif




