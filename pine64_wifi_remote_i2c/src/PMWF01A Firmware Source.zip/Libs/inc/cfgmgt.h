/*
 * cfgmgt.h
 *
 *  Created on: Apr 11, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_CFGMGT_H_
#define SHAREINCLUDE_CFGMGT_H_
#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"
#include "mem.h"
#include "board.h"
#include "uart.h"


/*
 * make structure in multiple of 4byte.
 */
typedef struct {
	struct ip_addr 	serverIP;  		//4byte
	uint8_t 		i2cenable; 		//1byte
	uint8_t			pwnenable; 		//1byte
	uint8_t 		gpioCfgStatus;  //1byte
	uint16_t 		reserve;   		//2byte, byte padding.
	//uint8_t			reserve1;		//1byte, byte padding
    uint16_t 		crc;	   		//2byte
} syscfg_t;

extern syscfg_t syscfg; //keeping the configuration

/******************************************************************************
 * Call to read the cfg. pData MUST include the space for the CRC on the last
 * 2 byte.
 * Return True if Configuration's CRC is correct.
*******************************************************************************/
uint8_t ICACHE_FLASH_ATTR cfgloadflash(void *pData, uint16 len);

/******************************************************************************
 * Calculate the crc and write the data into the memory space.
 * The pData MUST the memory space to keep the CRC on the last 2 byte.
*******************************************************************************/
void ICACHE_FLASH_ATTR cfgsaveflash(void *pData, uint16 len);

#endif /* SHAREINCLUDE_CFGMGT_H_ */
