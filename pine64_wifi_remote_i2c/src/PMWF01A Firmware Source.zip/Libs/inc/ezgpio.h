#ifndef __EZGPIO_H__
#define __EZGPIO_H__
#include "ets_sys.h"
#include "osapi.h"
#include "gpio.h"
#include "eagle_soc.h"

//#ifndef PIN_PULLUP_DIS
//#define PIN_PULLUP_DIS(PIN_NAME)                 CLEAR_PERI_REG_MASK(PIN_NAME, PERIPHS_IO_MUX_PULLUP)
//#define PIN_PULLUP_EN(PIN_NAME)                  SET_PERI_REG_MASK(PIN_NAME, PERIPHS_IO_MUX_PULLUP)
//#define PIN_PULLDWN_DIS(PIN_NAME)             CLEAR_PERI_REG_MASK(PIN_NAME, PERIPHS_IO_MUX_PULLDWN)
//#define PIN_PULLDWN_EN(PIN_NAME)              SET_PERI_REG_MASK(PIN_NAME, PERIPHS_IO_MUX_PULLDWN)
//#define PIN_FUNC_SELECT(PIN_NAME, FUNC)  do { \
//        CLEAR_PERI_REG_MASK(PIN_NAME, (PERIPHS_IO_MUX_FUNC<<PERIPHS_IO_MUX_FUNC_S)); \
//        SET_PERI_REG_MASK(PIN_NAME, (((FUNC&BIT2)<<2)|(FUNC&0x3))<<PERIPHS_IO_MUX_FUNC_S); \
//    } while (0)
//#endif

typedef enum {
  EZGPIO_INPUT=0,
  EZGPIO_OUTPUT=1
} EzGPIO_PinMode;

typedef enum {
  //EZGPIO_PULLDOWN=2,
  EZGPIO_PULLUP=3,
  EZGPIO_NOPULL=4
} EzGPIO_PullStatus;

/*
 * Initiallize easy interrupts
 */
void ICACHE_FLASH_ATTR EzGpio_Init(void);

/*
 * Detach interrupt handler
 */
bool ICACHE_FLASH_ATTR EzGpio_Detach(uint8_t gpio_pin);

/*
 * Install GPIO interrupt handler
 * During the pin interrupt, it will call the interrupt service routing (*vect) with (*data)
 */
void ICACHE_FLASH_ATTR EzGpio_Attach(uint8 gpio_pin, GPIO_INT_TYPE intrType, void (*vect)(void *), void *data);

#define ISR_HANDLER __attribute__((section(".iram1.text")))

/**
 * Sets the pull up and pull down registers for a pin.
 * 'pullUp' takes precedence over pullDown
 */
bool ICACHE_FLASH_ATTR EzGpio_pullMode(uint8_t gpio_pin, EzGPIO_PullStatus pullStatus);

/**
 * Sets the 'gpio_pin' pin as an input GPIO and sets the pull up and
 * pull down registers for that pin.
 */
bool ICACHE_FLASH_ATTR EzGpio_pinMode(uint8_t gpio_pin, EzGPIO_PullStatus pullStatus, EzGPIO_PinMode pinMode) ;

/*
 * To set the output high or low
 * GPIO_OUTPUT_SET(gpio_no, bit_value)
 *
 * To Read the input pin status
 * GPIO_INPUT_GET(gpio_no)
 */

#endif
