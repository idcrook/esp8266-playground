/*
 * i2c_Gen.h
 *
 *  Created on: Apr 8, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_I2C_GEN_H_
#define SHAREINCLUDE_I2C_GEN_H_

#include "ets_sys.h"
#include "osapi.h"


/**
 * Poll a device to check it is present
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * return true if detected a device present.
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_polldev(uint8_t address);
/**
 * Read a single byte
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * uint8_t location   : The memory location to read
 * return true if success.
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_readByte(uint8_t address, uint8_t location, uint8_t *pdata);
/**
 * Read a single byte
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * return true if success.
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_readByteDirect(uint8_t address, uint8_t *pdata);
/**
 * Read multiple bytes from the EEPROM
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * uint8_t location   : The memory location to read
 * uint8_t *pdata		: ptr to keep the return data, caller must provide the memory space
 * uint8_t len        : Number of bytes to read
 * return true if success.
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_readPage(uint8_t address, uint8_t location, uint8_t *pdata,uint8_t len);
/**
 * Write a byte to the I2C EEPROM
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t location   : Memory location
 * uint8_t data       : Data to write to the EEPROM
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_writeByte(uint8_t address, uint8_t location, uint8_t *pdata);
/**
 * Write a byte to the I2C bus
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t data       : Data to write to the device
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_writeByteDirect(uint8_t address, uint8_t *pdata);
/**
 * Write a number of pages to the EEPROM
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t location   : Start on this memory address
 * uint8_t data[]     : The data to be writen to the EEPROM
 * uint8_t len        : The lenght of the data
 */
uint8_t ICACHE_FLASH_ATTR I2CGen_writePage(uint8_t address, uint8_t location, uint8_t data[], uint8_t len);

#endif /* SHAREINCLUDE_I2C_GEN_H_ */
