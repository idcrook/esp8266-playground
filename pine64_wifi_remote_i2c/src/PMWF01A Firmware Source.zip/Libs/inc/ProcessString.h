/*
 * ProcessString.h
 *
 *  Created on: Mar 9, 2016
 *      Author: khgoh
 */

#ifndef INC_PROCESSSTRING_H_
#define INC_PROCESSSTRING_H_

#include "ets_sys.h"
#include "osapi.h"

void processStringInit(void (*printOut)(uint8_t *pData, unsigned int len),
				uint16_t (*rxbyte)(uint8_t *pData, uint16_t rxmaxsize));

/*
 * Call to process the received string from console
 */
void processRxString(char *str);

#endif /* INC_PROCESSSTRING_H_ */
