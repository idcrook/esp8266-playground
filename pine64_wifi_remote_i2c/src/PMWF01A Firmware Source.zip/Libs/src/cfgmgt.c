/*
 * cfgmgt.h
 *
 *  Created on: Apr 11, 2015
 *      Author: khgoh
 */
#include "cfgmgt.h"
#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"
#include "crc_update.h"

syscfg_t syscfg;

/*
 * Flash Configuration Save and restore
 * Each configuration will have total of 4096 byte including CRC on the last 2 byte.
 *
 * During loading, will load the first copy and check crc. If CRC fail will load copy
 * #2. If still fail, will return false
 *
 * During Saving, it will save on copy #2 first then copy #1.
 *
 * Saving 2 copy is to prevent power off during saving the configuration.
 */
#define SPI_FLASH_SECTOR_SIZE     4096	//flash sector size
#define CFG_SECTOR_START		  0x3E	//flash sector start location.

/******************************************************************************
 * Call to read the cfg. pData MUST include the space for the CRC on the last
 * 2 byte.
 * Return True if Configuration's CRC is correct.
*******************************************************************************/
uint8_t ICACHE_FLASH_ATTR cfgloadflash(void *pData, uint16 len)
{

	SpiFlashOpResult result;

    spi_flash_read((CFG_SECTOR_START + 0) * SPI_FLASH_SECTOR_SIZE,
                           (uint32 *)pData, len);

    if (result!=SPI_FLASH_RESULT_OK || !CheckCRC((uint8_t*)pData,len)) {
    	spi_flash_read((CFG_SECTOR_START + 1) * SPI_FLASH_SECTOR_SIZE,
    	                           (uint32 *)pData, len);

    	if (!CheckCRC((uint8_t*)pData,len)) {
    		return(0);
    	}
    	else {
    		//flash part 0 corrupted, copy part 1 into part 0
    		spi_flash_erase_sector(CFG_SECTOR_START + 0);
    		spi_flash_write((CFG_SECTOR_START + 0) * SPI_FLASH_SECTOR_SIZE,
    				                        (uint32 *)pData, len);
    	}
    }
    return(1);
}

/******************************************************************************
 * Calculate the crc and write the data into the memory space.
 * The pData MUST the memory space to keep the CRC on the last 2 byte.
*******************************************************************************/
void ICACHE_FLASH_ATTR cfgsaveflash(void *pData, uint16 len)
{
	SpiFlashOpResult result;

	CalCRC((uint8_t*)pData,len);
	//Write data in Copy #2 first.
	result=spi_flash_erase_sector(CFG_SECTOR_START + 1);
	result=spi_flash_write((CFG_SECTOR_START + 1) * SPI_FLASH_SECTOR_SIZE,
	                        (uint32 *)pData, len);
	//Write data in Copy #1.
	result=spi_flash_erase_sector(CFG_SECTOR_START + 0);
	result=spi_flash_write((CFG_SECTOR_START + 0) * SPI_FLASH_SECTOR_SIZE,
		                        (uint32 *)pData, len);
}

