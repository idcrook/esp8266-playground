/*
 * pktcreate.c
 *
 *  Created on: Apr 20, 2015
 *      Author: khgoh
 */
#include "pktcreate.h"
#include "crc_update.h"
#include "ets_sys.h"
#include "osapi.h"
#include "mem.h"
#include "user_config.h"
#include "user_interface.h"
#include "tcpCommandList.h"

//define max number of byte size in multiple packet Frame.
#define PKTCREATE_MAXFRAMESIZE	1024

uint8_t *pPktMemory=0; //keep the ptr to the memory
uint16_t pktSize=0;
uint16_t pktPayloadSize=0;
uint8_t pktTxCnt=1;
uint8_t pktRxCnt=0; //keep the last received counter.


/*
 * Call to request memory to create the reply or push packet
 * Will return the pointer to memory to keep the payload.
 * datasize -> data size to send, D0 to Dn (Excluding Cmd byte)
 * return true if memory is ready
 * Will add the byte at the end of the previous packet if currently have packet already allocated previously.
 */
uint8_t ICACHE_FLASH_ATTR pktc_request(uint8_t **pMemorySpace,uint16_t datasize)
{
	uint16_t tmpPktSize;
	//calculate the current packet byte size require
	tmpPktSize=(datasize+TXPKT_ExtraPayloadByte+1);

	if (pktSize==0) //only allow 1 packet at any one time.
	{
		//total size still below our set limit, so we append the new packet at the end of previous packet.
		pPktMemory=(uint8_t*)os_zalloc(tmpPktSize);
		if (pPktMemory)
		{
			pktSize=tmpPktSize;
			(*pMemorySpace)=&(pPktMemory[PKTINDEX_DATA+1]);
			return(1);
		}
	}
	return(0);
}

/*
 * Call the calculate and create the packet for sending.
 * if pServerRef is NULL, it will set the 4byte field to zero.
 */
void ICACHE_FLASH_ATTR pktc_create(uint8_t result, uint8_t Cmd)
{
	uint8_t ifMacAddr[6];
	wifi_get_macaddr(STATION_IF,ifMacAddr);
	pPktMemory[PKTINDEX_LEN]=pktSize;		//Len in factor 16, packet size
	pPktMemory[PKTINDEX_Cnt]=pktTxCnt++;			//packet counter
	pPktMemory[PKTINDEX_DATA]=Cmd;
	pPktMemory[PKTINDEX_RSSI]=(uint8_t)wifi_station_get_rssi();
	os_memcpy(&(pPktMemory[PKTINDEX_MAC]),ifMacAddr,6);
	pPktMemory[PKTINDEX_Result]=result;
	pPktMemory[0]=STXBYTE;
	CalCRC(&(pPktMemory[0]),pktSize);

}

/*
 * Call after pktc_create to get the created packet for sending out.
 */
uint8_t ICACHE_FLASH_ATTR *pktc_Get(uint16_t *pPktSize)
{
	(*pPktSize)=pktSize;
	return(pPktMemory);
}

/*
 * Call after finish sending the packet. no more needing the data.
 */
void ICACHE_FLASH_ATTR pktc_done(void)
{
	os_free(pPktMemory);
	pPktMemory=0;
	pktSize=0;
}

/*
 * Do a CRC check the Rx data.
 * return true if the data is ready for process.
 * will also return the pointer to the CMD/Data byte in the packet.
 *   CMD D0...Dn
 * pSize -> to return the total byte size CMD to Dn byte.
 */
uint8_t ICACHE_FLASH_ATTR pktc_rxPecket(uint8_t *pData, uint8_t **pResult, uint8_t **pCmdData, uint16_t *pSize)
{
	if (CheckCRC(pData,(pData[PKTINDEX_LEN])))
	{
		if (pktRxCnt!=pData[PKTINDEX_Cnt]){
			pktRxCnt=pData[PKTINDEX_Cnt];	//keep the current packet counter
			(*pCmdData)=&(pData[PKTINDEX_DATA]);
			(*pResult)=&(pData[PKTINDEX_Result]);
			(*pSize)=(pData[PKTINDEX_LEN])-TXPKT_ExtraPayloadByte;
			return(1);
		}
	}
	return(0);
}



