/******************************************************************************
 * Copyright 2013-2014 Espressif Systems (Wuxi)
 *
 * FileName: uart.c
 *
 * Description: Two UART mode configration and interrupt handler.
 *              Check your hardware connection while use this mode.
 *
 * Modification history:
 *     2014/3/12, v1.0 create this file.
*******************************************************************************/
#include "ets_sys.h"
#include "osapi.h"
#include "uart.h"
#include "cycindex_macro.h"
#include "user_interface.h"


#define UART0   0
#define UART1   1

#define RXBUFSIZE	(1024)
#define TXBUFSIZE	(512)
#define TXIntrTriggerLevel	(20)		//set the uart system tx low level trigger.
#define RXIntrTriggerLevel  (100)	//minimum value is 1. If set to zero, the system will hang.
#define RxIntrTimeOutTrigger (10)	//minimum time Rx idle before start trigger.

// UartDev is defined and initialized in rom code.
extern UartDevice UartDev;

typedef struct {
	cycindex_t rxBufCtrl;
	cycindex_t txBufCtrl;
	uint8_t rxBuf[RXBUFSIZE];
	uint8_t txBuf[TXBUFSIZE];
} uartbuff_t;


uartbuff_t uart0buffer;

//#define  UART_ECHO_TEST
LOCAL void UART_Intr_Handler(void *para);
LOCAL void ICACHE_FLASH_ATTR uart_config(uint8 uart_no);

/******************************************************************************
 * FunctionName : uart_init
 * Description  : user interface for init uart
 * Parameters   : UartBautRate uart0_br - uart0 bautrate
 *                UartBautRate uart1_br - uart1 bautrate
 * Returns      : NONE
*******************************************************************************/
void ICACHE_FLASH_ATTR
uart0_init(void)
{
    // rom use 74880 baut_rate, here reinitialize
	ETS_UART_INTR_DISABLE();

	CYCINDEX_RST_INDEXCTRL(&uart0buffer.rxBufCtrl,RXBUFSIZE);
	CYCINDEX_RST_INDEXCTRL(&uart0buffer.txBufCtrl,TXBUFSIZE);

	UartDev.baud_rate = 57600;
	UartDev.parity=NONE_BITS;
	UartDev.stop_bits=ONE_STOP_BIT;

	uart_config(UART0);
    ETS_UART_INTR_ENABLE();
}

/******************************************************************************
 * FunctionName : uart_config
 * Description  : Internal used function
 *                UART0 used for data TX/RX, RX buffer size is 0x100, interrupt enabled
 *                UART1 just used for debug output
 * Parameters   : uart_no, use UART0 or UART1 defined ahead
 * Returns      : NONE
*******************************************************************************/
LOCAL void ICACHE_FLASH_ATTR uart_config(uint8 uart_no)
{
	uint32_t tmp;

	if (uart_no==UART1) return;
    if (uart_no == UART1) {
        PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO2_U, FUNC_U1TXD_BK);
    } else {
        /* rcv_buff size if 0x100 */
        ETS_UART_INTR_ATTACH(UART_Intr_Handler,  &(uart0buffer));
        PIN_PULLUP_DIS(PERIPHS_IO_MUX_U0TXD_U);
#ifdef Debug_Print
        PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0TXD_U, FUNC_U0TXD);
#endif
    }

    WRITE_PERI_REG(UART_INT_CLR(UART1), 0xffff); //permenent disable UART1

    uart_div_modify(uart_no, UART_CLK_FREQ / (UartDev.baud_rate));

    WRITE_PERI_REG(UART_CONF0(uart_no),    UartDev.exist_parity
                   | UartDev.parity
                   | (UartDev.stop_bits << UART_STOP_BIT_NUM_S)
                   | (UartDev.data_bits << UART_BIT_NUM_S));


    //clear rx and tx fifo,not ready
    SET_PERI_REG_MASK(UART_CONF0(uart_no), UART_RXFIFO_RST | UART_TXFIFO_RST);
    CLEAR_PERI_REG_MASK(UART_CONF0(uart_no), UART_RXFIFO_RST | UART_TXFIFO_RST);

    //set rx fifo trigger
    WRITE_PERI_REG(UART_CONF1(uart_no), (UartDev.rcv_buff.TrigLvl & UART_RXFIFO_FULL_THRHD) << UART_RXFIFO_FULL_THRHD_S);

    //clear all interrupt
    WRITE_PERI_REG(UART_INT_CLR(uart_no), 0xffff);
    //enable rx_interrupt
    SET_PERI_REG_MASK(UART_INT_ENA(uart_no), UART_RXFIFO_FULL_INT_ENA);

    //set tx fifo trigger
    tmp=READ_PERI_REG(UART_CONF1(uart_no));
    WRITE_PERI_REG(UART_CONF1(uart_no),
    		((RXIntrTriggerLevel & UART_RXFIFO_FULL_THRHD) << (UART_RXFIFO_FULL_THRHD_S)) |
			((RxIntrTimeOutTrigger & UART_RX_TOUT_THRHD) <<(UART_RX_TOUT_THRHD_S))|
    		((TXIntrTriggerLevel & UART_TXFIFO_EMPTY_THRHD) << (UART_TXFIFO_EMPTY_THRHD_S)));

    //enable Rx Time out interrupt
    SET_PERI_REG_MASK(UART_CONF1(uart_no), UART_RX_TOUT_EN);
    SET_PERI_REG_MASK(UART_INT_ENA(uart_no), UART_RXFIFO_TOUT_INT_ENA);

	//disable tx_interrupt
 	CLEAR_PERI_REG_MASK(UART_INT_ENA(uart_no), UART_TXFIFO_EMPTY_INT_ENA);

 	//clear all interrupt
	WRITE_PERI_REG(UART_INT_CLR(uart_no), 0xffff);
}

/******************************************************************************
 * FunctionName : uart0_rx_intr_handler
 * Description  : Internal used function
 *                UART0 interrupt handler, add self handle code inside
 * Parameters   : void *para - point to ETS_UART_INTR_ATTACH's arg
 * Returns      : NONE
*******************************************************************************/
LOCAL void
UART_Intr_Handler(void *para)
{
    /* uart0 and uart1 intr combine togther, when interrupt occur, see reg 0x3ff20020, bit2, bit0 represents
     * uart1 and uart0 respectively
     */
	uartbuff_t *pUartBuff= (uartbuff_t *)para;
    uint8 RcvChar;

    if(READ_PERI_REG(UART_INT_ST(UART0)))	//any UART0 stuff
    {
    	if(UART_TXFIFO_EMPTY_INT_ST == (READ_PERI_REG(UART_INT_ST(UART0)) & UART_TXFIFO_EMPTY_INT_ST))
		{
    		// UART Transmitting Handler
			while(!CYCINDEX_ISEMPTY(&pUartBuff->txBufCtrl))
			{
				if (((READ_PERI_REG(UART_STATUS(UART0))>>UART_TXFIFO_CNT_S) & UART_TXFIFO_CNT) <=127)
				{
					//Tx FIFO still got space, send 1 byte into the Tx FIFO
					WRITE_PERI_REG(UART_FIFO(UART0) , pUartBuff->txBuf[CYCINDEX_GETRETURNINDEX(&pUartBuff->txBufCtrl)]);
				}
				else
				{
					//FIFO full, need to exit now.
					break;
				}
			}

			//At this point, either FIFO full or Txbuff is empty.
			if (CYCINDEX_ISEMPTY(&pUartBuff->txBufCtrl))
			{
				//Tx buffer is empty, neet to turn off the Tx Empty interrupt
				CLEAR_PERI_REG_MASK(UART_INT_ENA(UART0), UART_TXFIFO_EMPTY_INT_ENA);
			}
		}

    	// UART Receiving Handler
		while (READ_PERI_REG(UART_STATUS(UART0)) & (UART_RXFIFO_CNT << UART_RXFIFO_CNT_S)) {
			RcvChar = READ_PERI_REG(UART_FIFO(UART0)) & 0xFF;

			//If Rx buffer is full, we just remove the oldest byte from buffer
			//and make room for new incomming byte.
			/* you can add your handle code below.*/
			if(CYCINDEX_ISFULL(&pUartBuff->rxBufCtrl)){
				//buffer full, empty 1 place.
				CYCINDEX_GETRETURNINDEX(&pUartBuff->rxBufCtrl);
			}
			pUartBuff->rxBuf[CYCINDEX_KEEPINDEX(&pUartBuff->rxBufCtrl)]=RcvChar;
		}
    }
    WRITE_PERI_REG(UART_INT_CLR(UART0), 0xffff);
}

uint16_t ICACHE_FLASH_ATTR UART0_TxAvailableSpace(void)
{
	if (!CYCINDEX_ISFULL(&uart0buffer.txBufCtrl))
	{
		return(CYCINDEX_SPACELEFT(&uart0buffer.txBufCtrl));
	}
	return(0);
}
void ICACHE_FLASH_ATTR UART0_SendBytes(uint8_t *pData, unsigned int size)
{
	int c;
	for (c=0;c<size;c++)
	{
		while (CYCINDEX_ISFULL(&uart0buffer.txBufCtrl)) //wait until buffer is not full.
		{
#ifdef Debug_Print
			os_printf("IS FULL ");
#endif
			SET_PERI_REG_MASK(UART_INT_ENA(UART0), UART_TXFIFO_EMPTY_INT_ENA);
		}
		uart0buffer.txBuf[CYCINDEX_KEEPINDEX(&uart0buffer.txBufCtrl)]=pData[c];
	}
	//make sure interrupt is on so that the byte can be send out.
	SET_PERI_REG_MASK(UART_INT_ENA(UART0), UART_TXFIFO_EMPTY_INT_ENA);
}

void ICACHE_FLASH_ATTR UART0_SendByte(uint8_t data)
{
	UART0_SendBytes(&data,1);
}
/*
 * Call to return the number of byte in the rx buffer
 */
uint16_t ICACHE_FLASH_ATTR UART0_RxAvailable(void)
{
	if (!CYCINDEX_ISEMPTY(&uart0buffer.rxBufCtrl))
	{
		return(RXBUFSIZE-CYCINDEX_SPACELEFT(&uart0buffer.rxBufCtrl));
	}
	return(0);
}
/*
 * Call to return the Rx data from the buffer, return the actual byte return.
 */
uint16_t ICACHE_FLASH_ATTR UART0_RxReturn(uint8_t* pData, uint16_t size)
{
	int c;
	uint16_t totalsize=0;
	for (c=0;c<size;c++) {
		if (!CYCINDEX_ISEMPTY(&uart0buffer.rxBufCtrl))
		{
			pData[c]=uart0buffer.rxBuf[CYCINDEX_GETRETURNINDEX(&uart0buffer.rxBufCtrl)];
			totalsize++;
		}
		else {
			//no more data to return,
			break;
		}
	}
	return(totalsize);
}
