/*
 * ServerLink.c
 *
 *  Created on: Apr 21, 2015
 *      Author: khgoh
 */
#include "serverlink.h"
#include "ets_sys.h"
#include "osapi.h"
#include "tcpdriver.h"
#include "user_interface.h"
#include "pktcreate.h"
#include "cfgmgt.h"
#include "board.h"
#include "tcpCmdMgt.h"


#define SLINK_SERVER_PORT (35000)
TcpLinkProp_t *pClientRef=0;
static ETSTimer SLinkRefresh_Timer;
void ICACHE_FLASH_ATTR SLink_Refresh(void *arg);
//----------------------------------------------------------------

void ICACHE_FLASH_ATTR SLink_init(void)
{
	uint8_t tmpMac[6];
	wifi_get_macaddr(STATION_IF,tmpMac);
	tcpCmdMgt_init();
	tcpdriver_init(tmpMac[5]); //configure the tcpdriver

    pClientRef=tcpdriver_ConnRemoteSetup(syscfg.serverIP.addr,SLINK_SERVER_PORT);
	tcpdriver_RegCB_connected(pClientRef,&tcpCmdMgt_Connected);
	tcpdriver_RegCB_receive(pClientRef, &tcpCmdMgt_Rx);
	//tcpdriver_RegCB_disconnected(pClientRef, &CMB_TcpDisonnected);

    tcpdriver_ConnStart(pClientRef);

	//TcpPush_Init(pClientRef);

	os_timer_disarm(&SLinkRefresh_Timer);
	os_timer_setfn(&SLinkRefresh_Timer, (os_timer_func_t *)&SLink_Refresh, NULL);
	os_timer_arm(&SLinkRefresh_Timer, 1000, 1);

}

uint16_t ICACHE_FLASH_ATTR SLink_PushLinkDirect(uint8_t *pPkt, uint16_t size)
{
	return(tcpdriver_SendByLink(pClientRef,pPkt,size));
}

uint16_t ICACHE_FLASH_ATTR SLink_IsLinkUp(void)
{
	return(tcpdriver_isLinkUp(pClientRef));

}
void ICACHE_FLASH_ATTR SLink_Refresh(void *arg)
{
	static uint8_t preTcpLinkStatus=0;
	uint8_t currTcpLinkStatus=tcpdriver_isLinkUp(pClientRef);

	if (preTcpLinkStatus!=currTcpLinkStatus)
	{
		preTcpLinkStatus=currTcpLinkStatus;
		if (currTcpLinkStatus) {
			Board_LedControl(LED_SERVER_UP);
		}
		else {
			if (wifictrl_IsLinkUp()) {
				Board_LedControl(LED_SERVER_DOWN);
			}
			else {
				//wifi link also down.
				Board_LedControl(LED_LINK_DOWN);
			}
		}
	}
}
void ICACHE_FLASH_ATTR SLink_stop(void)
{
	if (pClientRef) {
		tcpdriver_ConnStop(pClientRef);
	}
}


