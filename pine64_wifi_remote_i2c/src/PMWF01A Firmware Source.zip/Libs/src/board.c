/*
 * board.c
 *
 *  Created on: May 1, 2015
 *      Author: khgoh
 */

#include "board.h"
#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_interface.h"
#include "uart.h"
#include "ezgpio.h"
#include "wificontrol.h"
#include "cfgmgt.h"
#include "dprint.h"
#include "processString.h"
#include "tcpdriver.h"

#define LED_BLINK_ON_PERIOD		40 //in ms
#define LED_BLINK_OFF_PERIOD    30 //in ms
#define LINK_DOWN_CYCLE			250
#define WIFI_UP_CYCLE			1000
#define CFGMODE_CYCLE			500
/*
 * Init the board Mainly on the hardware side
 * Call this first before any other functions.
 */
static ETSTimer boardLedRefresh_Timer;
static ETSTimer boardSystemRestart_Timer;
static ledmode_t boardLedMode;
static ETSTimer boardLedBlink_Timer[2];

static uint8_t boardLEDReady=0;
void ICACHE_FLASH_ATTR board_LedBlinkOff_0(void *arg);
void ICACHE_FLASH_ATTR board_LedBlinkOff_1(void *arg);

void ICACHE_FLASH_ATTR Board_ProcessLED(void *arg);

void ICACHE_FLASH_ATTR Board_LedBlinkSystem(void);

uint8_t prePortStatus=0x3f; //assume all high by default.
uint8_t gpioindex[]={GPIO_nINT,GPIO_SDA,GPIO_SCL,GPIO_SPICS,GPIO_SPIMOSI,GPIO_SPIMISO};
#define TotalGPIOPin (sizeof(gpioindex)/sizeof(uint8_t))

/*
 * Call Once to init the system
 */
void ICACHE_FLASH_ATTR Board_Init(void)
{
	uint8_t tmpMac[6];
	uint8_t tmp=0;
	struct station_config stcfg;

	uart0_init();
	RELAY_CONFIG();
	RELAY_OFF();
#ifndef ENABLE_DEBUG_UART0
	system_set_os_print(0); //Disable system debug message
#endif
	os_delay_us(100000);
	EzGpio_Init();

	boardLEDReady=1;
	LED_CONFIG();
	LED_OFF();
	boardLedMode=LED_IDLE;
	os_timer_disarm(&boardLedBlink_Timer[0]);
	os_timer_setfn(&boardLedBlink_Timer[0], (os_timer_func_t *)&board_LedBlinkOff_0, NULL);
	os_timer_disarm(&boardLedBlink_Timer[1]);
	os_timer_setfn(&boardLedBlink_Timer[1], (os_timer_func_t *)&board_LedBlinkOff_1, NULL);
	os_timer_disarm(&boardLedRefresh_Timer);
	os_timer_setfn(&boardLedRefresh_Timer, (os_timer_func_t *)&Board_ProcessLED, NULL);
	Board_LedControl(LED_LINK_DOWN);

#ifdef FORCE_DEF_CFG
	{
		dPrintText("Force using default setting.\n");
		struct station_config stcfg;
		int cnt;
		os_memset(&stcfg,0,sizeof(struct station_config));
		stcfg.bssid_set=0;
		for (cnt=0;cnt<strlen(WIFI_CLIENTSSID);cnt++)
			stcfg.ssid[cnt]=WIFI_CLIENTSSID[cnt];
		for (cnt=0;cnt<strlen(WIFI_CLIENTPASSWORD);cnt++)
			stcfg.password[cnt]=WIFI_CLIENTPASSWORD[cnt];
		wifictrl_StartSta(&(stcfg));
		syscfg.serverIP.addr=ipaddr_addr(TCPSERVERIP);
	}
#else
	{
		dPrintText("Using Wifi User Setting\n");
		if (!cfgloadflash(&syscfg,sizeof(syscfg_t))) {
			//error load server ip, use the default setting.
			dPrintText("No Tcp server setting found, Use Default Setting\n");
			syscfg.gpioCfgStatus=0x3f; //set all port to input
			syscfg.i2cenable=0; //disable i2c
			syscfg.pwnenable=0; //disable pwm
			syscfg.serverIP.addr=ipaddr_addr(TCPSERVERIP);

			wifi_set_opmode(STATION_MODE); //make sure it is on station mode.
			os_memset(&stcfg,0,sizeof(struct station_config));
			strcpy(stcfg.ssid,WIFI_CLIENTSSID);
			strcpy(stcfg.password,WIFI_CLIENTPASSWORD);
			stcfg.bssid_set=0;
			wifi_station_set_config(&stcfg);
			Board_ConfigGPIO(0x3f,0x3f,tmp); //configure all to input port
		}
	}
#endif
	processStringInit(&UART0_SendBytes,&UART0_RxReturn);
}

/*
 * Call this after the system is ready
 * to init the LED display
 */
void ICACHE_FLASH_ATTR Board_LED_Init(void)
{

}

/*
 * Timer Callback to reboot the system
 */
void ICACHE_FLASH_ATTR Board_RestartNow(void *arg)
{
	system_restart();
}

void ICACHE_FLASH_ATTR Board_SystemRestart(void)
{
	Board_LedControl(LED_REBOOTING);
	dPrintText("Request Board Restart....");
	os_timer_disarm(&boardSystemRestart_Timer);
	os_timer_setfn(&boardSystemRestart_Timer, (os_timer_func_t *)Board_RestartNow, NULL);
	os_timer_arm(&boardSystemRestart_Timer, 500, 0);
	tcpdriver_ConnStop_All();
}


/*
 * Timer call back function to process the LED
 */
void ICACHE_FLASH_ATTR Board_ProcessLED(void *arg)
{
	static char value=0;
	switch(boardLedMode)
	{
	case LED_LINK_DOWN:
		//blink both led
		Board_LedBlinkSystem();
		break;
	case LED_SERVER_UP:
		//red led on
		LED_ON();
		break;
	case LED_WIFI_UP:
	case LED_SERVER_DOWN:
		//blink the red led
		Board_LedBlinkSystem();
		break;
	case LED_CTRL_CFGMODE:
		//LED Off
		LED_OFF();
		break;
	}
}

/*
 * Application call to set the LED mode.
 */
void ICACHE_FLASH_ATTR Board_LedControl(ledmode_t mode)
{

	if (boardLEDReady) {
		if (boardLedMode==LED_CTRL_CFGMODE && mode!=LED_REBOOTING)
		{
			//do not allow to change the LED status if it is under cfgmode
			//unless it is Rebooting.
			return;
		}

		if (mode!=boardLedMode ) {
			switch(mode)
			{
			case LED_LINK_DOWN:
				dPrintText("LED Status: Link Down");
				os_timer_disarm(&boardLedRefresh_Timer);
				Board_LedBlinkSystem();
				os_timer_arm(&boardLedRefresh_Timer, LINK_DOWN_CYCLE, 1);
				break;
			case LED_WIFI_UP:
				dPrintText("LED Status: Wifi Connected");
				os_timer_disarm(&boardLedRefresh_Timer);
				Board_LedBlinkSystem();
				os_timer_arm(&boardLedRefresh_Timer, WIFI_UP_CYCLE, 1);
				break;
			case LED_SERVER_DOWN:
				//only update the LED if it is not link down.
				dPrintText("LED Status: Server Not Connected");
				os_timer_disarm(&boardLedRefresh_Timer);
				Board_LedBlinkSystem();
				os_timer_arm(&boardLedRefresh_Timer, WIFI_UP_CYCLE, 1);
				break;
			case LED_SERVER_UP:
				//Turn On the LED
				dPrintText("LED Status: Server Up");
				os_timer_disarm(&boardLedRefresh_Timer);
				LED_ON();
				break;
			case LED_CTRL_CFGMODE:
				//Turn Off the LED
				dPrintText("LED Status: Configuration Mode");
				os_timer_disarm(&boardLedRefresh_Timer);
				LED_OFF();
				os_timer_arm(&boardLedRefresh_Timer, WIFI_UP_CYCLE, 0);
				break;
			case LED_REBOOTING:
				//Turn Off the LED
				dPrintText("LED Status: Reboot");
				os_timer_disarm(&boardLedRefresh_Timer);
				LED_OFF();
				break;
			}
			boardLedMode=mode;
		}
		else {
		}

	}
}

//For LED On Blink callback
void ICACHE_FLASH_ATTR board_LedBlinkOff_0(void *arg)
{
	LED_OFF();
}

//For LED Off Blink callback
void ICACHE_FLASH_ATTR board_LedBlinkOff_1(void *arg)
{
	LED_ON();
}

/*
 * Call to Blink On the LED
 */
void ICACHE_FLASH_ATTR Board_LedBlinkSystem(void)
{
	LED_ON();
	os_timer_disarm(&boardLedBlink_Timer[0]);
	os_timer_arm(&boardLedBlink_Timer[0], LED_BLINK_ON_PERIOD, 0);
}

/*
 * Call to blink off the LED Once
 * Only allow if the Server is up.
 */
void ICACHE_FLASH_ATTR Board_LedBlinkOff(void)
{
	if (boardLedMode==LED_SERVER_UP) {
		LED_OFF();
		os_timer_disarm(&boardLedBlink_Timer[1]);
		os_timer_arm(&boardLedBlink_Timer[1], LED_BLINK_OFF_PERIOD, 0);
	}
}


void ICACHE_FLASH_ATTR Board_SetGPIO(uint8_t mask, uint8_t status)
{
	int c=0;
	uint8_t checkingmask=syscfg.gpioCfgStatus;
	if (syscfg.i2cenable) {
		checkingmask&=~(0x07); //mask of the sck, sda and nintr bit.
	}

	for (c=0;c<TotalGPIOPin;c++) {
		if (!(checkingmask&(1<<c))) {
			//only allow output port to change status
			if (mask&(1<<c)) {
				if (status & (1<<c))
				{
					//turn on
					GPIO_OUTPUT_SET(gpioindex[c],1);
				}
				else
				{
					//turn off
					GPIO_OUTPUT_SET(gpioindex[c],0);
				}
			}
		}
	}
}



/*
 * if 0=set to output port, 1=set to input port
 * will return the updated port setting
 */
uint8_t ICACHE_FLASH_ATTR Board_ConfigGPIO(uint8_t mask,uint8_t status,uint8_t currCfgStatus)
{
	int c=0;
	uint8_t tmpSetting=currCfgStatus;
	dPrintText("Total GPIO:%d ",TotalGPIOPin);
	for (c=0;c<TotalGPIOPin;c++) {
		if (mask&(1<<c)) {
			if (status & (1<<c))
			{
				dPrintText("%d:H ",c);
				//set input port
				EzGpio_pinMode(gpioindex[c],EZGPIO_PULLUP,EZGPIO_INPUT);
				tmpSetting |= (1<<c);
			}
			else
			{
				dPrintText("%d:L ",c);
				//set output port
				EzGpio_pinMode(gpioindex[c],EZGPIO_NOPULL,EZGPIO_OUTPUT);
				tmpSetting &= ~(1<<c);
			}
		}
	}
	dPrintText("\r\n ");
	return(tmpSetting);
}

/*
 * if there is changes, it will return true.
 * and the mask will indicate the bit that have chagnes.
 */
uint8_t ICACHE_FLASH_ATTR Board_DetectInputPortChanges(uint8_t *mask, uint8_t *currPortStatus)
{
	int c=0;
	uint32_t ioportstatus;
	uint8_t changes=0;
	(*mask)=0;
	(*currPortStatus)=0;
	uint8_t checkingmask=syscfg.gpioCfgStatus;
	if (syscfg.i2cenable) {
		checkingmask&=~(0x07); //mask of the sck, sda and nintr bit.
	}
	for (c=0;c<TotalGPIOPin;c++) {
		if (checkingmask&(1<<c)) { //only check on input port (bit=1)
			ioportstatus=GPIO_INPUT_GET(gpioindex[c]);
			if (ioportstatus) {
				(*currPortStatus)|=(1<<c);
			}
			if (((*currPortStatus) & (1<<c)) != (prePortStatus & (1<<c)))
			{
				changes=1;
				(*mask)|=(1<<c);

			}
		}
	}

	if (changes)
	{
		prePortStatus=(*currPortStatus);
		return(1);
	}
	return(0);
}
