/*
 * i2c_Gen.c
 *
 *  Created on: Apr 8, 2015
 *      Author: khgoh
 */

#include "i2c_Gen.h"
#include "i2c_master.h"
#include "mem.h"
#include "dPrint.h"
/**
 * Poll a device to check it is present
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * return true if detected a device present.
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_polldev(uint8_t address)
{
	i2c_master_start();
	i2c_master_writeByte(address);
	if (!i2c_master_checkAck())
	{
		i2c_master_stop();
		return 0;
	}
	i2c_master_stop();
	return(1);
}


/**
 * Read a single byte
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * uint8_t location   : The memory location to read
 * return true if success.
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_readByte(uint8_t address, uint8_t location, uint8_t *pdata)
{
    uint8_t write_address;

    i2c_master_start();
    i2c_master_writeByte(address);
    if (!i2c_master_checkAck())
    {
    	i2c_master_stop();
        return 0;
    }

    i2c_master_writeByte(location);
    if (!i2c_master_checkAck())
    {
    	i2c_master_stop();
        return 0;
    }

    i2c_master_start();
    write_address = address ;
    write_address |= 1;
    i2c_master_writeByte(write_address);
    if (!i2c_master_checkAck())
    {
    	i2c_master_stop();
        return 0;
    }
    pdata[0] = i2c_master_readByte();
    i2c_master_send_nack(); // NOACK
    i2c_master_stop();
    if (readerr) return(0);
    return(1);
}

/**
 * Read a single byte
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * return true if success.
 * Start read at current location.
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_readByteDirect(uint8_t address, uint8_t *pdata)
{
    uint8_t write_address;

    i2c_master_start();
    write_address = address ;
    write_address |= 1;
    i2c_master_writeByte(write_address);
    if (!i2c_master_checkAck())
    {
    	i2c_master_stop();
        return 0;
    }
    pdata[0] = i2c_master_readByte();
    i2c_master_send_nack(); // NOACK
    i2c_master_stop();
    if (readerr) return(0);
    return(1);
}
/**
 * Read multiple bytes from the EEPROM
 * uint8_t address    : The i2c address with control code on bit[7..3]
 * uint8_t location   : The memory location to read
 * uint8_t *pdata		: ptr to keep the return data, caller must provide the memory space
 * uint8_t len        : Number of bytes to read
 * return true if success.
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_readPage(uint8_t address, uint8_t location, uint8_t *pdata,uint8_t len)
{

    uint8_t write_address;

    i2c_master_start();
    i2c_master_writeByte(address);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    i2c_master_writeByte(location);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    i2c_master_start();
    write_address = address;
    write_address |= 1;
    i2c_master_writeByte(write_address);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    uint8_t i;
    for (i = 0; i < len; i++)
    {
    	pdata[i] = i2c_master_readByte();
    	if (readerr){
    		 i2c_master_send_nack(); // NOACK
    		 i2c_master_stop();
    		return(0);
    	}
        if(i != len-1)
           i2c_master_send_ack(); //ACK
    }
    i2c_master_send_nack(); // NOACK
    i2c_master_stop();
    return (1);
}

/**
 * Write a byte to the I2C EEPROM
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t location   : Memory location
 * uint8_t data       : Data to write to the EEPROM
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_writeByte(uint8_t address, uint8_t location, uint8_t *pdata)
{
    i2c_master_start();
    //Write address
    i2c_master_writeByte(address);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    //Write memory location
    i2c_master_writeByte(location);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    //Write data
    i2c_master_writeByte(pdata[0]);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }
    i2c_master_stop();
    return 1;
}

/**
 * Write a byte to the I2C bus
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t data       : Data to write to the device
 * Will start write at the current location.
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_writeByteDirect(uint8_t address, uint8_t *pdata)
{
    i2c_master_start();
    //Write address
    i2c_master_writeByte(address);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    //Write data
    i2c_master_writeByte(pdata[0]);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }
    i2c_master_stop();
    return 1;
}

/**
 * Write a number of pages to the EEPROM
 * uint8_t address    : I2C Device address with control code on bit[7..3]
 * uint8_t location   : Start on this memory address
 * uint8_t data[]     : The data to be writen to the EEPROM
 * uint8_t len        : The lenght of the data
 */
uint8_t ICACHE_FLASH_ATTR
I2CGen_writePage(uint8_t address, uint8_t location, uint8_t data[], uint8_t len)
{
	dPrintText(" Writing ID: %02x, addr: %02x, size: %02x data: ",address, location,len);
	dPrintByte(data,len);
	dPrintText("\n");

    i2c_master_start();
    i2c_master_writeByte(address);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    i2c_master_writeByte(location);
    if (!i2c_master_checkAck())
    {
        i2c_master_stop();
        return 0;
    }

    uint8_t i;
    for (i = 0; i < len; i++)
    {
        i2c_master_writeByte(data[i]);
        if (!i2c_master_checkAck())
        {
            i2c_master_stop();
            return 0;
        }
    }

    i2c_master_stop();
    return 1;
}

