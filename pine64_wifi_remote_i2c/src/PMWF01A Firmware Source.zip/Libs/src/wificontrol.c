/*
 * wificontrol.c
 *
 *  Created on: Apr 4, 2015
 *      Author: khgoh
 */
#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_interface.h"
#include "uart.h"
#include "user_config.h"
#include "gpio.h"
#include "gpio16.h"
#include "board.h"
//#include "tcpdriver.h"

/****************** Function Prototype ***************************************/

/***************** System variable ******************************************/
static uint8_t wifiCtrl_State=0xff; //0=link down, 1=link up
static uint8_t wifiCtrl_StaStarted=0;

//keep the current connected sta AP info and my Ip address
Event_StaMode_Connected_t connectedAPInfo;
Event_StaMode_Got_IP_t connectedIPInfo;

void (*LinkUpDownCB) (uint8_t)=NULL;
void wifi_handle_event_cb(System_Event_t *evt);

/*
 * Call Once during startup, register Wifi Up/Down Status Change callback
 */
void ICACHE_FLASH_ATTR wifictrl_init(void (*LinkUpDownCallback) (uint8_t State))
{
	LinkUpDownCB=LinkUpDownCallback;
	Board_LedControl(LED_LINK_DOWN);
	wifi_set_event_handler_cb(&wifi_handle_event_cb);
}

/*
 * state = 1, wifi link is up
 */
uint8_t ICACHE_FLASH_ATTR wifictrl_IsLinkUp(uint8_t state)
{
	return(wifiCtrl_State);
}

/*
 * Configure Wifi to enable Station (ST) mode.
 * pSTCfg -> wifi STMode configuration
 * pAP_Ip -> Wifi Ip address if running on fix ip, else set to NULL
 */
void ICACHE_FLASH_ATTR wifictrl_StartSta(struct station_config *pSTCfg)
{
	wifi_set_opmode(STATION_MODE);
	struct station_config stconfig;
	wifi_station_disconnect();
	wifi_station_dhcpc_stop();
	wifi_set_phy_mode(PHY_MODE_11N);
	if(wifi_station_get_config(&stconfig))
	{
		wifi_station_set_auto_connect(1);
		wifi_station_set_config(pSTCfg);
	}
	wifi_station_connect();
	wifi_station_dhcpc_start();
	wifiCtrl_StaStarted=1;
}

#define ChangekWifiStateToDown(pWifiState,pReqCallBackFlag) do{\
			if ((pWifiState)[0]){\
				(pWifiState)[0]=0;\
				(pReqCallBackFlag)[0]=1;\
			}\
	}while(0)

void wifi_handle_event_cb(System_Event_t *evt)
{
	uint8_t requireDoCallBack=0;
	struct ip_info ipConfig;
	switch(evt->event) {
	case EVENT_STAMODE_CONNECTED:
		os_memcpy(&connectedAPInfo,&evt->event_info.connected,sizeof(Event_StaMode_Connected_t));
		ChangekWifiStateToDown(&wifiCtrl_State,&requireDoCallBack);
		break;
	case EVENT_STAMODE_DISCONNECTED:
		ChangekWifiStateToDown(&wifiCtrl_State,&requireDoCallBack);
		break;
	case EVENT_STAMODE_AUTHMODE_CHANGE:
		ChangekWifiStateToDown(&wifiCtrl_State,&requireDoCallBack);
		break;
	case EVENT_STAMODE_GOT_IP:
		//tcpdriver_connectnow();
		wifiCtrl_State=1;
		requireDoCallBack=1;
		os_memcpy(&connectedIPInfo,&evt->event_info.got_ip,sizeof(Event_StaMode_Got_IP_t));
		break;
	case EVENT_SOFTAPMODE_STACONNECTED:
		wifiCtrl_State=0;
		break;
	case EVENT_SOFTAPMODE_STADISCONNECTED:
		wifiCtrl_State=0;
		break;
	}

	if (requireDoCallBack) {
		if (wifiCtrl_State) Board_LedControl(LED_WIFI_UP);
		else Board_LedControl(LED_LINK_DOWN);

		if (LinkUpDownCB)
		{
			(*LinkUpDownCB)(wifiCtrl_State);
		}
	}
}

