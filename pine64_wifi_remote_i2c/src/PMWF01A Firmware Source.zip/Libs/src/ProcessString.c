
#include "ets_sys.h"
#include "osapi.h"
#include "mem.h"
#include <string.h>
#include <stdlib.h>
#include "cfgmgt.h"

#define	_code_unknow 			240
#define _code_ok				200

typedef enum {
	cmdID_help  	=	0,
	cmdID_show		=	1,
	cmdID_server	=	2,
	cmdID_wifi		=	3,
	cmdID_exit		=	4,
	cmdID_unknow	= 	100,
} cmdID;

char _cmdhelp[] ="help";
char _cmdshow[] ="show";
char _cmdserver[] ="server";
char _cmdwifi[] = "wifi";
char _cmdexit[]  ="exit";

//convert command into selection cmdID.
#define DecodeCmd(pCmdStr,pcmdID) do {\
		if (os_strcmp((pCmdStr),_cmdhelp)==0) (pcmdID)[0]=cmdID_help;\
			else if (os_strcmp((pCmdStr),_cmdshow)==0) (pcmdID)[0]=cmdID_show;\
			else if (os_strcmp((pCmdStr),_cmdserver)==0) (pcmdID)[0]=cmdID_server;\
			else if (os_strcmp((pCmdStr),_cmdwifi)==0) (pcmdID)[0]=cmdID_wifi;\
			else if (os_strcmp((pCmdStr),_cmdexit)==0) (pcmdID)[0]=cmdID_exit;\
			else	(pcmdID)[0]=cmdID_unknow;\
	}while(0)

char _ch_sep[] =" \n\r";

char _helpcmd0[]="show - Show current setting\n\r";
char _helpcmd1[]="server [IP] - Set server ip address\n\r";
char _helpcmd2[]="wifi [SSID] [Password] - Set wifi router SSID and Password\n\r";
char _helpcmd3[]="exit - Quit and reboot\n\r";

char _startstr[] =	"\n\rPine Wifi Remote I2c Configuration Mode\n\r"
					"Firmware Version %02x%02x%02x%02x Firmware ID: %04x\n\r"
					"Type 'help' for command information\n\r>";

void (*printsOutCB)(uint8_t *pData, unsigned int len)=0;
uint16_t (*rxbyteCB)(uint8_t *pData, uint16_t rxmaxsize)=0;
static ETSTimer procStrRx_Timer;
uint8_t configmode=0; //indicate is under configuration mode.
uint8_t debounceCnt=0;


#define PrintString(str) do {\
	if (printsOutCB) {\
		(*printsOutCB)((uint8_t*)str, os_strlen(str));\
	}\
}while(0)


void ICACHE_FLASH_ATTR ProcStrRx(void *arg);

void processStringInit(void (*printOut)(uint8_t *pData, unsigned int len),
				uint16_t (*rxbyte)(uint8_t *pData, uint16_t rxmaxsize)) {
	printsOutCB=printOut;
	rxbyteCB=rxbyte;

	os_timer_disarm(&procStrRx_Timer);
    os_timer_setfn(&procStrRx_Timer, (os_timer_func_t *)ProcStrRx, NULL);
    os_timer_arm(&procStrRx_Timer, 50, 1);

    EzGpio_pinMode(GPIO_SW,EZGPIO_PULLUP,EZGPIO_INPUT);
}

void printWifi(struct station_config *stcfg)
{
	char strbuf[100];
	char strbuf2[65];
	int cnt;
	for (cnt=0;(cnt<32 && stcfg->ssid[cnt]);cnt++)
		strbuf2[cnt]=stcfg->ssid[cnt];
	strbuf2[cnt]=0;
	os_sprintf(strbuf,"SSID: %s\r\n",strbuf2);
	PrintString(strbuf);

	for (cnt=0;(cnt<64 && stcfg->password[cnt]);cnt++)
		strbuf2[cnt]=stcfg->password[cnt];
	strbuf2[cnt]=0;
	os_sprintf(strbuf,"Password: %s\r\n",strbuf2);
	PrintString(strbuf);
}
char *strtok_r(char *s, const char *delim, char **last)
{
    char *spanp;
    int c, sc;
    char *tok;

    if (s == NULL && (s = *last) == NULL)
    {
        return NULL;
    }
cont:
    c = *s++;
    for (spanp = (char *)delim; (sc = *spanp++) != 0; )
    {
        if (c == sc)
        {
            goto cont;
        }
    }

    if (c == 0)		/* no non-delimiter characters */
    {
        *last = NULL;
        return NULL;
    }
    tok = s - 1;

    /*
     * Scan token (scan for delimiters: s += strcspn(s, delim), sort of).
     * Note that delim must have one NUL; we stop if we see that, too.
     */
    for (;;)
    {
        c = *s++;
        spanp = (char *)delim;
        do
        {
            if ((sc = *spanp++) == c)
            {
                if (c == 0)
                {
                    s = NULL;
                }
                else
                {
                    char *w = s - 1;
                    *w = '\0';
                }
                *last = s;
                return tok;
            }
        }
        while (sc != 0);
    }
    /* NOTREACHED */
}

/*
 * Call to process the received string from console
 */
void processRxString(char *str) {
    char tmp[45];
    char *ptr1,*ptr2;
    uint16_t cmderror=_code_ok;
    char strbuf[256];
    cmdID cmdid;
    struct station_config stcfg;
    int cnt;
    
    ptr1=strtok_r((char*)str,_ch_sep,&ptr2);
    
    if (ptr1>0) {
    	DecodeCmd(ptr1,&cmdid);

		switch (cmdid) {
		case cmdID_help :
			PrintString(_helpcmd0);
			PrintString(_helpcmd1);
			PrintString(_helpcmd2);
			PrintString(_helpcmd3);
			break;
		case cmdID_show	:
			wifi_station_get_config(&stcfg);
			printWifi(&stcfg);
			os_sprintf(strbuf,"Server IP: "IPSTR"\r\n",IP2STR(&syscfg.serverIP));
			PrintString(strbuf);
			break;
		case cmdID_server:
			ptr1=strtok_r(NULL,_ch_sep,&ptr2);
			if (ptr1>0)
			{
				syscfg.serverIP.addr=ipaddr_addr(ptr1);
				os_sprintf(strbuf,"Server IP: "IPSTR"\r\n",IP2STR(&syscfg.serverIP));
				PrintString(strbuf);
			}
			cfgsaveflash(&syscfg,sizeof(syscfg_t));
			break;
		case cmdID_wifi	:
			ptr1=strtok_r(NULL,_ch_sep,&ptr2);
			os_memset(&stcfg,0,sizeof(struct station_config));
			if (ptr1>0) {
				//SSID
				for (cnt=0;cnt<strlen(ptr1);cnt++)
					stcfg.ssid[cnt]=ptr1[cnt];
			}
			ptr1=strtok_r(NULL,_ch_sep,&ptr2);
			if (ptr1>0) {
				//Password
				for (cnt=0;cnt<strlen(ptr1);cnt++)
					stcfg.password[cnt]=ptr1[cnt];

			}
			else {
				os_strcpy(stcfg.password,"00000000");
			}

			wifi_set_opmode(STATION_MODE); //make sure it is on station mode.
			stcfg.bssid_set=0;
			if (wifi_station_set_config(&stcfg)==false){
				os_printf("Unable to configure wifi setting, Error\n");
			}
			else {
				printWifi(&stcfg);
			}
			wifi_station_connect();
			wifi_station_set_auto_connect(1);

			break;
		case cmdID_exit	:
			Board_SystemRestart();
			break;
		case cmdID_unknow:
			cmderror=_code_unknow;
			break;
		default:
			cmderror=_code_unknow;
			break;
		}
		if (cmderror==_code_ok)
		{
			PrintString("OK >");
		}
		else
		{
			PrintString("ERR>");
		}
    }
    else {
    	PrintString("OK >");
    }
}

#define RXBUFSize 257
void ICACHE_FLASH_ATTR ProcStrRx(void *arg)
{
	static uint8_t rxbuf[RXBUFSize];
	static uint16_t index=0;
	static uint8_t preswstate=1;
	uint16_t currRxSize=0;
	int c=0;

	/*
	 * Check for Configuration switch pressed
	 */
	if (GPIO_INPUT_GET(GPIO_SW)) {
		//now is high
		if (!preswstate) {
			//prev is low, Change state detected
			debounceCnt=0;
			preswstate=1;
		}
	}
	else {
		//now is low
		if (preswstate) {
			//now is high, Change state detected
			debounceCnt=0;
			preswstate=0;
		}
	}

	debounceCnt++;
	debounceCnt=(debounceCnt>100)?100:debounceCnt;

	if (debounceCnt==4 && preswstate==0) {
		//switch pressed.
		if (configmode) {
			//need to disable the configuration mode and restart
			configmode=0;
			PrintString("Exit and rebooting...\n\r");
			Board_SystemRestart();
		}
		else
		{
			//go into configuration mode.
			configmode=1;
			index=0;
			os_sprintf(rxbuf,_startstr,FWV_YY,FWV_MM,FWV_DD,FWV_REV,FWID);
			PrintString(rxbuf);
			os_memset(rxbuf,0,RXBUFSize);
		}
	}
	/*
	 * Check serial port for text entry.
	 */
	if (index==RXBUFSize-1)
	{
		index=0;
	}
	currRxSize=(*rxbyteCB)(&(rxbuf[index]),(RXBUFSize-index-1));

	if (configmode) {
		//echo back
		rxbuf[index+currRxSize]=0;
		//PrintString(&rxbuf[index]);

		if (currRxSize){
			//got byte received
			index+=currRxSize;
			for ( c=0;c<index+1;c++)
			{
				if(rxbuf[c]=='\n' || rxbuf[c]=='\r')
				{
					rxbuf[c]=0;
					processRxString((char*)rxbuf);
					index=0;
				}
			}
		}
	}
}
