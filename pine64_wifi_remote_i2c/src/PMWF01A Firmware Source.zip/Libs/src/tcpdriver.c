/*
 * tcpdriv.c
 *
 *  Created on: Apr 2, 2015
 *      Author: khgoh
 */
#include "tcpdriver.h"
#include "ets_sys.h"
#include "os_type.h"
#include "osapi.h"
#include "mem.h"
#include "user_interface.h"
#include "wificontrol.h"
#include "espconn.h"
#include "board.h"

#define MaxTcpLink 5 //support up to 5 different port/type of Tcp Link
#define MaxTcpConn	10 //support total of 10 connection
#define MaxBuffSize 4096


//each count period is refer to TcpRefreshDelay
#define TcpRefreshDelay		 600
#define RetryConn_PauseCount	3//number of count to wait before start to retry connect
#define RetryConn_ConnCount		2//number of count to wait during connecting.

#define KeepAliveDelay 10000 //delay between keep alive packet is the connection is idling.

#define ESPConnectRemoteNow(pEspConn) do{\
			(pEspConn)->proto.tcp->local_port=espconn_port();\
			sint8 espcon_status = espconn_connect((pEspConn));\
		}while(0)

uint8_t totalTcpLink = 0;
uint16_t totalBuffSize = 0;
TcpLinkProp_t *tcpLinkProp[MaxTcpLink];
TcpConn_t tcpConn[MaxTcpConn];
uint8_t tcpSendPause = 0;
uint16_t refreshDelayExtra=0;
ETSTimer tcpdriver_RefreshTimer;
ETSTimer tcpdriver_ResendAfterDisconnected;
static uint16_t tcpdriver_RefreshForceConnectNow=0;
/*
 * Matching by port, will return true if it is match.
 */
#define tcpMatchConn(pTcpConn,pespconn) ((((pespconn)->proto.tcp->remote_port==(pTcpConn)->remote_port) &&\
					((pespconn)->proto.tcp->local_port==(pTcpConn)->local_port)))

static void ICACHE_FLASH_ATTR tcpdriver_Refresh(void *arg);
/*
 * callback when finish sending last packet.
 */
static void ICACHE_FLASH_ATTR tcpdriver_sentcb(void *arg);

/*
 * callback when request reconnect
 */
static void ICACHE_FLASH_ATTR tcpdriver_reconncb(void *arg, sint8 err);
/*
 * append the data at the end of the pDest buffer.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_AppandData(uint8_t **pDest,
		uint16_t *pDestLen, uint8_t *pNewdata, uint16_t NewDataLen);
/*
 * Resent the data in the sending buffer
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_ResentNow(TcpConn_t *pTcpConn);
/*
 * send data in the SendBuffer and move it to sendingbuffer
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendNow(TcpConn_t *pTcpConn);
/*
 * callback when finish sending last packet.
 */
static void ICACHE_FLASH_ATTR tcpdriver_sentcb(void *arg);
/*
 * Callback when write finish
 */
static void ICACHE_FLASH_ATTR tcpdriver_writefinishcb(void *arg);
/*
 * Callback when data received
 */
static void ICACHE_FLASH_ATTR tcpdriver_receivedcb(void *arg, char *pdata,
		unsigned short len);
/*
 * Callback when connected
 */
static void ICACHE_FLASH_ATTR tcpdriver_connectedcb(void *arg);
/*
 * callback when disconnected
 */
static void ICACHE_FLASH_ATTR tcpdriver_disconncb(void *arg);
/*
 * callback when request reconnect
 */
static void ICACHE_FLASH_ATTR tcpdriver_reconncb(void *arg, sint8 err);
/*
 * Find a vacant slot in the TcpConn_t structure.
 * Return true if found the slot, else return false.
 */
uint16_t ICACHE_FLASH_ATTR GetVacantConn(uint16_t *pIndex);
/*
 * return the TcpConn structure base on the tcpLinkProp Reference
 * if pLinkRef=Null, will reset the counter.
 * continue call with the pLinkRef set, will find other tcpConn associated with the tcpLinkProp
 * will return Null is more tcpConn structure detected.
 */
TcpConn_t ICACHE_FLASH_ATTR *GetConnByLink(TcpLinkProp_t *pLinkRef);
/*
 * return pointer to tcpConn Structure by matching pespconn.
 */
TcpConn_t ICACHE_FLASH_ATTR *GetConnByEspConn(struct espconn *pespconn);

/*
 * Call to re-schedule resend data in the buffer after re-connected
 */
void ICACHE_FLASH_ATTR tcpdriver_ScheduleToResend(TcpConn_t *pTcpConn);

/*
 * Call once during system startup.
 */
void ICACHE_FLASH_ATTR tcpdriver_init(uint16_t extraDelay) {
	uint8_t macaddr[6];
	refreshDelayExtra=extraDelay;
	wifi_get_macaddr(STATION_IF, macaddr);

	//Disarm timer
	os_timer_disarm(&tcpdriver_RefreshTimer);
	//Setup timer
	os_timer_setfn(&tcpdriver_RefreshTimer,
			(os_timer_func_t *) tcpdriver_Refresh, &tcpdriver_RefreshForceConnectNow);
	//Arm timer for repeat every 1 sec.
	os_timer_arm(&tcpdriver_RefreshTimer, TcpRefreshDelay+refreshDelayExtra, 0);
}

/*
 * Find a vacant slot in the TcpConn_t structure.
 * Return true if found the slot, else return false.
 */
uint16_t ICACHE_FLASH_ATTR GetVacantConn(uint16_t *pIndex)
{
	int a;
	for (a = 0; a < MaxTcpConn; a++) {
		if (!tcpConn[a].pespconn) {
			(*pIndex) = a;
			os_memset(&tcpConn[a], 0, sizeof(TcpConn_t));
			return (1);
		}
	}
	return (0);
}

/*
 * Stop all tcp connection
 */
void ICACHE_FLASH_ATTR tcpdriver_ConnStop_All(void)
{
	int c;
	for (c=0;c<totalTcpLink;c++)
	{
		tcpdriver_ConnStop(tcpLinkProp[c]);
	}
}
TcpLinkProp_t ICACHE_FLASH_ATTR *tcpdriver_ConnRemoteSetup(uint32_t Remote_IP,
		int port)
{
	uint16_t tcpConnIndex;
	if (totalTcpLink < MaxTcpLink) {
		//still got blank space in the memory
		if (GetVacantConn(&tcpConnIndex)) {
			os_memset(&tcpConn[tcpConnIndex], 0, sizeof(TcpConn_t));

			if ((tcpLinkProp[totalTcpLink] = (TcpLinkProp_t*) os_zalloc(
					sizeof(TcpLinkProp_t)))) {
				os_memset(tcpLinkProp[totalTcpLink], 0, sizeof(TcpLinkProp_t));
				tcpLinkProp[totalTcpLink]->enabled = 0;
				tcpLinkProp[totalTcpLink]->connToRemote = 1; //0=local server, 1=connect remote
				tcpLinkProp[totalTcpLink]->espconn.proto.tcp =
						&tcpLinkProp[totalTcpLink]->ConnTcp;
				tcpLinkProp[totalTcpLink]->espconn.type = ESPCONN_TCP;
				tcpLinkProp[totalTcpLink]->espconn.state = ESPCONN_NONE;
				uint32_t ip = Remote_IP; //convert the ip text to number
				os_memcpy(
						tcpLinkProp[totalTcpLink]->espconn.proto.tcp->remote_ip,
						&ip, 4);
				tcpLinkProp[totalTcpLink]->espconn.proto.tcp->local_port =
						espconn_port();
				tcpLinkProp[totalTcpLink]->espconn.proto.tcp->remote_port =
						port;
				tcpConn[tcpConnIndex].pespconn =
						&(tcpLinkProp[totalTcpLink]->espconn);
				tcpConn[tcpConnIndex].pLinkRef = tcpLinkProp[totalTcpLink];

				espconn_regist_sentcb(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_sentcb);
				espconn_regist_reconcb(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_reconncb);
				espconn_regist_disconcb(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_disconncb);
				espconn_regist_connectcb(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_connectedcb);
				espconn_regist_recvcb(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_receivedcb);
				espconn_regist_write_finish(&(tcpLinkProp[totalTcpLink]->espconn),
						&tcpdriver_writefinishcb);
				totalTcpLink++;
				return (tcpLinkProp[totalTcpLink - 1]);
			}
		}
	}
	return (0);
}

/*
 * Start the connection
 */
void ICACHE_FLASH_ATTR tcpdriver_ConnStart(TcpLinkProp_t *pLinkRef) {
	uint16_t index;
	if (pLinkRef) {
		if (pLinkRef->enabled == 0) {
			pLinkRef->enabled = 1;

			if (pLinkRef->connToRemote) {
				if (wifictrl_IsLinkUp()) {

					//Start as Tcp client connect to server
					ESPConnectRemoteNow(&(pLinkRef->espconn));
				}
			} else {
				//Start as a Tcp server listen to incoming client
				espconn_accept(&(pLinkRef->espconn));

			}
		}

	}
}

/*
 * return the TcpConn structure base on the tcpLinkProp Reference
 * if pLinkRef=Null, will reset the counter.
 * continue call with the pLinkRef set, will find other tcpConn associated with the tcpLinkProp
 * will return Null is more tcpConn structure detected.
 */
TcpConn_t ICACHE_FLASH_ATTR *GetConnByLink(TcpLinkProp_t *pLinkRef) {
	//dpEnterFunc(dp_TcpDriver,"GetConnByLink");
	static uint16_t getConnByLink_ConnIndex = 0;
	if (pLinkRef) {
		while (getConnByLink_ConnIndex < MaxTcpConn) {
			if (tcpConn[getConnByLink_ConnIndex].pespconn
					&& tcpConn[getConnByLink_ConnIndex].pLinkRef == pLinkRef) {
				//found the tcpConn
				//dpPrintText(dp_TcpDriver,"found on index %d ",getConnByLink_ConnIndex);
				getConnByLink_ConnIndex++;
				//dpExitFunc(dp_TcpDriver);
				return (&(tcpConn[getConnByLink_ConnIndex - 1]));
			} else {
				getConnByLink_ConnIndex++;
			}
		}
	} else {
		getConnByLink_ConnIndex = 0;
	}
	//dpExitFunc(dp_TcpDriver);
	return (0);
}

/*
 * return pointer to tcpConn Structure by matching pespconn.
 */
TcpConn_t ICACHE_FLASH_ATTR *GetConnByEspConn(struct espconn *pespconn) {
	uint16_t index;
	for (index = 0; index < MaxTcpConn; index++) {
		if (tcpConn[index].pespconn && tcpConn[index].pespconn == pespconn) {
			return (&tcpConn[index]);
		}
	}
	return (0);
}
/*
 * Stop the connection
 */
void ICACHE_FLASH_ATTR tcpdriver_ConnStop(TcpLinkProp_t * pLinkRef) {
	uint16_t index;
	TcpConn_t *pTcpConn;
	if (pLinkRef) {
		if (pLinkRef->enabled) {
			pLinkRef->enabled = 0;
			GetConnByLink(0); //reset
			while ((pTcpConn = GetConnByLink(pLinkRef))) {
				if (pTcpConn->linkUp) {
					espconn_disconnect(pTcpConn->pespconn);
				}
			}
		}
	}
}

/*
 * Just disconnect the link, the link is still enable.
 */
void ICACHE_FLASH_ATTR tcpdriver_Disconnect(TcpLinkProp_t * pLinkRef) {
uint16_t index;
	TcpConn_t *pTcpConn;
	if (pLinkRef) {
		if (pLinkRef->enabled) {
			GetConnByLink(0); //reset
			while ((pTcpConn = GetConnByLink(pLinkRef))) {
				if (pTcpConn->linkUp) {
					espconn_disconnect(pTcpConn->pespconn);
				}
			}
		}
	}
}
/*
 * Get the LinkUp state.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_isLinkUp(TcpLinkProp_t *pLinkRef) {
	TcpConn_t *pTcpConn;
	if (pLinkRef) {
		if (pLinkRef->enabled) {
			GetConnByLink(0);
			while ((pTcpConn = GetConnByLink(pLinkRef))) {
				if (pTcpConn->linkUp) {
					return (1);
				}
			}
		}
	}

	return (0);
}

/*
 * Register data received callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_receive(TcpLinkProp_t *pLinkRef,
		void (*cb)(void *pTcpConn, char *pData, unsigned short len)) {
	if (pLinkRef) {
		pLinkRef->cbDataReceived = cb;
	}
}
/*
 * Register link connected callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_connected(TcpLinkProp_t *pLinkRef,
		void (*cb)(void *pTcpConn)) {
	if (pLinkRef) {
		pLinkRef->cbConnected = cb;
	}
}
/*
 * Register link disconnected callback
 */
void ICACHE_FLASH_ATTR tcpdriver_RegCB_disconnected(TcpLinkProp_t *pLinkRef,
		void (*cb)(void *pTcpConn)) {
	if (pLinkRef) {
		pLinkRef->cbDisconnected = cb;
	}
}

/************************************************************************************/

//append the data at the end of the pDest buffer.
uint16_t ICACHE_FLASH_ATTR tcpdriver_AppandData(uint8_t **pDest,
		uint16_t *pDestLen, uint8_t *pNewdata, uint16_t NewDataLen) {
	if ((*pDestLen)) {
		//already got data in the temp buf, need to add the new data into the old one
		uint8_t *ptmp = (uint8_t*) os_zalloc(NewDataLen + (*pDestLen));
		if (ptmp) {
			totalBuffSize += NewDataLen;
			os_memcpy(ptmp, (*pDest), (*pDestLen));
			os_memcpy(&(ptmp[(*pDestLen)]), pNewdata, NewDataLen);
			os_free((*pDest));
			(*pDest) = ptmp;
			(*pDestLen) += NewDataLen;
			return (1);
		}
	} else {
		//currently buffer is empty
		uint8_t *ptmp = (uint8_t*) os_zalloc(NewDataLen);
		if (ptmp) {
			totalBuffSize += NewDataLen;
			os_memcpy(ptmp, pNewdata, NewDataLen);
			(*pDest) = ptmp;
			(*pDestLen) = NewDataLen;
			return (1);
		}
	}
	return (0);
}

/*
 * send data in the SendBuffer and move it to sendingbuffer
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendNow(TcpConn_t *pTcpConn) {

	pTcpConn->pSendingBuf = pTcpConn->pSendBuf;
	pTcpConn->sendingBufLen = pTcpConn->sendBufLen;
	pTcpConn->pSendBuf = 0;
	pTcpConn->sendBufLen = 0;
	pTcpConn->sendBusy = 1;

	BlinkSendingData();

	if (espconn_sent(pTcpConn->pespconn, pTcpConn->pSendingBuf,
			pTcpConn->sendingBufLen)) {
		/*
		 * Sending fail, revert back the buffer.
		 */
		pTcpConn->pSendBuf = pTcpConn->pSendingBuf;
		pTcpConn->sendBufLen = pTcpConn->sendingBufLen;
		pTcpConn->pSendingBuf = 0;
		pTcpConn->sendingBufLen = 0;
		pTcpConn->sendBusy = 0;
		return (0);
	}
	return (1);
}

/************************* Sending Management **********************************/
/*
 * Resent the data in the sending buffer
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_ResentNow(TcpConn_t *pTcpConn)
{
	pTcpConn->sendBusy = 1;
	BlinkSendingData();
	if (espconn_sent(pTcpConn->pespconn, pTcpConn->pSendingBuf,
			pTcpConn->sendingBufLen))
	{
		/*
		 * Sending fail, revert back the buffer.
		 */
		pTcpConn->sendBusy = 0;
		return (0);
	}
	return (1);
}
/*
 * Send message refer by pLinkRef.
 * If the link is Server link, it will send the message out to all the currently connected
 * client.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendByLink(TcpLinkProp_t *pLinkRef,
		uint8_t *pdata, uint16_t len)
{
	TcpConn_t *pTcpConn;
	uint16_t returnresult = 0;
	if (pLinkRef) {
		GetConnByLink(0); //reset
		while ((pTcpConn = GetConnByLink(pLinkRef))) {
			if (pTcpConn->linkUp) {
				uint16_t result;
				result = tcpdriver_SendByConn(pTcpConn, pdata, len);
				if (result) {
					returnresult = 1;
				}
			}
		}
	}
	return (returnresult);
}

/*
 * Call to send the data out to destination refer by the TcpConn.
 */
uint16_t ICACHE_FLASH_ATTR tcpdriver_SendByConn(TcpConn_t *pTcpConn,
		uint8_t *pdata, uint16_t len)
{
	if (len == 0) {
		return (1);
	}
	if (!wifictrl_IsLinkUp() || (totalBuffSize + len) > MaxBuffSize) {
		return (0);
	}
	if (pTcpConn && pTcpConn->pespconn) {
		if (!pTcpConn->pLinkRef->enabled) {
			//connection is disabled, just return.
			return (0);
		}
		if (pTcpConn->sendBusy) {
			//currently busy sending
			if (tcpdriver_AppandData(&(pTcpConn->pSendBuf),
					&(pTcpConn->sendBufLen), pdata, len)) {
				//success kept in the send buffer
				return (1);
			}
		} else {
			if (pTcpConn->sendingBufLen) {
				//got data in the sending buff, need to resent.
				if (tcpdriver_ResentNow(pTcpConn)) {
					//able to resent, append the new data into the buffer
					if (tcpdriver_AppandData(&(pTcpConn->pSendBuf),
							&(pTcpConn->sendBufLen), pdata, len)) {
						//success kept in the send buffer
						return (1);
					}
				}
			} else if (pTcpConn->sendBufLen) {
				//got data in the send buf need to send first
				if (tcpdriver_SendNow(pTcpConn)) {
					//send success, insert the new data into the send buff.
					if (tcpdriver_AppandData(&(pTcpConn->pSendBuf),
							&(pTcpConn->sendBufLen), pdata, len)) {
						//success kept in the send buffer
						return (1);
					}
				}
			} else {
				//no data in the sendbuf and sendingBuf, so we just send out the data.
				pTcpConn->pSendBuf = (uint8_t*) os_zalloc(len);
				if (pTcpConn->pSendBuf) {
					totalBuffSize += len;
					os_memcpy(pTcpConn->pSendBuf, pdata, len);
					pTcpConn->sendBufLen = len;
					if (tcpdriver_SendNow(pTcpConn)) {
						return (1);
					}
				}
			}
		}
	}
	return (0);
}

/*
 * callback when finish sending last packet.
 */
static void ICACHE_FLASH_ATTR tcpdriver_sentcb(void *arg) {

	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpConnIndex;

	for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++) {
		if (tcpMatchConn(&tcpConn[tcpConnIndex], pespconn)) {
			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//is a server waiting for client connection
				tcpConn[tcpConnIndex].pespconn = pespconn;
			}
			//tcpConn[tcpConnIndex].keepAlive_timestamp=ms_count; //reset the keepalive timestamp
			if (tcpConn[tcpConnIndex].sendingBufLen) {
				//release memory for the sending buff.
				os_free(tcpConn[tcpConnIndex].pSendingBuf);
				tcpConn[tcpConnIndex].pSendingBuf=0;
				totalBuffSize -= tcpConn[tcpConnIndex].sendingBufLen;
				tcpConn[tcpConnIndex].sendingBufLen = 0;
				tcpConn[tcpConnIndex].sendBusy = 0;
			}
			if (tcpConn[tcpConnIndex].sendBufLen) {
				//got data in the send buf, need to send out now.
				tcpdriver_SendNow(&tcpConn[tcpConnIndex]);
			}
			break;
		}
	}
}
/*
 * Callback when write finish
 */
static void ICACHE_FLASH_ATTR tcpdriver_writefinishcb(void *arg) {
	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpConnIndex;
	for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++) {
		if (tcpMatchConn(&tcpConn[tcpConnIndex], pespconn)) {
			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//is a server waiting for client connection
				tcpConn[tcpConnIndex].pespconn = pespconn;
			}
			if (tcpConn[tcpConnIndex].pLinkRef->cbWriteFinish) {
				(*tcpConn[tcpConnIndex].pLinkRef->cbWriteFinish)(
						&tcpConn[tcpConnIndex]);
			}
			break;
		}

	}
}
/*
 * Callback when data received
 */
static void ICACHE_FLASH_ATTR tcpdriver_receivedcb(void *arg, char *pdata,
		unsigned short len) {
	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpConnIndex;

	for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++) {
		if (tcpMatchConn(&tcpConn[tcpConnIndex], pespconn)) {
			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//is a server waiting for client connection
				tcpConn[tcpConnIndex].pespconn = pespconn;
			}
			//tcpConn[tcpConnIndex].keepAlive_timestamp=ms_count; //reset the keepalive timestamp
			if (tcpConn[tcpConnIndex].pLinkRef->cbDataReceived) {
				(*tcpConn[tcpConnIndex].pLinkRef->cbDataReceived)(
						&tcpConn[tcpConnIndex], pdata, len);
			}
			break;
		}
	}
}
/*
 * Callback when connected
 */
static void ICACHE_FLASH_ATTR tcpdriver_connectedcb(void *arg) {


	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpLinkIndex;
	uint16_t tcpConnIndex;
	uint8_t found = 0;
	uint8_t foundconnslot = 0;

	//need to match in coming connect traffic to our TcpLinkProp_t structure
	for (tcpLinkIndex = 0; tcpLinkIndex < totalTcpLink; tcpLinkIndex++) {
		if (tcpLinkProp[tcpLinkIndex]->connToRemote) {
			//client connect to server match by pespconn
			if (&(tcpLinkProp[tcpLinkIndex]->espconn) == pespconn) {
				//this is a client connection
				//found the TcpLinkProp.
				found = 1;
				//the conn detail already in the tcpConn array.(
				for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn;
						tcpConnIndex++) {
					if (tcpConn[tcpConnIndex].pespconn == pespconn) {
						//found the slot keeping the conn info.
						/*
						if (tcpConn[tcpConnIndex].pSendBuf)
							os_free(tcpConn[tcpConnIndex].pSendBuf);
						tcpConn[tcpConnIndex].sendBufLen = 0;
						if (tcpConn[tcpConnIndex].pSendingBuf)
							os_free(tcpConn[tcpConnIndex].pSendingBuf);
						tcpConn[tcpConnIndex].sendingBufLen = 0;
						*/
						if (tcpConn[tcpConnIndex].pSendingBuf) {
							tcpdriver_ScheduleToResend(&tcpConn[tcpConnIndex]);
						}
						break;
						foundconnslot = 1;
					}
				}
				break;
			}
		} else {
			//test this Server connection by matching the local port.
			if ((tcpLinkProp[tcpLinkIndex]->espconn.proto.tcp->local_port
					== pespconn->proto.tcp->local_port)) {
				//found the TcpLinkProp.
				found = 1;

				//this is a server connection, need to find a vacant slot in TcpConn structure.
				if (!GetVacantConn(&tcpConnIndex)) {
					//no more vacant slot, close the connection.
					espconn_disconnect(pespconn);
					return;
				}

				//found the vacant conn slot, set it up

				tcpConn[tcpConnIndex].pespconn = pespconn;
				tcpConn[tcpConnIndex].pLinkRef = tcpLinkProp[tcpLinkIndex];

				tcpConn[tcpConnIndex].linkUp = 1;

				espconn_regist_sentcb(tcpConn[tcpConnIndex].pespconn, &tcpdriver_sentcb);
				espconn_regist_reconcb(tcpConn[tcpConnIndex].pespconn,
						&tcpdriver_reconncb);
				espconn_regist_disconcb(tcpConn[tcpConnIndex].pespconn,
						&tcpdriver_disconncb);
				espconn_regist_recvcb(tcpConn[tcpConnIndex].pespconn,
						&tcpdriver_receivedcb);
				espconn_regist_write_finish(tcpConn[tcpConnIndex].pespconn,
						&tcpdriver_writefinishcb);
				break;
			}
		}
	}
	if (found) {
		tcpConn[tcpConnIndex].remote_port = pespconn->proto.tcp->remote_port;
		tcpConn[tcpConnIndex].local_port = pespconn->proto.tcp->local_port;

		tcpConn[tcpConnIndex].sendBusy = 0;
		tcpConn[tcpConnIndex].linkUp = 1;

		if (tcpConn[tcpConnIndex].pLinkRef->cbConnected) {
			(*tcpConn[tcpConnIndex].pLinkRef->cbConnected)(
					&(tcpConn[tcpConnIndex]));
		}
	} else {
		//error, just disconnect
		espconn_disconnect(pespconn);
	}
}

/*
 * callback when disconnected
 */

static void ICACHE_FLASH_ATTR tcpdriver_disconncb(void *arg) {

	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpConnIndex;
	for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++) {
		if (tcpMatchConn(&tcpConn[tcpConnIndex], pespconn)) {
			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//is a server waiting for client connection
				tcpConn[tcpConnIndex].pespconn = pespconn;
			}
			if (tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//This is a Client Connection
				tcpConn[tcpConnIndex].linkUp = 0;
				tcpConn[tcpConnIndex].sendBusy = 0;
				tcpConn[tcpConnIndex].retryCount = 0;
				tcpConn[tcpConnIndex].retryPause = 1;
			}

			//Do the Application Callback.
			if (tcpConn[tcpConnIndex].pLinkRef->cbDisconnected) {
				(*tcpConn[tcpConnIndex].pLinkRef->cbDisconnected)(
						&(tcpConn[tcpConnIndex]));
			}

			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//This is a Server Connection, need to vacant the tcpConn.
				tcpConn[tcpConnIndex].pespconn = 0;
			}
			break;
		}

	}
	espconn_disconnect(pespconn);
}

/******************************************************************************/

/*
 * callback when request reconnect
 */
static void ICACHE_FLASH_ATTR tcpdriver_reconncb(void *arg, sint8 err) {
	struct espconn *pespconn = (struct espconn *) arg;
	uint16_t tcpConnIndex;
	uint16_t tcpLinkPropIndex;
	espconn_disconnect(pespconn);
	for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++) {
		if (tcpMatchConn(&tcpConn[tcpConnIndex], pespconn)) {
			if (!tcpConn[tcpConnIndex].pLinkRef->connToRemote) {
				//is a server waiting for client connection
				tcpConn[tcpConnIndex].pespconn = pespconn;
			} else //if (tcpLinkProp[tcpLinkPropIndex]->connToRemote)
			{
				//is a client connect to server, Need to do the reconnection
				tcpConn[tcpConnIndex].linkUp = 0;
				ESPConnectRemoteNow(pespconn);
			}
			if (tcpConn[tcpConnIndex].pLinkRef->cbReconnect) {
				(*tcpConn[tcpConnIndex].pLinkRef->cbReconnect)(
						&(tcpConn[tcpConnIndex]));
			}

			break;
		}
	}
}

//search all the enabled link and find the connection that is currently isLinkUp and
//do the callback with the link's TcpConn_t structure.
//only do this if wifi is up.
static void ICACHE_FLASH_ATTR SearchConnected(
		void (*pCallBackConnected)(void *arg),
		void (*pCallBackDisconnected)(TcpConn_t* pTcpConn))
{
	int tcpConnIndex;

	if (wifictrl_IsLinkUp()) {
		for (tcpConnIndex = 0; tcpConnIndex < MaxTcpConn; tcpConnIndex++)
		{
			if (tcpConn[tcpConnIndex].pespconn
					&& tcpConn[tcpConnIndex].pLinkRef->enabled)
			{
				if (tcpConn[tcpConnIndex].linkUp) {
					(*pCallBackConnected)(&tcpConn[tcpConnIndex]);
				}
				else
				{
					(*pCallBackDisconnected)(&tcpConn[tcpConnIndex]);
				}
			}
		}
	}
}

static void ICACHE_FLASH_ATTR RefreshConnectedLink(void *arg) {

	TcpConn_t *pTcpConn=(TcpConn_t*)arg;
	//link currently is up, send out the data in the send buffer
	if (pTcpConn->sendBusy == 0) {
		//not sending busy
		if (pTcpConn->sendingBufLen) {
			//got data in the sending buffer
			tcpdriver_ResentNow(pTcpConn);
		} else if (pTcpConn->sendBufLen) {
			//got data in the send buffer
			tcpdriver_SendNow(pTcpConn);		}
	}
}

/*
 * Call to re-schedule resend data in the buffer after re-connected
 */
void ICACHE_FLASH_ATTR tcpdriver_ScheduleToResend(TcpConn_t *pTcpConn)
{
	os_timer_disarm(&tcpdriver_ResendAfterDisconnected);
	os_timer_setfn(&tcpdriver_ResendAfterDisconnected,	(os_timer_func_t *) RefreshConnectedLink, pTcpConn);
	os_timer_arm(&tcpdriver_ResendAfterDisconnected, 200, 0);
}

static void ICACHE_FLASH_ATTR ConnNowDisconnectedLink(TcpConn_t *pTcpConn) {
	if (pTcpConn->pLinkRef->connToRemote) {
		//need to connect to remote server
		pTcpConn->retryPause = 0;
		pTcpConn->retryCount = 0;

		//This link is client need to connect to remote
		ESPConnectRemoteNow(pTcpConn->pespconn);
	}
}

static void ICACHE_FLASH_ATTR RefreshDisconnectedLink(TcpConn_t *pTcpConn) {
	if (pTcpConn->pLinkRef->connToRemote) {
		//need to connect to remote server
		if (pTcpConn->retryPause == 0) {
			//now is not in pause mode. make sure still in the retry period.
			if (pTcpConn->retryCount >= RetryConn_ConnCount) {
				//end of retry connect period. now need to go into retry pause mode.
				pTcpConn->retryPause = 1;
				pTcpConn->retryCount = 0;
				espconn_disconnect(pTcpConn->pespconn);
			} else {
				pTcpConn->retryCount++;
			}
		} else {
			//now is in retry pause, check if reach the end of the pause period
			if (pTcpConn->retryCount >= RetryConn_PauseCount) {
				//end of pause period. now need to go into retry pause mode.
				pTcpConn->retryPause = 0;
				pTcpConn->retryCount = 0;

				//This link is client need to connect to remote
				ESPConnectRemoteNow(pTcpConn->pespconn);
			}
			else {
				pTcpConn->retryCount++;
			}
		}
	}
}

/*
 * Call to request connect now all the connection
 */
void ICACHE_FLASH_ATTR tcpdriver_connectnow(void)
{
	tcpdriver_RefreshForceConnectNow=1;
	os_timer_disarm(&tcpdriver_RefreshTimer);
	os_timer_arm(&tcpdriver_RefreshTimer, 50+refreshDelayExtra, 0);
}

/*
 * Will be call regularly to do  any clean up.
 */
static void ICACHE_FLASH_ATTR tcpdriver_Refresh(void *arg) {
	uint16_t *pConnectNow=(uint16_t*)arg;
	os_timer_disarm(&tcpdriver_RefreshTimer);
	os_timer_arm(&tcpdriver_RefreshTimer, TcpRefreshDelay+refreshDelayExtra, 0);
	if (pConnectNow[0])
	{
		pConnectNow[0]=0;
		SearchConnected(&RefreshConnectedLink, &ConnNowDisconnectedLink);
	}
	else
	{
		SearchConnected(&RefreshConnectedLink, &RefreshDisconnectedLink);
	}
}


