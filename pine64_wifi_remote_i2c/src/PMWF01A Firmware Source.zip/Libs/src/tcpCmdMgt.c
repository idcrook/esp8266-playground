/*
 * tcpCmdMgt.c
 *
 *  Created on: Mar 8, 2016
 *      Author: khgoh
 */

#include "tcpdriver.h"
#include "ets_sys.h"
#include "os_type.h"
#include "osapi.h"
#include "mem.h"
#include "board.h"
#include "pktcreate.h"
#include "dprint.h"
#include "tcpCmdMgt.h"
#include "board.h"
#include "cfgmgt.h"

typedef struct{
	uint8_t busy;
	uint8_t cmd;
	uint8_t *pData; //must call os_free to free up the memory
	uint8_t size; //pdata size
	void *cbm_pcurrProcessTcpConn;
}rxTcpCmdProp_t;

#define IdleCheckTimeOut	60 //in sec

ETSTimer tcpCmdMgt_ProcessCmd;
ETSTimer tcpScanIOPort;
ETSTimer tcpIdleDisconnect;
uint8_t tcpCmdMgt_RxByte[256];
uint16_t tcpCmdMgt_RxByteLen;
uint8_t tcpCmdMgt_RxBusy=0;
uint8_t tcpCmdMgt_currProcessCmd=cmd_nop;
void *cbm_pcurrProcessTcpConn=0; //keep the current process tcp ptr.
extern TcpLinkProp_t *pClientRef; //declare in Serverlink.c
uint8_t i2cstarted=0;
rxTcpCmdProp_t rxTcpCmdProp;

void tcpIdleDisconnetcheck(void *arg);
uint8_t idlecheckCnt=0;

/*
 * Process the tcp command
 */
void ICACHE_FLASH_ATTR ProcTcpCmd(void *arg);
/*
 * Regularly scan the input port for changes.
 * will push result back to host
 */
void ICACHE_FLASH_ATTR ProcScanInputPort(void *arg);

void ICACHE_FLASH_ATTR tcpCmdMgt_init(void)
{
	os_timer_disarm(&tcpCmdMgt_ProcessCmd);
    os_timer_setfn(&tcpCmdMgt_ProcessCmd, (os_timer_func_t *)ProcTcpCmd, NULL);
    os_memset(&rxTcpCmdProp,0,sizeof(rxTcpCmdProp_t));

    os_timer_disarm(&tcpScanIOPort);
    os_timer_setfn(&tcpScanIOPort, (os_timer_func_t *)ProcScanInputPort, NULL);
    os_timer_arm(&tcpScanIOPort, 50, 1);

    os_timer_disarm(&tcpIdleDisconnect);
	os_timer_setfn(&tcpIdleDisconnect, (os_timer_func_t *)tcpIdleDisconnetcheck, NULL);
	os_timer_arm(&tcpIdleDisconnect, 1000, 1);

    Board_ConfigGPIO(0x3f,syscfg.gpioCfgStatus,0);
    if (syscfg.i2cenable)
    {
    	i2cstarted=1;
    	i2c_master_gpio_init();
    }
    dPrintText("i2cenable %d, pwmenable %d, iomask %02x",syscfg.i2cenable,syscfg.pwnenable,syscfg.gpioCfgStatus);
}

/*
 * Process the tcp command
 */
void ICACHE_FLASH_ATTR ProcTcpCmd(void *arg) {
	uint8_t *tmpbyte;
	uint8_t iomask, iostatus;
	dPrintText("cmd %02x size %d:",rxTcpCmdProp.cmd,rxTcpCmdProp.size);
	if (rxTcpCmdProp.size) dPrintByte(rxTcpCmdProp.pData,rxTcpCmdProp.size);
	dPrintText("\n");
	os_timer_disarm(&tcpCmdMgt_ProcessCmd);
	cbm_pcurrProcessTcpConn=rxTcpCmdProp.cbm_pcurrProcessTcpConn;
	tcpCmdMgt_currProcessCmd=rxTcpCmdProp.cmd;

	switch(rxTcpCmdProp.cmd){
	case cmd_i2cpoll:
		if (!i2cstarted){
			TcpReplyWithNACK();
			break;
		}
		if (I2CGen_polldev((rxTcpCmdProp.pData[0]<<1)))
		{
			TcpReplyWithACK();
		}
		else
		{
			TcpReplyWithNACK();
		}
		break;

	case cmd_i2cenable:
		if (!i2cstarted) {
			i2c_master_gpio_init();
			dPrintText("i2cEnabled\n");
			i2cstarted=1;
			syscfg.i2cenable=1;
			cfgsaveflash(&syscfg,sizeof(syscfg_t));
		}
		TcpReplyWithACK();
		break;
	case cmd_i2cdisable:
		if (i2cstarted)
		{
			i2cstarted=0;
			syscfg.i2cenable=0;
			i2c_master_gpio_uninit();
			cfgsaveflash(&syscfg,sizeof(syscfg_t));
			Board_ConfigGPIO(0x3f,syscfg.gpioCfgStatus,0);
		}
		TcpReplyWithACK();
		break;
	case cmd_i2cread:
		if (!i2cstarted || rxTcpCmdProp.size <3){
			TcpReplyWithNACK();
			break;
		}
		if (pktc_request(&tmpbyte,rxTcpCmdProp.pData[2])) {
			dPrintText("i2cRead: %02x %02x %02x : ",rxTcpCmdProp.pData[0],rxTcpCmdProp.pData[1],rxTcpCmdProp.pData[2]);
			if (I2CGen_readPage((rxTcpCmdProp.pData[0]<<1),rxTcpCmdProp.pData[1],tmpbyte,rxTcpCmdProp.pData[2]))
			{
				dPrintByte(tmpbyte,rxTcpCmdProp.pData[2]);
				dPrintText("\n");

				tcpCmdMgt_SendReply_SendNow(TCP_ACK);
			}
			else {
				pktc_done();
				TcpReplyWithNACK();
			}
		}
		else {
			TcpReplyWithNACK();
		}
		break;
	case cmd_i2cwrite:
		if (!i2cstarted || rxTcpCmdProp.size < 3 || rxTcpCmdProp.size < (2+rxTcpCmdProp.pData[2])){
			TcpReplyWithNACK();
			break;
		}
		if (I2CGen_writePage((rxTcpCmdProp.pData[0]<<1),rxTcpCmdProp.pData[1],&rxTcpCmdProp.pData[3],rxTcpCmdProp.pData[2]))
		{
			TcpReplyWithACK();
		}
		else
		{
			TcpReplyWithNACK();
		}
		break;
	case cmd_cfgport:
		/*
		 * IOMask: 0 = Ignore bit status, 1=Set Bit status
		 * IOStatus : 0 = As Output Port, 1 = As Input Port
		 */
		if (rxTcpCmdProp.size < 2){
			TcpReplyWithNACK();
			break;
		}
		iomask=rxTcpCmdProp.pData[0];
		iostatus=rxTcpCmdProp.pData[1];
		iomask&=0x3F; //allow bit0 to bit5

		iostatus=Board_ConfigGPIO(iomask,iostatus,syscfg.gpioCfgStatus);
		dPrintText("gpioCfgStatus: old %02x new %02x ",syscfg.gpioCfgStatus,iostatus);
		//keep the latest setting in the flash.
		if (syscfg.gpioCfgStatus!=iostatus)
		{
			syscfg.gpioCfgStatus=iostatus;
			cfgsaveflash(&syscfg,sizeof(syscfg_t));
			dPrintText("Updated");
		}
		dPrintText("\r\n");
		TcpReplyWithACK();
		break;
	default:
		TcpReplyWithNACK();
		break;
	}
	if (rxTcpCmdProp.size>0)
	{
		os_free(rxTcpCmdProp.pData);
	}
	rxTcpCmdProp.busy=0;
}
/*
 * Callback function when connected to a remote connection
 */
void ICACHE_FLASH_ATTR tcpCmdMgt_Connected(void *pTcpConn)
{
	uint8_t *ptmp;
	cbm_pcurrProcessTcpConn=pTcpConn;
	if(pktc_request(&ptmp,6)) {
		tcpCmdMgt_currProcessCmd=Cmd02_HWINFO;
		ptmp[0]=(FWID >> 8)&0xff;
		ptmp[1]=FWID&0xff;
		ptmp[2]=FWV_YY;
		ptmp[3]=FWV_MM;
		ptmp[4]=FWV_DD;
		ptmp[5]=FWV_REV;
		tcpCmdMgt_SendReply_SendNow(TCP_ACK);
	}
	else {
		//something is wrong, just disconnect and reboot.
		tcpdriver_ConnStop(pClientRef);
		Board_SystemRestart();
	}
	idlecheckCnt=0;
}
/*
 * Callback function when received a tcp packet
 */
void ICACHE_FLASH_ATTR tcpCmdMgt_Rx(void *pTcpConn,char *pdata, unsigned short len)
{
	uint8_t* pResult;
	uint8_t* pCmdData;
	uint16_t size;
	uint8_t iomask, iostatus;

	dPrintText("Rx data size %d:",len);
	dPrintByte(pdata,len);
	cbm_pcurrProcessTcpConn=pTcpConn;
	idlecheckCnt=0;
	if (!rxTcpCmdProp.busy && pktc_rxPecket(pdata,&pResult,&pCmdData,&size)){
		rxTcpCmdProp.cbm_pcurrProcessTcpConn=pTcpConn;
		rxTcpCmdProp.cmd=pCmdData[0];
		rxTcpCmdProp.size=size-1;
		rxTcpCmdProp.pData=pCmdData+1;
		tcpCmdMgt_currProcessCmd=rxTcpCmdProp.cmd;

		switch(rxTcpCmdProp.cmd){
		case cmd_nop:
			TcpReplyWithACK();
			break;

		case cmd_relay:
			if (rxTcpCmdProp.size < 1){
				TcpReplyWithNACK();
				break;
			}
			if (rxTcpCmdProp.pData[0]){
				//turn on the relay
				RELAY_ON();
			}
			else
			{
				//turn off the relay
				RELAY_OFF();
			}
			TcpReplyWithACK();
			break;
			/*
			 * Following section is done off line because it might too long to finish the job.
			 */
		case cmd_setio:
			/*
			 * data: IO Mask, IO Status
			 * Bit0 : GPIO5/nINT
			 * Bit1 : GPIO2/SDA
			 * Bit2 : GPIO14/SCL
			 * Bit3 : GPIO15
			 * Bit4 : GPIO13
			 * Bit5 : GPIO12
			 *
			 * IOMask: 0 = Ignore bit status, 1=Set Bit status
			 * IOStatus : 0 = Output Low, 1 = Output High
			 *
			 * When I2c port is started, Bit0 to Bit2 will be ignore
			 */
			if (rxTcpCmdProp.size < 2){
				TcpReplyWithNACK();
				break;
			}
			iomask=rxTcpCmdProp.pData[0];
			iostatus=rxTcpCmdProp.pData[1];
			iomask&=0x3F; //allow bit0 to bit5
			if (i2cstarted) {
				iomask &= 0xF8; //ignore bit0 to bit3
			}
			Board_SetGPIO(iomask,iostatus);
			TcpReplyWithACK();
			break;

		case cmd_i2cpoll:
		case cmd_i2cenable:
		case cmd_i2cdisable:
		case cmd_cfgport:
		case cmd_i2cread:
		case cmd_i2cwrite:
			if (rxTcpCmdProp.size>0) {
				if ((rxTcpCmdProp.pData=(uint8_t*)os_malloc(size))) {
					rxTcpCmdProp.busy=1;
					os_memcpy(rxTcpCmdProp.pData,pCmdData+1,size);
					os_timer_arm(&tcpCmdMgt_ProcessCmd, 1, 0);
				}
				else {
					TcpReplyWithNACK();
				}
			}
			else
			{
				rxTcpCmdProp.busy=1;
				os_timer_arm(&tcpCmdMgt_ProcessCmd, 1, 0);

			}
			break;
		default:
			TcpReplyWithNACK();
			break;
		}

	}
}
uint8_t preI2cIntr=0; //0=not trigger, 1=trigger.
/*
 * Regularly scan the input port for changes.
 * will push result back to host
 */
void ICACHE_FLASH_ATTR ProcScanInputPort(void *arg)
{
	uint8_t mask,status;
	uint8_t *tmpbyte;
	uint16_t pktsize;

	//Check all the input port
	if (Board_DetectInputPortChanges(&mask,&status)) {
		//if the changes on the input status,
		//will send it out to the host.
		if (pktc_request(&tmpbyte,2)) {
			tmpbyte[0]=mask;
			tmpbyte[1]=status;
			pktc_create((uint8_t)TCP_ACKRT2, Cmd33_PUSH_IP_STATUS);
			tcpdriver_SendByLink(pClientRef, pktc_Get(&pktsize),pktsize);
			pktc_done();
		}
	}

	//check the i2c nIntr Pin trigger condition.
	if (i2cstarted)
	{
		if (!GPIO_INPUT_GET(GPIO_nINT)) {
			//low detected (trigger)
			if (!preI2cIntr) {
				//previously not trigger, need to trigger it now.
				preI2cIntr=1;
				if (pktc_request(&tmpbyte,0)) {
					pktc_create((uint8_t)TCP_ACKRT2, Cmd16_I2cIntr);
					tcpdriver_SendByLink(pClientRef, pktc_Get(&pktsize),pktsize);
					pktc_done();
				}
			}
		}
		else {
			//not trigger, just clear the intr trigger flag
			preI2cIntr=0;
		}
	}
}

/*
 * Call to send the data.
 */
uint8_t ICACHE_FLASH_ATTR tcpCmdMgt_SendReply_SendNow(tcpAckState tcpAckResult)
{
	uint16_t pktSize;
	uint8_t sendResult;
	pktc_create((uint8_t)tcpAckResult, tcpCmdMgt_currProcessCmd);
	sendResult=tcpdriver_SendByConn(cbm_pcurrProcessTcpConn, pktc_Get(&pktSize),pktSize);
	pktc_done();
	return(sendResult);
}
void ICACHE_FLASH_ATTR tcpIdleDisconnetcheck(void *arg)
{
	idlecheckCnt++;
	if (idlecheckCnt>=IdleCheckTimeOut){
		tcpdriver_Disconnect(pClientRef);
	}
}
