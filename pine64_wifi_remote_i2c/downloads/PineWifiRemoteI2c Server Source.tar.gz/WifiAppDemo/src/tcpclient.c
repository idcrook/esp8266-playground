/*
 * tcpclient.c
 *
 *  Created on: Apr 12, 2016
 *      Author: khgoh
 */

#include "tcpclient.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "TimerMgr.h"
#include "PollMgr.h"

#define TCPRefreshTime 200 	//in ms

static char tcpc_server[256];			//server address
static int tcpc_portno;				//Server port number
static void (*pRxConnCB)(int fd, short int, void *ptr); 	//on received data Callback
static void (*pConnnectedCB)(int fd)=0;		//First Connected Callback
static void *cbPtr;							//keep the pointer to be include in the received data callback.
static int csfd;							//current connected socket FD
static unsigned char tcpc_suspend=1;			//indicate the connected is suppended by caller app
static unsigned char tcpc_connected=0;		//indicate current connection state
static char tcpc_connecting=0;				//indicate currently is under connect() state
static char tcpc_alreadyconnected=0;
static int tcpc_sockfd=0;						//temp socket FD used during connect() state.
static int csTimerID;
static void tcpc_Refresh(int timerid, void *ptr);
static unsigned int tcpc_RetryConnCnt=0;

//call to close the connection
//please make sure is currently connect before calling close
#define CloseConn() do{\
		close(csfd);\
		PollMgr_Remove(csfd);\
		tcpc_connected=0;\
	} while(0)

/*
 * Call to create a connection with a server
 * return fd if is connected, else return 0
 */
void ConnServerNow(char *strServerAddr, int portno);

/*
 * Set the connected callback
 */
void tcpc_SetConnectedCB(void (*pFirstConnnectedCB)(int fd))
{
	pConnnectedCB=pFirstConnnectedCB;
}
/*
 * Call to init the server connect
 */
void tcpc_Init(char *server,char *portno, void (*rxCallback)(int fd, short int event,void *ptr), void *ptr)
{
	pRxConnCB=rxCallback;
	strcpy(tcpc_server,server);
	tcpc_portno = atoi(portno);
	cbPtr=ptr;
	tcpc_suspend=0;
	csTimerID=TimerMgr_Create("ConnServ",TCPRefreshTime,1,&tcpc_Refresh,NULL);
	TimerMgr_Start(csTimerID);
}

/*
 * return current connect state.
 */
unsigned int tcpc_isConnected(void)
{
	return(tcpc_connected);
}

/*
 * Call regularly
 */
static void tcpc_Refresh(int timerid, void *ptr)
{
	if (!tcpc_suspend) {
		if (!tcpc_connected && !tcpc_alreadyconnected)
		{
			ConnServerNow(tcpc_server,tcpc_portno);
		}
	}
}

/*
 * if return true, system should exit/end
 */
unsigned int tcpc_isEndded(void) {
	if (!tcpc_connected && tcpc_alreadyconnected)
	{
		return(1);
	}
	return(0);
}

/*
 * Call the write data into the connection
 * Return number of byte send out.
 */
unsigned int tcpc_Write(unsigned char *pData, unsigned int size)
{
	int n;
	if (tcpc_connected){
		char data;
		/*
		 * Check if the link is still connected before sending
		 */
		ssize_t x=recv(csfd,&data,1, MSG_PEEK | MSG_DONTWAIT);
		if (x==0) {
			CloseConn();
			return(0);
		}

		n = send(csfd,pData,size,0 );
		if (n < 0)
		{
			//write error, close it and return;
			CloseConn();
			return(0);
		}
		return(n);
	}
	return(0);
}
/*
 * Restart the connection after tcpc_Close() is called
 */
void tcpc_Resume()
{
	tcpc_suspend=0;
}

/*
 * Close the connection if currently connected and
 * restart connection.
 * On Next refresh, it will start to reconnect
 * It will also clear suspend flag if previously call tcpc_close.
 */
void tcpc_reconnect()
{
	if (tcpc_connected){
		CloseConn();
	}
	tcpc_suspend=0;
}

/*
 * Close and suspend the connection until tcpc_Resume() is called
 */
void tcpc_Close()
{
	if (tcpc_connected){
		CloseConn();
	}
	tcpc_suspend=1;
}


/*
 * Call to create a connection with a server
 * return fd if is connected, else return 0
 */
void ConnectNowRefresh(void)
{
	int res;
	struct timeval tv;
	long arg;
	int valopt;
	socklen_t lon;
	fd_set tcpc_connset;

	if (tcpc_connecting)
	{

		tv.tv_sec=0;tv.tv_usec=0;
		FD_ZERO(&tcpc_connset);
		FD_SET(tcpc_sockfd, &tcpc_connset);
		res = select(tcpc_sockfd+1,NULL, &tcpc_connset , NULL, &tv);

		if (res < 0 && errno != EINTR)
		{
			tcpc_connecting=0;
			close(tcpc_sockfd);
			return;
		}
		else if (res > 0)
		{
			tcpc_connecting=0;
			lon = sizeof(int);
			if (getsockopt(tcpc_sockfd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon) < 0) {
				 close(tcpc_sockfd);
				 return;
			}
			if (valopt)
			{
				 close(tcpc_sockfd);
			     return;
			}


			//set it back to blocking.
			arg = fcntl(tcpc_sockfd, F_GETFL, NULL);
			arg &= (~O_NONBLOCK);
			fcntl(tcpc_sockfd, F_SETFL, arg);

			tcpc_connected=1;
			tcpc_alreadyconnected=1;
			csfd=tcpc_sockfd;
			PollMgr_Insert("ConnServer",tcpc_sockfd,POLLIN,pRxConnCB,cbPtr);
			if (pConnnectedCB) (*pConnnectedCB)(tcpc_sockfd);
		}
	}
}

void ConnServerNow(char *strServerAddr, int portno)
{
	struct sockaddr_in serv_addr;
	struct hostent *server;
	int connresult;
	int keepalive = 1;
	int tcpnodelay=1;
	long arg;
	char tmpServerAddr[256];
	char *pTmpServerAddr;
	char *pTmpServerAddr2;
	if (tcpc_connecting)
	{
		ConnectNowRefresh();
		return;
	}

	tcpc_RetryConnCnt++;
	tcpc_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (tcpc_sockfd < 0)
	{
		//unable to allocate socket fd
		return;
	}
	strcpy(tmpServerAddr,strServerAddr);
	//remove the 'http://' in the server address
	pTmpServerAddr=strstr(tmpServerAddr,"http://");
	if (pTmpServerAddr) {
		//found 'http://' word in the address, need to skip it.
		pTmpServerAddr=&pTmpServerAddr[7];
	}
	else {
		//did not find the key word. address start from the beginig
		pTmpServerAddr=tmpServerAddr;
	}

	//remove any trailing command from the server address
	pTmpServerAddr2=strpbrk(pTmpServerAddr,":?/");
	if (pTmpServerAddr2){
		pTmpServerAddr2[0]=0; //put a null at the char to mark the end of the server addr
	}
	server = gethostbyname(pTmpServerAddr);
	if (server == NULL) {
		//server address not valid.
		close(tcpc_sockfd);
		return;
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char *)server->h_addr,
		         (char *)&serv_addr.sin_addr.s_addr,
		         server->h_length);
	serv_addr.sin_port = htons(portno);
	setsockopt(tcpc_sockfd,SOL_SOCKET,SO_KEEPALIVE,&keepalive , sizeof(keepalive ));
	setsockopt(tcpc_sockfd, IPPROTO_TCP, TCP_NODELAY, &tcpnodelay, sizeof(tcpnodelay));

	arg=fcntl(tcpc_sockfd, F_GETFL, NULL);
	arg |= O_NONBLOCK;
	fcntl(tcpc_sockfd, F_SETFL, arg);
	connresult=connect(tcpc_sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr));
	if ( connresult < 0 && errno == EINPROGRESS)
	{
		//halfway connection
		tcpc_connecting=1;
		return;
	}
	//unable to connect, close the fd reconnect on next retry.
	close(tcpc_sockfd);
	return;
}
