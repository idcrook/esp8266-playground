/*
 * DriverMgr.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */



#include "DriverMgr.h"
#include "DriverI2c.h"
#include "globe.h"
#include "clientfunction.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "tcpclient.h"

typedef struct{
	uint8_t i2cid;
	void (*refreshCB)(clientprop_t*);
	void (*replyCB)(clientprop_t*,char **token, int tokenCnt);
	void (*cmdtimeoutCB)(clientprop_t*);
	void (*remotedisconnectedCB)(clientprop_t*);
	void (*resetallCB)(clientprop_t*);
}drivermgt_t;

drivermgt_t *pDriverMgt[MaxDriver];
uint16_t totalI2cDriver=0;
clientprop_t *pCurrProcessClient;
char *pSendBuffer=0;
unsigned int (*pSendCmdCB)(char *pData,unsigned int size)=NULL;

/*
 * List down all the init function for i2c driver.
 */
void (*pDrvInitFunction[])(void) = {
		&DrvI2cInit_init,
		&DrvLight_init,
		&DrvHumidity_init,
};

//call to send out data in the send buffer.
void SendOutBufferNow(void);
/*
 * Call once during startup
 */
void Dmgr_Init(unsigned int (*pSendCmdCallBack)(char *pData,unsigned int size))
{
	int c;
	int drivercnt=sizeof(pDrvInitFunction)/sizeof(void*);
	pSendCmdCB=pSendCmdCallBack;
	for(c=0;c<MaxDriver;c++) pDriverMgt[c]=0;
	for(c=0;c<drivercnt;c++) (*pDrvInitFunction[c])();
}

/*
 * register the i2c driver, on success, it will return the drivermgrSequence number
 */
int DMgr_RegisterDriver(uint8_t i2cid,
		void (*refreshCB)(clientprop_t*), //call once in the fix interval
		void (*replyCB)(clientprop_t*,char **token, int tokenCnt), // call when remote client reply
		void (*cmdtimeoutCB)(clientprop_t*), //call when received timeout notice
		void (*remoteClientDisconnectedCB)(clientprop_t*),
		void (*resetAllCB)(clientprop_t*))

{
	if (totalI2cDriver<MaxDriver) {
		pDriverMgt[totalI2cDriver]=(drivermgt_t*)malloc(sizeof(drivermgt_t));
		if (pDriverMgt[totalI2cDriver]) {
			memset(pDriverMgt[totalI2cDriver],0,sizeof(drivermgt_t));
			pDriverMgt[totalI2cDriver]->i2cid=i2cid;
			pDriverMgt[totalI2cDriver]->refreshCB=refreshCB;
			pDriverMgt[totalI2cDriver]->replyCB=replyCB;
			pDriverMgt[totalI2cDriver]->cmdtimeoutCB=cmdtimeoutCB;
			pDriverMgt[totalI2cDriver]->remotedisconnectedCB=remoteClientDisconnectedCB;
			pDriverMgt[totalI2cDriver]->resetallCB=resetAllCB;
			totalI2cDriver++;
			return(totalI2cDriver-1);
		}
	}
	return(-1);
}

/*
 * Create, get and release I2c Device properties storage area under
 * the connected remote Client
 */
void *DMgr_CreateDevicePropertiesStorage(int storageSize)
{
	void *ptr;
	if (!pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber])
	{
		//only create memory if not yet created.
		ptr=(void*)malloc(storageSize);
		if (ptr) {
			memset(ptr,0,storageSize);
			pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]=ptr;
		}
	}
	return(pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]);
}

void DMgr_ReleaseDevicePropertiesStorage(clientprop_t *pClientProp, int driverID)
{
	if (driverID>=0) {
		if (pClientProp->pDeviceSetting[driverID])
		{
			free(pClientProp->pDeviceSetting[driverID]);
			pClientProp->pDeviceSetting[driverID]=NULL;
		}
	}
}
void *DMgr_GetDevicePropertiestStorage(void)
{
	return(pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]);
}

/*
 * Return Device Properties structure. App Require to Cast the return pointer
 */
void *DMgr_GetDeviceProperties(int remoteClientRef, int DeviceID)
{
	if (remoteClientRef==-1 || DeviceID==-1) return(NULL);
	clientprop_t *cprop=GetClientProp(remoteClientRef);
	if (cprop){
		return(cprop->pDeviceSetting[DeviceID]);
	}
	return(NULL);
}

/*
 * will do the callback on each remote client with the drivermgrsequence
 */
void DriverRefresh(void)
{
	int clientref;
	int repeatcnt=0;

	for (clientref=0;clientref<GetTotalClient();clientref++)
	{
		repeatcnt=0;
		clientprop_t *pClientProp=GetClientByIndex(clientref);
		do {
			if (pClientProp && totalI2cDriver) {
				//check for pending reply time out
				if (pClientProp->i2cPandingReply){
					pClientProp->i2cReplyWaitingCnt++;
					if (pClientProp->i2cReplyWaitingCnt>(SensorReplyTimeout/SensorDevicePollRate))
					{
						DMgr_ClientCmdTimeout(pClientProp);
					}
				}
				else
				{
					//currently not pending reply.
					if (pClientProp->CurrDriverIndexNumber>=totalI2cDriver) {
						//not suppose to happen, we will reset everything
						pClientProp->CurrDriverIndexNumber=0;
						pClientProp->i2ccmdstep=stepstart;
					}
					else if (pClientProp->i2ccmdstep==stepdone) {
						//goto next sequence number and reset the i2ccmdstep to stepstart
						pClientProp->CurrDriverIndexNumber++;
						if (pClientProp->CurrDriverIndexNumber>=totalI2cDriver) pClientProp->CurrDriverIndexNumber=0;
						pClientProp->i2ccmdstep=stepstart;
					}
					//do the callback for the driver.
					if (pClientProp->i2ccmdstep==stepstart && pClientProp->online &&  pDriverMgt[pClientProp->CurrDriverIndexNumber]->refreshCB) {
						pCurrProcessClient=pClientProp;
						(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->refreshCB)(pClientProp);

						if (pClientProp->i2ccmdstep==stepdone) {
							//the driver did not send any think, we will repeat again with the next i2cdriver.
							repeatcnt++;
						}
						else {
							repeatcnt=0;
						}
					}
				}
			}
		} while(repeatcnt && repeatcnt<totalI2cDriver); //will exit the loop is no need repeat or already repeat for all driver.
	}
	SendOutBufferNow();
}

//call to send out data in the send buffer.
void SendOutBufferNow(void) {
	unsigned int size,sendsize;
	char *tmpstr;
	if (pSendBuffer && (size=strlen(pSendBuffer))>0)
	{
		if (pSendCmdCB) {
			sendsize=(*pSendCmdCB)(pSendBuffer,size);
			if (size-sendsize) {
				//unable to finish sending
				tmpstr=(char*)malloc(size-sendsize+1);
				if (tmpstr) {
					strcpy(tmpstr,&pSendBuffer[sendsize]);
					free(pSendBuffer);
					pSendBuffer=tmpstr;
				}
				else {
					//unable to allocate memory, just clear it.
					free(pSendBuffer);
					pSendBuffer=NULL;
				}
			}
			else {
				//all the byte is send out, clear it.
				free(pSendBuffer);
				pSendBuffer=NULL;
			}
		}
		else {
			//all the byte is send out, clear it.
			free(pSendBuffer);
			pSendBuffer=NULL;
		}
	}
}

/*
 * return true is current process i2c device is online
 * Only allow to call this function during driver callback.
 */
int DMgr_isDeviceOnline(void)
{
	return (pCurrProcessClient->i2cDevOnline[pCurrProcessClient->CurrDriverIndexNumber]);
}
void DMgr_SetDeviceOnline(void)
{
	pCurrProcessClient->i2cDevOnline[pCurrProcessClient->CurrDriverIndexNumber]=1;
}
void DMgr_SetDeviceOffline(void)
{
	pCurrProcessClient->i2cDevOnline[pCurrProcessClient->CurrDriverIndexNumber]=0;
}
/*
 * Call when client just online
 */
void DMgr_ClientOnline(clientprop_t* pClientProp)
{
	pClientProp->CurrDriverIndexNumber=0;
	pClientProp->i2ccmdstep=stepstart;
}

/*
 * Call when client just offline
 */
void DMgr_ClientOffline(clientprop_t* pClientProp)
{
	int c;
	pClientProp->CurrDriverIndexNumber=0;
	pClientProp->i2ccmdstep=stepstart;
	pClientProp->i2cready=0;
	for (c=0;c<totalI2cDriver;c++){
		if (pDriverMgt[c] && pDriverMgt[c]->remotedisconnectedCB) {
			(*pDriverMgt[c]->remotedisconnectedCB)(pClientProp);
		}
	}
}

/*
 * request to send the command string.
 * return true if able to insert the cmdString into the send buffer.
 */
int DMgr_DriverSend(char *cmdString, char *attbString)
{
	char *tmpstring;
	char *tmpcmd;
	int size=0;
	int result=0;

	if (pCurrProcessClient->i2cPandingReply==0) {
		tmpcmd=(char*)malloc(sizeof(cmdString)+sizeof(attbString)+10);
		if (tmpcmd) {
			sprintf(tmpcmd,"%s %d %s",cmdString,pCurrProcessClient->clientref,attbString);
			if (pSendBuffer) {
				size=strlen(tmpcmd)+strlen(pSendBuffer);
			}
			else {
				size=strlen(tmpcmd);
			}
			tmpstring=(char*)malloc(size+2);
			if (tmpstring) {
				if (pSendBuffer) {
					sprintf(tmpstring,"%s%s\n",pSendBuffer,tmpcmd);
					free(pSendBuffer);
				}
				else {
					sprintf(tmpstring,"%s\n",tmpcmd);
				}
				pSendBuffer=tmpstring;
				pCurrProcessClient->i2cPandingReply=1;
				pCurrProcessClient->i2cReplyWaitingCnt=0;
				result=1;
			}
			free(tmpcmd);
		}
	}
	return(result);
}

/*
 * Call during remote client reply command.
 */
void DMgr_ClientReply(char **token, int tokenCnt )
{

	int clientref=atoi(token[1]);

	clientprop_t *pClientProp=GetClientProp(clientref);
	if (pClientProp) {
		if (pClientProp->CurrDriverIndexNumber>=totalI2cDriver) {
			//not suppose to happen, we will reset everything
			pClientProp->CurrDriverIndexNumber=0;
			pClientProp->i2ccmdstep=stepstart;
		}
		if (pClientProp->online && pDriverMgt[pClientProp->CurrDriverIndexNumber]->replyCB) {
			pCurrProcessClient=pClientProp;
			(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->replyCB)(pClientProp,token,tokenCnt);
		}
	}
	SendOutBufferNow();
}
/*
 * Call when received TIMEOUT message from remote client
 */
void DMgr_ClientCmdTimeout(clientprop_t* pClientProp)
{

	if (pClientProp) {
		if (pClientProp->CurrDriverIndexNumber>=totalI2cDriver) {
			//not suppose to happen, we will reset everything
			pClientProp->CurrDriverIndexNumber=0;
			pClientProp->i2ccmdstep=stepstart;
		}
		if (pClientProp->online && pDriverMgt[pClientProp->CurrDriverIndexNumber]->cmdtimeoutCB) {
			pCurrProcessClient=pClientProp;
			(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->cmdtimeoutCB)(pClientProp);
			pClientProp->i2cPandingReply=0;
		}
	}
}

/*
 * Call when server disconnected
 */
void DMgr_Serverdisconnected(void)
{
	int c,drvid;
	clientprop_t *rclient;
	int totalRemoteclient=GetTotalClient();
	for (c=0;c<totalRemoteclient;c++)
	{
		//rotate through all the client.
		rclient=GetClientProp(c);
		for (drvid=0;drvid<totalI2cDriver;drvid++)
		{
			//call the driver one by one.
			(*pDriverMgt[drvid]->resetallCB)(rclient);
		}
	}
	if (pSendBuffer) {
		free(pSendBuffer);
		pSendBuffer=NULL;
	}
}
