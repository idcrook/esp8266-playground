/*
 * DriverLight.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

void DrvLight_refresh(clientprop_t *pClientProp);
void DrvLight_reply(clientprop_t *pClientProp,char **token, int tokenCnt);
void DrvLight_cmdtimeout(clientprop_t *pClientProp);
void DrvLight_RemoteClientOffline(clientprop_t *pClientProp);
void DrvLight_ResetAll(clientprop_t *pClientProp);

int drvLightID=-1;				//keep the I2c device driver ID.
#define DrvLight_i2cID	0x39	//I2c device ID address

#define DrvLightDeviceDisconnected(pDrvLight) do{\
		DMgr_SetDeviceOffline();\
		if ((pDrvLight)) {\
			(pDrvLight)->dataready=0;\
			(pDrvLight)->powerup=0;\
		}\
	}while(0)

/*
 * Call once during system startup by DriverMgr Init function
 */
void DrvLight_init(void)
{
	drvLightID=DMgr_RegisterDriver(DrvLight_i2cID,&DrvLight_refresh,&DrvLight_reply,
								&DrvLight_cmdtimeout,&DrvLight_RemoteClientOffline,&DrvLight_ResetAll);
}

/*
 * Call frequently by DriverMgr. This will allow the driver to send command.
 */
void DrvLight_refresh(clientprop_t *pClientProp)
{
	char tmpstring[50];
	drvlight_t* pDrvLight=(drvlight_t*)pClientProp->pDeviceSetting[pClientProp->CurrDriverIndexNumber];
	if (pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			if (!DMgr_isDeviceOnline()) {
				//need to call i2c poll to check if the hardware is connected
				sprintf(tmpstring,"%x",DrvLight_i2cID);
				DMgr_DriverSend("i2cpoll",tmpstring);
				pClientProp->i2ccmdstep++;
				break;
			}
			pClientProp->i2ccmdstep+=2; //skip the poll command.
			//no break here.
		case step2:
			if (!pDrvLight->powerup) {
				//step2 - send power up.
				//not power up yet, need to send power up command.
				sprintf(tmpstring,"%x 0 1 3",DrvLight_i2cID);
				DMgr_DriverSend("i2cwrite",tmpstring);
				pClientProp->i2ccmdstep++;
				break;
			}
			else {
				//already power up, goto step4
				pClientProp->i2ccmdstep+=2;
			}
			//No break here.
		case step4: //read 0x0c and 0x0d
			sprintf(tmpstring,"%x ac 2",DrvLight_i2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			pClientProp->i2ccmdstep++;
			break;
		case step6: //read 0x0e and 0x0f
			sprintf(tmpstring,"%x ae 2",DrvLight_i2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			pClientProp->i2ccmdstep++;
			break;
		default:
			DMgr_SendDone(pClientProp);
			break;

		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

/*
 * Call when received reply from the remote I2c device.
 */
void DrvLight_reply(clientprop_t *pClientProp,char **token, int tokenCnt)
{
	int tmpL,tmpH;
	double tmpcal;
	drvlight_t* pDrvLight=(drvlight_t*)pClientProp->pDeviceSetting[pClientProp->CurrDriverIndexNumber];
	switch(pClientProp->i2ccmdstep)
	{
	case step1: //reply from Poll
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			DMgr_SetDeviceOnline();
			//create the properties/result storage for the i2c device.
			if (DMgr_CreateDevicePropertiesStorage(sizeof(drvlight_t))) {
				DMgr_RecNextStep(pClientProp,&DrvLight_refresh);
			}
			else {
				DMgr_SendDone(pClientProp);
			}
		}
		else if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"NACK")==0) {
			DrvLightDeviceDisconnected(pDrvLight);
			DMgr_SendDone(pClientProp);
			//end of process.
		}
		break;
	case step3: //reply from power up command
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0)
		{
			if ((pDrvLight=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
				pDrvLight->powerup=1;
				DMgr_RecNextStep(pClientProp,&DrvLight_refresh);
			}
			else {
				DMgr_SetDeviceOffline();
				DMgr_SendDone(pClientProp);
			}
		}
		else {
			DrvLightDeviceDisconnected(pDrvLight);
			DMgr_SendDone(pClientProp);
		}
		break;
	case step5: //reply from reading 0x0c and 0x0d (channel 0)
	case step7: //reply from reading 0x0e and 0x0d (channel 1)
		if (token && strcmp(token[TokenIndex_Status],"ACK")==0)
		{

			tmpL=(int)strtol(token[TokenIndex_Status+2],NULL,16);
			tmpH=(int)strtol(token[TokenIndex_Status+3],NULL,16);
			if ((pDrvLight=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
				if (pClientProp->i2ccmdstep==step5)
				{
					pDrvLight->channel0=(256*tmpH)+tmpL;
					DMgr_RecNextStep(pClientProp,&DrvLight_refresh);
				}
				else {
					pDrvLight->channel1=(256*tmpH)+tmpL;

					//calculate the brightness in Lux
					if (pDrvLight->channel1!=0 && pDrvLight->channel0!=0) {
						tmpcal=(double)(pDrvLight->channel1/pDrvLight->channel0);
						if (tmpcal<=0.50) pDrvLight->lux=(0.0304 * pDrvLight->channel0) - (0.062 * pDrvLight->channel0 * pow(tmpcal,1.4));
						else if (tmpcal<=0.61) pDrvLight->lux=(0.0224 * pDrvLight->channel0) - (0.031 * pDrvLight->channel1);
						else if (tmpcal<=0.80) pDrvLight->lux=(0.0128 * pDrvLight->channel0) - (0.0153 * pDrvLight->channel1);
						else if (tmpcal<=1.30) pDrvLight->lux=(0.00146 * pDrvLight->channel0) - (0.00112 * pDrvLight->channel1);
						else pDrvLight->lux=0;
					}
					else {
						pDrvLight->lux=0;
					}
					pDrvLight->dataready=1;

					DMgr_SendDone(pClientProp);
				}
			}
		}
		else {
			DrvLightDeviceDisconnected(pDrvLight);
			DMgr_SendDone(pClientProp);
		}
		break;
	default: //error.
		DMgr_SendDone(pClientProp);
		break;
	}
}

/*
 * Call when timeout waiting for the return reply from I2c devices
 */
void DrvLight_cmdtimeout(clientprop_t *pClientProp)
{
	if (drvLightID>=0) {
		drvlight_t* pDrvLight=(drvlight_t*)pClientProp->pDeviceSetting[drvLightID];
		if (pDrvLight) DrvLightDeviceDisconnected(pDrvLight);
	}
}

/*
 * Call when the I2c device is disconnect from the Wifi Remote I2c
 */
void DrvLight_RemoteClientOffline(clientprop_t *pClientProp)
{
	if (drvLightID>=0) {
		drvlight_t* pDrvLight=(drvlight_t*)pClientProp->pDeviceSetting[drvLightID];
		if (pDrvLight) DrvLightDeviceDisconnected(pDrvLight);
	}
}
/*
 * Call when the wifi I2c server is disconnected
 */
void DrvLight_ResetAll(clientprop_t *pClientProp)
{
	DMgr_ReleaseDevicePropertiesStorage(pClientProp,drvLightID);
}

