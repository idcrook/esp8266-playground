/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * clientfunction.h
 *
 *  Created on: Apr 7, 2016
 *      Author: khgoh
 */

#ifndef CLIENTFUNCTION_H_
#define CLIENTFUNCTION_H_

#include "globe.h"

/*
 * insert a new client into the memory
 */
void InsertOnlineClient(char *ref, char*macaddr, char*ipaddr, char *online, char*rssi);
/*
 * Set the client online, return false if Remote client is not in the list
 */
int SetClientOnline(char *ref, char *ipaddr);
/*
 * Set the Client offline
 */
void SetClientOffline(char *ref);

int GetTotalClient(void);

clientprop_t *GetClientByIndex(int index);

/*
 * Search for the client properties structure.
 * return null if cannot find the wifi client.
 */
clientprop_t *GetClientProp(int clientref);
/*
 * Clear all pending reply flag.
 */
void ClearAllPendingReply(void);

/*
 * Call when remote server is disconnected, need to reset all the client.
 */
void ResetAllClient(void);
#endif /* CLIENTFUNCTION_H_ */
