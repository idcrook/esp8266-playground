/*
 * DriverI2cInit.c
 *
 *  Created on: Apr 12, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void DrvI2cInit_refresh(clientprop_t *pClientProp);
void DrvI2cInit_reply(clientprop_t *pClientProp, char **token, int tokenCnt);
void DrvI2cInit_cmdtimeout(clientprop_t *pClientProp);
void DrvI2cInit_RemoteClientOffline(clientprop_t *pClientProp);
void DrvI2cInit_ResetAll(clientprop_t *pClientProp);

/*
 * Call once during system startup by DriverMgr Init function
 */
void DrvI2cInit_init(void)
{
	DMgr_RegisterDriver(0xff,&DrvI2cInit_refresh,&DrvI2cInit_reply,
						&DrvI2cInit_cmdtimeout,&DrvI2cInit_RemoteClientOffline,&DrvI2cInit_ResetAll);
}

/*
 * Call frequently by DriverMgr. This will allow the driver to send command.
 */
void DrvI2cInit_refresh(clientprop_t *pClientProp)
{

	if (!pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			DMgr_DriverSend("i2cstart","");
			pClientProp->i2ccmdstep++;
			break;
		default:
			break;
		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

/*
 * Call when received reply from the remote I2c device.
 */
void DrvI2cInit_reply(clientprop_t *pClientProp, char **token, int tokenCnt)
{
	switch(pClientProp->i2ccmdstep)
	{
	case step1:
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			pClientProp->i2cready=1;
		}
		DMgr_SendDone(pClientProp);
		break;
	default:
		break;
	}
}

/*
 * Call when timeout waiting for the return reply from I2c devices
 */
void DrvI2cInit_cmdtimeout(clientprop_t *pClientProp)
{

}

/*
 * Call when the I2c device is disconnect from the Wifi Remote I2c
 */
void DrvI2cInit_RemoteClientOffline(clientprop_t *pClientProp)
{

}

/*
 * Call when the wifi I2c server is disconnected
 */
void DrvI2cInit_ResetAll(clientprop_t *pClientProp)
{

}
