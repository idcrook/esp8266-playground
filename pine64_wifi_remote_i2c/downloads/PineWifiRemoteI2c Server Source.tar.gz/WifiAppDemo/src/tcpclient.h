/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * tcpclient.h
 *
 *  Created on: Apr 12, 2016
 *      Author: khgoh
 */

#ifndef TCPCLIENT_H_
#define TCPCLIENT_H_


/*
 * Call to init the server connect
 * rxCallback is the callback when received data trigger
 * The callback function will use recv() function to retrive the data.
 */
void tcpc_Init(char *server,char *portno, void (*rxCallback)(int fd,short int event, void *ptr), void *ptr);
/*
 * return current connect state.
 */
unsigned int tcpc_isConnected(void);

/*
 * Call the write data into the connection
 * Return number of byte send out.
 */
unsigned int tcpc_Write(unsigned char *pData, unsigned int size);
/*
 * Restart the connection after tcpc_Close() is called
 */
void tcpc_Resume();
/*
 * Close and suspend the connection until tcpc_Resume() is called
 */
void tcpc_Close();
/*
 * Close the connection if currently connected and
 * restart connection.
 * On Next refresh, it will start to reconnect
 * It will also clear suspend flag if previously call tcpc_close.
 */
void tcpc_reconnect();
/*
 * Set the connected callback
 */
void tcpc_SetConnectedCB(void (*pFirstConnnectedCB)(int fd));

/*
 * if return true, system should exit/end
 */
unsigned int tcpc_isEndded(void);

#endif /* TCPCLIENT_H_ */
