/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * globe.h
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#ifndef GLOBE_H_
#define GLOBE_H_

#include <inttypes.h>

#define MaxDriver 10 //set maximum number of driver

#define SensorDevicePollRate	100   //time between each polling on i2c sensor, in ms
#define SensorReplyTimeout		15000  //time out waiting for i2c sensor to reply, in ms
#define ResultPrintOutRate		1000   //Disply printout rate.

typedef enum {
	stepstart=0,step1,step2,step3,step4,step5,step6,step7,step8,step9,step10,
	stepdone,
}i2ccmdstep_t;

extern int serverLinkReady;
typedef struct {
	int  clientref;
	char macaddr[13];
	char ipaddr[17];
	char rssi[8];
	int  online;
	int  i2cready;
	//int  lastSendCmd;
	//uint8_t attribute;

	int CurrDriverIndexNumber;  //manage by DriverMgr.c,each i2c driver will be assign a drivermgrSequnce number
						   //driver only allow to send command when sequence number match the driver number.
	//uint8_t i2cLastSendID; //keep the last active i2c driver's i2cid
	i2ccmdstep_t i2ccmdstep;			//keep the process step of the i2c driver
						//must set to stepdone when driver finish comm with the remote client.
	uint8_t i2cPandingReply;
	int i2cReplyWaitingCnt;
	int i2cDevOnline[MaxDriver]; //keep index of device online.
	void *pDeviceSetting[MaxDriver]; //keep the pointer to the device setting.
}clientprop_t;

//program version date code
//in BCD format
#define SYSVER_YY	0x16
#define SYSVER_MM	0x05
#define SYSVER_DD	0x16
#define SYSVER_REV	0x01

#endif /* GLOBE_H_ */
