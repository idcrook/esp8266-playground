/*
 * Driverhumidity.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void DrvHumidity_refresh(clientprop_t *pClientProp);
void DrvHumidity_reply(clientprop_t *pClientProp,char **token, int tokenCnt);
void DrvHumidity_cmdtimeout(clientprop_t *pClientProp);
void DrvHumidity_RemoteClientOffline(clientprop_t *pClientProp);
void DrvHumidity_ResetAll(clientprop_t *pClientProp);

int drvHumidityID=-1;			//keep the I2c device driver ID.
#define DrvHumidity_I2cID 0x40	//I2c device ID address

#define DrvHumidityDeviceDisconnected(pDrvHumidity) do{\
		DMgr_SetDeviceOffline();\
		if ((pDrvHumidity)) {\
			(pDrvHumidity)->dataready=0;\
		}\
	}while(0)

/*
 * Call once during system startup by DriverMgr Init function
 */
void DrvHumidity_init(void)
{
	drvHumidityID=DMgr_RegisterDriver(DrvHumidity_I2cID,&DrvHumidity_refresh,&DrvHumidity_reply,
									&DrvHumidity_cmdtimeout,&DrvHumidity_RemoteClientOffline,&DrvHumidity_ResetAll);
}

/*
 * Call frequently by DriverMgr. This will allow the driver to send command.
 */
void DrvHumidity_refresh(clientprop_t *pClientProp)
{
	char tmpstring[50];
	//drvHumidity_t* pDrvHumidity=(drvHumidity_t*)pClientProp->pDeviceSetting[pClientProp->CurrDriverIndexNumber];
	if (pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			if (!DMgr_isDeviceOnline()) {
				//need to call i2c poll to check if the hardware is connected
				sprintf(tmpstring,"%x",DrvHumidity_I2cID);
				DMgr_DriverSend("i2cpoll",tmpstring);
				pClientProp->i2ccmdstep++;
				break;
			}
			else {
				pClientProp->i2ccmdstep+=2;
			}
			//no break here.
		case step2: //get humidity
			sprintf(tmpstring,"%x e5 2",DrvHumidity_I2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			pClientProp->i2ccmdstep++;
			break;
		case step4: //get temp
			sprintf(tmpstring,"%x e0 2",DrvHumidity_I2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			pClientProp->i2ccmdstep++;
			break;
		default:
			DMgr_SendDone(pClientProp);
			break;
		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

/*
 * Call when received reply from the remote I2c device.
 */
void DrvHumidity_reply(clientprop_t *pClientProp, char **token, int tokenCnt)
{
	int tmpL,tmpH;
	double tmpvalue;
	drvHumidity_t* pDrvHumidity=(drvHumidity_t*)pClientProp->pDeviceSetting[pClientProp->CurrDriverIndexNumber];
	switch(pClientProp->i2ccmdstep)
	{
	case step1: //reply from Poll
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			DMgr_SetDeviceOnline();
			if (DMgr_CreateDevicePropertiesStorage(sizeof(drvHumidity_t))) {
				DMgr_RecNextStep(pClientProp,&DrvHumidity_refresh);
			}
			else {
				DMgr_SendDone(pClientProp);
			}
		}
		else if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"NACK")==0) {
			DrvHumidityDeviceDisconnected(pDrvHumidity);
			DMgr_SendDone(pClientProp);
			//end of process.
		}
		break;
	case step3: //reply from get Humidity
	case step5: //reply get temperature
		if (tokenCnt>=(TokenIndex_Status+3) && strcmp(token[TokenIndex_Status],"ACK")==0)
		{
			tmpH=(int)strtol(token[TokenIndex_Status+2],NULL,16);
			tmpL=(int)strtol(token[TokenIndex_Status+3],NULL,16);
			if ((pDrvHumidity=(drvHumidity_t*)DMgr_GetDevicePropertiestStorage())) {
				tmpvalue=(double)(256*tmpH)+tmpL;
				if (pClientProp->i2ccmdstep==step3)
				{
					//Humidity reading
					pDrvHumidity->humidity=(float)(125*tmpvalue/65536)-6;
					DMgr_RecNextStep(pClientProp,&DrvHumidity_refresh);
				}
				else {
					//temperature reading
					pDrvHumidity->temperature=(float)(175.72*tmpvalue/65536)-46.8;
					pDrvHumidity->dataready=1;
					DMgr_SendDone(pClientProp);
				}
			}
		}
		else {
			DrvHumidityDeviceDisconnected(pDrvHumidity);
			DMgr_SendDone(pClientProp);
		}
		break;

	default: //error.
		DMgr_SendDone(pClientProp);
		break;
	}
}

/*
 * Call when timeout waiting for the return reply from I2c devices
 */
void DrvHumidity_cmdtimeout(clientprop_t *pClientProp)
{
	if (drvHumidityID>=0) {
		drvHumidity_t* pDrvHumidity=(drvHumidity_t*)pClientProp->pDeviceSetting[drvHumidityID];
		if (pDrvHumidity)	pDrvHumidity->dataready=0;
	}
}

/*
 * Call when the I2c device is disconnect from the Wifi Remote I2c
 */
void DrvHumidity_RemoteClientOffline(clientprop_t *pClientProp)
{
	if (drvHumidityID>=0) {
		drvHumidity_t* pDrvHumidity=(drvHumidity_t*)pClientProp->pDeviceSetting[drvHumidityID];
		if (pDrvHumidity) pDrvHumidity->dataready=0;
	}
}

/*
 * Call when the wifi I2c server is disconnected
 */
void DrvHumidity_ResetAll(clientprop_t *pClientProp)
{
	DMgr_ReleaseDevicePropertiesStorage(pClientProp,drvHumidityID);
}
