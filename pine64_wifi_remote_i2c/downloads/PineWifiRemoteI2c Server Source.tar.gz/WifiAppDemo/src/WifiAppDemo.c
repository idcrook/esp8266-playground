/*
 ============================================================================
 Name        : WifiAppDemo.c
 Author      : KHGoh
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "PollMgr.h"
#include "ProcRxCmd.h"
#include "DriverMgr.h"
#include "tcpclient.h"
#include "TimerMgr.h"
#include "clientfunction.h"
#include "DriverI2c.h"
#include "globe.h"

#define RXBufSize 1000

void TcpRxCallBack(int fd,short int event, void *ptr);
//unsigned int TcpSendDataNow(char *pData,unsigned int size);
void TcpConnectedCallBack(int fd);
void PrintResult(int timerid,void*ptr);
int serverLinkReady=0;
int printouttimerid;

int main(int argc, char *argv[]) {

	printf("Remote Wifi I2c Demo Application\n");
	printf("Version : %.2x%.2x%.2x%.2x\n",SYSVER_YY,SYSVER_MM,SYSVER_DD,SYSVER_REV);
	ProcStrInit();
	if (argc>1){
		printf("Connection to %s server\n",argv[1]);
		tcpc_Init(argv[1],"10000", &TcpRxCallBack, NULL);
	}
	else {
		printf("Usage: WifiAppDemo <Server Ip address>\n");
		printf("Connection to localhost server\n");
		tcpc_Init("127.0.0.1","10000", &TcpRxCallBack, NULL);
	}

	tcpc_SetConnectedCB(&TcpConnectedCallBack);
	printouttimerid=TimerMgr_Create("PrintResult",ResultPrintOutRate,1,&PrintResult,NULL);
	TimerMgr_Start(printouttimerid);

	while(!tcpc_isEndded()) PollMgr_Refresh();

	printf("Server link down, program exiting...\n");
	return EXIT_SUCCESS;
}


void PrintResult(int timerid,void*ptr)
{
	int c;
	static int NoRemoteClientMsgPrint=0;
	static int ServerDisconnectedMsgPrint=0;
	static int ServerConnected=0;
	static long counter=0;

	clientprop_t *rclient;

	int totalRemoteclient=GetTotalClient();

	if (tcpc_isConnected()) {
		ServerConnected=1;
		counter++;
		if (totalRemoteclient) {
			for (c=0;c<totalRemoteclient;c++)
			{
				rclient=GetClientProp(c);
				if (!rclient) continue;
				drvlight_t* drvlight=(drvlight_t*)DMgr_GetDeviceProperties(c,drvLightID);
				drvHumidity_t* drvhumidity=(drvHumidity_t*)DMgr_GetDeviceProperties(c,drvHumidityID);
				printf ("#%s#%s|%s|",rclient->macaddr, rclient->ipaddr,rclient->rssi);
				if (rclient->online) {
					if (drvlight){
						if (drvlight->dataready) {
							//display Channel0,Channel1,and brightness in Lux.
							printf("LSen,CH:%3d/%3d/%4.1fLux",drvlight->channel0,drvlight->channel1,drvlight->lux);
						}
						else {
							printf("LSen, ----Not Ready----");
						}
					}
					else {
						printf("LSen, ----   N/A  ---- ");
					}
					printf("|");
					if (drvhumidity){
						if (drvhumidity->dataready) {
							//display Humidity and Temperature reading.
							printf("TSen:%2.1f%%/%2.2fC ",drvhumidity->humidity,drvhumidity->temperature);

						}
						else {
							printf("TSen: Not Ready  ");
						}
					}
					else {
						printf("TSen: ---N/A---  ");
					}
				}
				else {
					printf("Remote Client Offline");
				}
				printf("\n");
			}
			printf("Round %ld ************************\n",counter);
		}
		else {
			if (!NoRemoteClientMsgPrint) {
				printf("No Remote Client Detected\n");
				NoRemoteClientMsgPrint=1;
			}
		}
	}
	else {
		//Wifi Server is not connected.
		if (!ServerDisconnectedMsgPrint) {
			ServerDisconnectedMsgPrint=1;
			printf("Server Not Connected\n");
		}
		else {
			if (ServerConnected) {
				//previously connected, now is disconnected, reseting
				DMgr_Serverdisconnected();
				ResetAllClient();
				NoRemoteClientMsgPrint=0;
				ServerDisconnectedMsgPrint=0;
				ServerConnected=0;
			}
		}
	}
}
void TcpConnectedCallBack(int fd)
{

}

void TcpRxCallBack(int fd,short int event, void *ptr)
{
	int n;
	char buffer[RXBufSize];
	if (event & POLLIN) {
		n = read(fd,buffer,RXBufSize);
		if (n>0)
		{
			ProcStrRx((unsigned char*)buffer,n);
		}
	}
}
