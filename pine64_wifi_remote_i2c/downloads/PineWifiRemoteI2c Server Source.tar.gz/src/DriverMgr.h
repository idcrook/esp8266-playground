/*
 * DriverMgt.h
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#ifndef DRIVERMGR_H_
#define DRIVERMGR_H_

#include "globe.h"
#include <inttypes.h>
/*
 * Call once during startup
 */
void Dmgr_Init(unsigned int (*pSendCmdCallBack)(char *pData,unsigned int size));

/*
 * register the i2c driver, on success, it will return the drivermgrSequence number
 * will return -1 if fail to register.
 */
int DMgr_RegisterDriver(uint8_t i2cid,
		void (*refreshCB)(clientprop_t*), //call once in the fix interval
		void (*replyCB)(clientprop_t*,char **token, int tokenCnt), // call when remote client reply
		void (*cmdtimeoutCB)(clientprop_t*)); //call when received timeout notice

/*
 * Call during remote client reply command.
 */
void DMgr_ClientReply(char **token, int tokenCnt);
/*
 * Call when received TIMEOUT message from remote client
 */
void DMgr_ClientCmdTimeout(clientprop_t* pClientProp);


/*
 * Call when client just online
 */
void DMgr_ClientOnline(clientprop_t* pClientProp);

/*
 * Call when client just offline
 */
void DMgr_ClientOffline(clientprop_t* pClientProp);

/*
 * return true is current process i2c device is online
 * Only allow to call this function during driver callback.
 */
int DMgr_isDeviceOnline(void);
void DMgr_SetDeviceOnline(void);
void DMgr_SetDeviceOffline(void);

/*
 * Create (return null if fail), get and release I2c Device properties storage area under
 * the connected remote Client
 */
void *DMgr_CreateDevicePropertiesStorage(int storageSize);
void DMgr_ReleaseDevicePropertiesStorage(void);
void *DMgr_GetDevicePropertiestStorage(void);
/*
 * request to send the command string.
 * return true if able to insert the cmdString into the send buffer.
 */
int DMgr_DriverSend(char *cmdString, char *attbString);


#define DMgr_RecNextStep(pClientProp) do {\
		(pClientProp)->i2ccmdstep++;\
		(pClientProp)->i2cPandingReply=0;\
		DrvLight_refresh((pClientProp));\
	}while(0)

#define DMgr_SendDone(pClientProp) do {\
		(pClientProp)->i2ccmdstep=stepdone;\
		(pClientProp)->i2cPandingReply=0;\
	}while(0)


#endif /* DRIVERMGR_H_ */
