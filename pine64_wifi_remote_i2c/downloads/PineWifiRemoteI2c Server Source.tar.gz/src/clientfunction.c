/*
 * clientfunction.c
 *
 *  Created on: Apr 7, 2016
 *      Author: khgoh
 */
#include "clientfunction.h"
#include "DriverMgr.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define MaxClient 100


clientprop_t *pClientProp[100]; //for keeping the pointer to the memory property
int totalclient=0; //keep total number of client in the memory.


/*
 * Copy the string with size limit control.
 */
void copystr(char *src, char *dest, int maxsize);
/*
 * Search for the client properties structure.
 * return null if cannot fine the wifi client.
 */
clientprop_t *GetClientProp(int clientref);

#define UpdateMAC(src,dest) do{copystr((src),(dest),13);}while(0)
#define UpdateIP(src,dest) do{copystr((src),(dest),16);}while(0)
#define UpdateRSSI(src,dest) do{copystr((src),(dest),7);}while(0)

/*
 * insert a new client into the memory
 */
void InsertOnlineClient(char *ref, char*macaddr, char*ipaddr,char *online, char*rssi)
{
	clientprop_t *pCProp;

	int clientref=atoi(ref);
	int onlinestatus=atoi(online);
	if ((pCProp=GetClientProp(clientref))) {
		//found in the memory, just update to online
		pCProp->online=onlinestatus;
		DMgr_ClientOnline(pCProp);
	}
	else {
		if (totalclient<MaxClient){
			pClientProp[totalclient]=(clientprop_t*)malloc(sizeof(clientprop_t));
			if (pClientProp[totalclient]) {
				memset(pCProp,0,sizeof(clientprop_t));
				pClientProp[totalclient]->clientref=atoi(ref);
				UpdateMAC(macaddr,pClientProp[totalclient]->macaddr);
				UpdateIP(ipaddr,pClientProp[totalclient]->ipaddr);
				UpdateRSSI(rssi,pClientProp[totalclient]->rssi);
				pClientProp[totalclient]->online=onlinestatus;
				totalclient++;
				DMgr_ClientOnline(pCProp);
			}
		}
	}
}

/*
 * Set the client online
 */
void SetClientOnline(char *ref, char *ipaddr)
{
	clientprop_t *pCProp;
	int clientref=atoi(ref);
	if ((pCProp=GetClientProp(clientref))) {
		//found in the memory, just update to online
		if (pCProp->online==0)
		{
			//Just online
			DMgr_ClientOnline(pCProp);
		}
		pCProp->online=1;
		UpdateIP(ipaddr,pCProp->ipaddr);
	}
}
/*
 * Set the Client offline
 */
void SetClientOffline(char *ref)
{
	clientprop_t *pCProp;
	int clientref=atoi(ref);
	if ((pCProp=GetClientProp(clientref))) {
		//found in the memory, just update to online
		if (pCProp->online==1)
		{
			//just offline
			DMgr_ClientOffline(pCProp);
		}
		pCProp->online=0;
	}
}

/*
 * Return total number of registered client.
 */
int GetTotalClient(void)
{
	return(totalclient);
}
clientprop_t *GetClientByIndex(int index)
{
	if (index<totalclient)
	{
		return(pClientProp[index]);
	}
	return(NULL);
}

//-----------------------------------------------------------------------------
/*
 * Copy the string with size limit control.
 */
void copystr(char *src, char *dest, int maxsize)
{
	int c;
	memset(dest,0,maxsize);
	for (c=0;(c<maxsize && src[c]);c++) dest[c]=src[c];
}

/*
 * Search for the client properties structure.
 * return null if cannot find the wifi client.
 */
clientprop_t *GetClientProp(int clientref)
{	int c;
	for(c=0;c<totalclient;c++)
	{
		if (pClientProp[c]->clientref==clientref)
		{
			return(pClientProp[c]);
		}
	}
	return(0);
}
