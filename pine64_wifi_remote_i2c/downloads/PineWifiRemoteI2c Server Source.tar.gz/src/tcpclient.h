/*
 * tcpclient.h
 *
 *  Created on: Apr 12, 2016
 *      Author: khgoh
 */

#ifndef TCPCLIENT_H_
#define TCPCLIENT_H_


/*
 * Call to init the server connect
 * rxCallback is the callback when received data trigger
 * The callback function will use recv() function to retrive the data.
 */
void tcpc_Init(char *server,char *portno, void (*rxCallback)(int fd,short int event, void *ptr), void *ptr);
/*
 * return current connect state.
 */
unsigned int tcpc_isConnected(void);

/*
 * Call the write data into the connection
 * Return number of byte send out.
 */
unsigned int tcpc_Write(unsigned char *pData, unsigned int size);
/*
 * Restart the connection after tcpc_Close() is called
 */
void tcpc_Resume();
/*
 * Close and suspend the connection until tcpc_Resume() is called
 */
void tcpc_Close();
/*
 * Close the connection if currently connected and
 * restart connection.
 * On Next refresh, it will start to reconnect
 * It will also clear suspend flag if previously call tcpc_close.
 */
void tcpc_reconnect();
/*
 * Set the connected callback
 */
void tcpc_SetConnectedCB(void (*pFirstConnnectedCB)(int fd));

#endif /* TCPCLIENT_H_ */
