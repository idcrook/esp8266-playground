/*
 * globe.h
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#ifndef GLOBE_H_
#define GLOBE_H_

#include <inttypes.h>

#define MaxDriver 10 //set maximum number of driver
typedef enum {
	stepstart=0,step1,step2,step3,step4,step5,step6,step7,step8,step9,step10,
	stepdone,
}i2ccmdstep_t;

typedef struct {
	int  clientref;
	char macaddr[13];
	char ipaddr[16];
	char rssi[7];
	int  online;
	int  i2cready;
	int  lastSendCmd;
	uint8_t attribute;

	int CurrDriverIndexNumber;  //manage by DriverMgr.c,each i2c driver will be assign a drivermgrSequnce number
						   //driver only allow to send command when sequence number match the driver number.
	uint8_t i2cLastSendID; //keep the last active i2c driver's i2cid
	i2ccmdstep_t i2ccmdstep;			//keep the process step of the i2c driver
						//must set to stepdone when driver finish comm with the remote client.
	uint8_t i2cPandingReply;
	int i2cReplyWaitingCnt;
	int i2cDevOnline[MaxDriver]; //keep index of device online.
	void *pDeviceSetting[MaxDriver]; //keep the pointer to the device setting.
}clientprop_t;

#endif /* GLOBE_H_ */
