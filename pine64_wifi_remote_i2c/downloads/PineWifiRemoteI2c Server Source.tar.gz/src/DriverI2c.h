/*
 * DriverI2c.h
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#ifndef DRIVERI2C_H_
#define DRIVERI2C_H_

#include "globe.h"
#include <inttypes.h>

#define TokenIndex_ClientRef	1
#define TokenIndex_Status 		2

typedef struct{
	uint8_t powerup;
	uint8_t dataready;
	int channel0;
	int channel1;
}drvlight_t;

typedef struct{
	uint8_t dataready;
	float humidity;		//in %
	float temperature; //in C
}drvHumidity_t;

void DrvI2cInit_init(void);
void DrvLight_init(void);
void DrvHumidity_init(void);

#endif /* DRIVERI2C_H_ */
