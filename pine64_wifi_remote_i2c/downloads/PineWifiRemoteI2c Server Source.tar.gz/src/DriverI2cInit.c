/*
 * DriverI2cInit.c
 *
 *  Created on: Apr 12, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void DrvI2cInit_refresh(clientprop_t *pClientProp);
void DrvI2cInit_reply(clientprop_t *pClientProp, char **token, int tokenCnt);
void DrvI2cInit_cmdtimeout(clientprop_t *pClientProp);

void DrvI2cInit_init(void)
{
	DMgr_RegisterDriver(0xff,&DrvI2cInit_refresh,DrvI2cInit_reply,DrvI2cInit_cmdtimeout);
}
void DrvI2cInit_refresh(clientprop_t *pClientProp)
{

	if (!pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			DMgr_DriverSend("i2cstart","");
			pClientProp->i2ccmdstep++;
			break;
		default:
			break;
		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

void DrvI2cInit_reply(clientprop_t *pClientProp, char **token, int tokenCnt)
{
	switch(pClientProp->i2ccmdstep)
	{
	case step1:
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			pClientProp->i2cready=1;
		}
		DMgr_SendDone(pClientProp);
		break;
	default:
		break;
	}
}
void DrvI2cInit_cmdtimeout(clientprop_t *pClientProp)
{

}
