/*
 ============================================================================
 Name        : WifiAppDemo.c
 Author      : KHGoh
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "PollMgr.h"
#include "ProcRxCmd.h"
#include "DriverMgr.h"
#include "tcpclient.h"

#define RXBufSize 1000

void TcpRxCallBack(int fd,short int event, void *ptr);
unsigned int TcpSendDataNow(char *pData,unsigned int size);
void TcpConnectedCallBack(int fd);

int main(void) {

	ProcStrInit();
	Dmgr_Init(&TcpSendDataNow);

	tcpc_Init("192.168.0.220","10000", &TcpRxCallBack, NULL);
	tcpc_SetConnectedCB(&TcpConnectedCallBack);

	while(1) PollMgr_Refresh();

	return EXIT_SUCCESS;
}

void TcpConnectedCallBack(int fd)
{
	char tmpstr[20];
	sprintf(tmpstr,"list\n");
	tcpc_Write((unsigned char *)tmpstr, strlen(tmpstr));
}

void TcpRxCallBack(int fd,short int event, void *ptr)
{
	int n;
	char buffer[RXBufSize];
	if (event & POLLIN) {
		n = read(fd,buffer,RXBufSize);
		if (n>0)
		{
			ProcStrRx((unsigned char*)buffer,RXBufSize);
			//printf("%s\n",buffer);
		}
	}
}

unsigned int TcpSendDataNow(char *pData,unsigned int size)
{
	unsigned int sendsize;
	sendsize=tcpc_Write((unsigned char *)pData, size);
	return(sendsize);
}
