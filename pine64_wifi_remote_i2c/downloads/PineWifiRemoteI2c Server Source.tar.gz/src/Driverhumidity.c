/*
 * Driverhumidity.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void DrvHumidity_refresh(clientprop_t *pClientProp);
void DrvHumidity_reply(clientprop_t *pClientProp,char **token, int tokenCnt);
void DrvHumidity_cmdtimeout(clientprop_t *pClientProp);
drvHumidity_t *pDrvHumidity;

#define DrvHumidity_I2cID 0x40
void DrvHumidity_init(void)
{
	DMgr_RegisterDriver(DrvHumidity_I2cID,&DrvHumidity_refresh,DrvHumidity_reply,DrvHumidity_cmdtimeout);
}

void DrvHumidity_refresh(clientprop_t *pClientProp)
{
	char tmpstring[50];
	if (pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			if (!DMgr_isDeviceOnline()) {
				//need to call i2c poll to check if the hardware is connected
				sprintf(tmpstring,"%x",DrvHumidity_I2cID);
				DMgr_DriverSend("i2cpoll",tmpstring);
				pClientProp->i2ccmdstep++;
				break;
			}
			else {
				pClientProp->i2ccmdstep+=2;
			}
			//no break here.
		case step2: //get humidity
			sprintf(tmpstring,"%x e5 2",DrvHumidity_I2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			break;
		case step4: //get temp
			sprintf(tmpstring,"%x e0 2",DrvHumidity_I2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			break;
		default:
			DMgr_SendDone(pClientProp);
			break;
		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

void DrvHumidity_reply(clientprop_t *pClientProp, char **token, int tokenCnt)
{
	int tmpL,tmpH,tmpvalue;

	switch(pClientProp->i2ccmdstep)
	{
	case step1: //reply from Poll
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			DMgr_SetDeviceOnline();
			if (DMgr_CreateDevicePropertiesStorage(sizeof(drvHumidity_t))) {
				DMgr_RecNextStep(pClientProp);
			}
			else {
				DMgr_SendDone(pClientProp);
			}
		}
		else if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"NACK")==0) {
			DMgr_SetDeviceOffline();
			DMgr_SendDone(pClientProp);
			//end of process.
		}
		break;
	case step3: //reply from get Humidity
	case step5: //repy get temperature
		if (tokenCnt>=(TokenIndex_Status+3) && strcmp(token[TokenIndex_Status],"ACK")==0)
		{
			tmpH=atoi(token[TokenIndex_Status+2]);
			tmpL=atoi(token[TokenIndex_Status+3]);
			if ((pDrvHumidity=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
				tmpvalue=256*tmpH+tmpL;
				if (pClientProp->i2ccmdstep==step3)
				{
					//Humidity reading
					pDrvHumidity->humidity=(125*tmpvalue/65536)-6;
					DMgr_RecNextStep(pClientProp);
				}
				else {
					//temperature reading
					pDrvHumidity->temperature=(175.72*tmpvalue/65536)-46.8;
					pDrvHumidity->dataready=1;
					DMgr_SendDone(pClientProp);
				}
			}
		}
		break;

	default:
		DMgr_SendDone(pClientProp);
		break;
	}
}

void DrvHumidity_cmdtimeout(clientprop_t *pClientProp)
{

}
