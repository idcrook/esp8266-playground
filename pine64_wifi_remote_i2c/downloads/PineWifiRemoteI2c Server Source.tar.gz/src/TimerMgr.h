/*
 * TimerMgr.h
 *
 *  Created on: Jul 9, 2015
 *      Author: khgoh
 */

#ifndef INC_TIMERMGR_H_
#define INC_TIMERMGR_H_

/*
 * This Timer Manager will be making use of the PollMgr module
 * To handle the FD.
 * Once trigger, will do the callback.
 */

/*
 * Call to create a time, on success, will return the timerid.
 * or else, will return zero.
 * name length is 16 char or less.
 */
int TimerMgr_Create(char *name, long delay_ms, unsigned char isRepeat,
				void (*cb)(int timerid,void*ptr), void *ptr);

/*
 * Call to start the timer
 */
void TimerMgr_Start(int timerid);

/*
 * Call to stop the timer
 */
void TimerMgr_Stop(int timerid);

#endif /* INC_TIMERMGR_H_ */
