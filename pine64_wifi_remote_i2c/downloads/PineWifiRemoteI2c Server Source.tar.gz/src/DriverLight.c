/*
 * DriverLight.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */

#include "DriverI2c.h"
#include "DriverMgr.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void DrvLight_refresh(clientprop_t *pClientProp);
void DrvLight_reply(clientprop_t *pClientProp,char **token, int tokenCnt);
void DrvLight_cmdtimeout(clientprop_t *pClientProp);
drvlight_t *pDrvLight;

#define DrvLight_i2cID	0x39

void DrvLight_init(void)
{
	DMgr_RegisterDriver(DrvLight_i2cID,&DrvLight_refresh,DrvLight_reply,DrvLight_cmdtimeout);
}


void DrvLight_refresh(clientprop_t *pClientProp)
{
	char tmpstring[50];
	if (pClientProp->i2cready) {
		switch(pClientProp->i2ccmdstep)
		{
		case stepstart:
			if (!DMgr_isDeviceOnline()) {
				//need to call i2c poll to check if the hardware is connected
				sprintf(tmpstring,"%x",DrvLight_i2cID);
				DMgr_DriverSend("i2cpoll",tmpstring);
				pClientProp->i2ccmdstep++;
				break;
			}
			else {
				pClientProp->i2ccmdstep+=2; //skip the poll command.
				if ((pDrvLight=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
					if (!pDrvLight->powerup) {
						//step2 - send power up.
						//not power up yet, need to send power up command.
						sprintf(tmpstring,"%x 0 1 3",DrvLight_i2cID);
						DMgr_DriverSend("i2cwrite",tmpstring);
						pClientProp->i2ccmdstep++;
						break;
					}
					else {
						//already power up, goto step4
						pClientProp->i2ccmdstep+=2;
					}
				}
				else {
					//not suppose to happen.
					DMgr_SetDeviceOffline();
					DMgr_SendDone(pClientProp);
				}
			}
			//No break here.
		case step4: //read 0x0c and 0x0d
			sprintf(tmpstring,"%x ac 2",DrvLight_i2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			break;
		case step6: //read 0x0e and 0x0f
			sprintf(tmpstring,"%x ae 2",DrvLight_i2cID);
			DMgr_DriverSend("i2cread",tmpstring);
			break;
		default:
			DMgr_SendDone(pClientProp);
			break;

		}
	}
	else {
		DMgr_SendDone(pClientProp);
	}
}

void DrvLight_reply(clientprop_t *pClientProp,char **token, int tokenCnt)
{
	int tmpL,tmpH;
	switch(pClientProp->i2ccmdstep)
	{
	case step1: //reply from Poll
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0) {
			DMgr_SetDeviceOnline();
			if (DMgr_CreateDevicePropertiesStorage(sizeof(drvlight_t))) {
				DMgr_RecNextStep(pClientProp);
			}
			else {
				DMgr_SendDone(pClientProp);
			}
		}
		else if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"NACK")==0) {
			DMgr_SetDeviceOffline();
			DMgr_SendDone(pClientProp);
			//end of process.
		}
		break;
	case step3: //reply from power up command
		if (tokenCnt>TokenIndex_Status && strcmp(token[TokenIndex_Status],"ACK")==0)
		{
			if ((pDrvLight=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
				pDrvLight->powerup=1;
			}
			else {
				DMgr_SetDeviceOffline();
				DMgr_SendDone(pClientProp);
			}
		}
		else {
			DMgr_SetDeviceOffline();
			DMgr_SendDone(pClientProp);
		}
		break;
	case step5: //reply from reading 0x0c and 0x0d (channel 0)
	case step7: //reply from reading 0x0e and 0x0d (channel 1)
		if (token && strcmp(token[TokenIndex_Status],"ACK"))
		{
			tmpL=atoi(token[TokenIndex_Status+2]);
			tmpH=atoi(token[TokenIndex_Status+3]);
			if ((pDrvLight=(drvlight_t*)DMgr_GetDevicePropertiestStorage())) {
				if (pClientProp->i2ccmdstep==step5) {
					pDrvLight->channel0=256*tmpH+tmpL;
					DMgr_RecNextStep(pClientProp);
				}
				else {
					pDrvLight->channel1=256*tmpH+tmpL;
					pDrvLight->dataready=1;
					DMgr_SendDone(pClientProp);
				}
			}
		}
		break;
	default: //error.
		DMgr_SendDone(pClientProp);
		break;
	}
}

void DrvLight_cmdtimeout(clientprop_t *pClientProp)
{

}
