/*
 * ProcRxCmd.c
 *
 *  Created on: Apr 7, 2016
 *      Author: khgoh
 */
#include "ProcRxCmd.h"
#include "clientfunction.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>

#define maxStrCmd  50 //maximum number of command.
#define InputBufSize	260

//the command list sequence must follow strcmdID command index sequence
const char strRxCmd[]= {
		"LIST  I2CSTART I2CPOLL I2CREAD I2CWRITE OFFLINE ONLINE"
};

//command constant definition
//do not change the sequence number.
typedef enum {
	rxCmdID_list  	=	0,
	rxCmdID_i2cstart,
	rxCmdID_i2cpoll	,
	rxCmdID_i2cread	,
	rxCmdID_i2cwrite,
	rxCmdID_offline	,
	rxCmdID_online	,
	rxCmdID_unknow  , //this id must place at the end of the list.
} rxcmdID;

char *pTokenCmd[maxStrCmd];
char inputbuffer[InputBufSize];
uint16_t totalCmd=0;

/*
 * Process the command string
 */
void DecodeRxString(char *str);

/*
 * Call once to init the module
 */
int ProcStrInit(void)
{
	char *tmpcmd;
	char *ptr1,*ptr2;
	tmpcmd=(char*)malloc(strlen(strRxCmd)+1);
	//indexing all the command from the command list
	if (tmpcmd) {
		strcpy(tmpcmd,strRxCmd);
		for ((ptr1=strtok_r(tmpcmd," ",&ptr2));ptr1;(ptr1=strtok_r(NULL," ",&ptr2)))
		{
			pTokenCmd[totalCmd]=(char*)malloc(strlen(ptr1)+1);
			if (pTokenCmd[totalCmd])
			{
				strcpy(pTokenCmd[totalCmd],ptr1);
				totalCmd++;
			}
			else
			{
				//cannot allocate memory, error return.
				free(tmpcmd);
				return(0);
			}

			if (totalCmd>=maxStrCmd) {
				//reach the max number of command.
				free(tmpcmd);
				return(0);
			}
		}
		//done
		free(tmpcmd);
		return(1);
	}
	return(0);
}


//match the command and convert into index
rxcmdID ProcStrDecodeCmd(char *strCmd)
{
	int c=0;
	for(c=0;c<totalCmd;c++)
	{
		if(strcmp(pTokenCmd[c],strCmd)==0)
		{
			return(c);
		}
	}
	return(rxCmdID_unknow);
}

/*
 * Call to process the received string from console
 * will only call string processing when detected \r or \n.
 */
void ProcStrRx(uint8_t *str, uint16_t strsize)
{
	static uint8_t rxbuf[InputBufSize];
	static uint16_t index=0;
	uint16_t leftoverbyte=strsize;
	uint16_t rxindex=0;
	while(leftoverbyte) {
		if (str[rxindex]=='\n'||str[rxindex]=='\r') {
			rxbuf[index]=0; //set string end of line
			if (strlen((char*)rxbuf)>0) {
				//call to process the string
				DecodeRxString((char*)rxbuf);
			}
			index=0;
		}
		else {
			rxbuf[index]=str[rxindex];
			index++;
			//check for input buffer over flow
			//should not happen under normal condition.
			if (index==InputBufSize-1)
			{
				index=0;
			}
		}
		rxindex++;
		leftoverbyte--;
	}
}

/*
 * Process the command string
 */
void DecodeRxString(char *str) {
    char *ptr2;
    rxcmdID cmdcode;
    char *_ch_sep=" \r\n";
    char *tokenlist[15]; //to keep the list of pointer.
    int tokenCnt;

    if (strlen>0) {

    	tokenCnt=0;
    	for (tokenlist[tokenCnt]=strtok_r((char*)str,_ch_sep,&ptr2);
    		(tokenlist[tokenCnt] && tokenCnt<15);
    		tokenlist[tokenCnt]=strtok_r(NULL,_ch_sep,&ptr2)) tokenCnt++;

    	cmdcode=ProcStrDecodeCmd(tokenlist[0]);
    	switch (cmdcode) {

    		case rxCmdID_list:
    			if (tokenCnt==8){
    				InsertOnlineClient(tokenlist[1],tokenlist[2],tokenlist[3],tokenlist[6],tokenlist[7]);
    			}
    			break;
    		case rxCmdID_i2cstart:
    		case rxCmdID_i2cpoll:
    		case rxCmdID_i2cread:
    			DMgr_ClientReply(tokenlist,tokenCnt);
    			break;
    		case rxCmdID_offline:
    			if (tokenCnt==2)
    			{
    				SetClientOffline(tokenlist[1]);
    			}
    			break;
    		case rxCmdID_online:
    			if (tokenCnt==4)
    			{
    				SetClientOnline(tokenlist[1],tokenlist[3]);
    			}
    			break;
    		default:
    			break;
    	}
    }
}

