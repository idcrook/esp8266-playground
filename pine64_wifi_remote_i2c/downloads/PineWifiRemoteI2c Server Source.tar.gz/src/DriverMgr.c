/*
 * DriverMgr.c
 *
 *  Created on: Apr 8, 2016
 *      Author: khgoh
 */



#include "DriverMgr.h"
#include "TimerMgr.h"
#include "DriverI2c.h"
#include "globe.h"
#include "clientfunction.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "tcpclient.h"

typedef struct{
	uint8_t i2cid;
	void (*refreshCB)(clientprop_t*);
	void (*replyCB)(clientprop_t*,char **token, int tokenCnt);
	void (*cmdtimeoutCB)(clientprop_t*);
}drivermgt_t;

drivermgt_t *pDriverMgt[MaxDriver];
uint16_t totalDriver=0;
clientprop_t *pCurrProcessClient;
char *pSendBuffer=0;
unsigned int (*pSendCmdCB)(char *pData,unsigned int size)=NULL;

/*
 * List down all the init function for i2c driver.
 */
void (*pDrvInitFunction[])(void) = {
		&DrvI2cInit_init,
		&DrvLight_init,
		&DrvHumidity_init,
};

void DriverRefresh(int timerid,void*ptr);
//call to send out data in the send buffer.
void SendOutBufferNow(void);
/*
 * Call once during startup
 */
void Dmgr_Init(unsigned int (*pSendCmdCallBack)(char *pData,unsigned int size))
{
	int c;
	int drivercnt=sizeof(pDrvInitFunction)/sizeof(void*);
	pSendCmdCB=pSendCmdCallBack;
	DrvLight_init();
	DrvHumidity_init();
	for(c=0;c<MaxDriver;c++) pDriverMgt[c]=0;
	for(c=0;c<drivercnt;c++) (*pDrvInitFunction[c])();
	TimerMgr_Create("DrvMgr",1000,1,&DriverRefresh,NULL);
}

/*
 * register the i2c driver, on success, it will return the drivermgrSequence number
 */
int DMgr_RegisterDriver(uint8_t i2cid,
		void (*refreshCB)(clientprop_t*), //call once in the fix interval
		void (*replyCB)(clientprop_t*,char **token, int tokenCnt), // call when remote client reply
		void (*cmdtimeoutCB)(clientprop_t*)) //call when received timeout notice

{
	if (totalDriver<MaxDriver) {
		pDriverMgt[totalDriver]=(drivermgt_t*)malloc(sizeof(drivermgt_t));
		if (pDriverMgt[totalDriver]) {
			memset(pDriverMgt[totalDriver],0,sizeof(drivermgt_t));
			pDriverMgt[totalDriver]->i2cid=i2cid;
			pDriverMgt[totalDriver]->refreshCB=refreshCB;
			pDriverMgt[totalDriver]->replyCB=replyCB;
			pDriverMgt[totalDriver]->cmdtimeoutCB=cmdtimeoutCB;
			totalDriver++;
			return(totalDriver-1);
		}
	}
	return(-1);
}

/*
 * Create, get and release I2c Device properties storage area under
 * the connected remote Client
 */
void *DMgr_CreateDevicePropertiesStorage(int storageSize)
{
	void *ptr;
	if (!pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber])
	{
		//only create memory if not yet created.
		ptr=(void*)malloc(storageSize);
		if (ptr) {
			memset(ptr,0,storageSize);
			pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]=ptr;
		}
	}
	return(pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]);
}
void DMgr_ReleaseDevicePropertiesStorage(void)
{
	if (pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber])
	{
		free(pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]);
		pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]=NULL;
	}
}
void *DMgr_GetDevicePropertiestStorage(void)
{
	return(pCurrProcessClient->pDeviceSetting[pCurrProcessClient->CurrDriverIndexNumber]);
}

/*
 * will do the callback on each remote client with the drivermgrsequence
 */
void DriverRefresh(int timerid,void*ptr)
{
	int clientref;
	int repeatcnt;
	if (tcpc_isConnected()) {
		for (clientref=0;clientref<GetTotalClient();clientref++)
		{
			repeatcnt=0;
			clientprop_t *pClientProp=GetClientByIndex(clientref);
			do {
				if (pClientProp && totalDriver) {

					//check for pending reply time out
					if (pClientProp->i2cPandingReply){
						pClientProp->i2cReplyWaitingCnt++;
						if (pClientProp->i2cReplyWaitingCnt>7)
						{
							DMgr_ClientCmdTimeout(pClientProp);
						}
					}
					if (pClientProp->CurrDriverIndexNumber>=totalDriver) {
						//not suppose to happen, we will reset everything
						pClientProp->CurrDriverIndexNumber=0;
						pClientProp->i2ccmdstep=stepstart;
					}
					else if (pClientProp->i2ccmdstep==stepdone) {
						//goto next sequence number and reset the i2ccmdstep to stepstart
						pClientProp->CurrDriverIndexNumber++;
						if (pClientProp->CurrDriverIndexNumber>=totalDriver-1) pClientProp->CurrDriverIndexNumber=0;
						pClientProp->i2ccmdstep=stepstart;
					}
					//do the callback for the driver.
					if (pClientProp->online &&  pDriverMgt[pClientProp->CurrDriverIndexNumber]->refreshCB) {
						pCurrProcessClient=pClientProp;
						(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->refreshCB)(pClientProp);
					}
					if (pClientProp->i2ccmdstep==stepdone) {
						//the driver did not send any think, we will repeat again with the next i2cdriver.
						repeatcnt++;
					}
					else {
						repeatcnt=0;
					}
				}
			} while(!repeatcnt && repeatcnt<totalDriver); //will exit the loop is no need repeat or already repeat for all driver.
		}
		SendOutBufferNow();
	}
}

//call to send out data in the send buffer.
void SendOutBufferNow(void) {
	unsigned int size,sendsize;
	char *tmpstr;
	if (pSendBuffer && (size=strlen(pSendBuffer))>0)
	{
		if (pSendCmdCB) {
			sendsize=(*pSendCmdCB)(pSendBuffer,size);
			if (size-sendsize) {
				//unable to finish sending
				tmpstr=(char*)malloc(size-sendsize+1);
				if (tmpstr) {
					strcpy(tmpstr,&pSendBuffer[sendsize]);
					free(pSendBuffer);
					pSendBuffer=tmpstr;
				}
				else {
					//unable to allocate memory, just clear it.
					free(pSendBuffer);
					pSendBuffer=NULL;
				}
			}
			else {
				//all the byte is send out, clear it.
				free(pSendBuffer);
				pSendBuffer=NULL;
			}
		}
		else {
			//all the byte is send out, clear it.
			free(pSendBuffer);
			pSendBuffer=NULL;
		}
	}
}

/*
 * return true is current process i2c device is online
 * Only allow to call this function during driver callback.
 */
int DMgr_isDeviceOnline(void)
{
	int c;
	for (c=0;c<MaxDriver;c++)
	{
		if (pCurrProcessClient->i2cDevOnline[c]==pCurrProcessClient->CurrDriverIndexNumber){
			return(1);
		}
	}
	return(0);
}
void DMgr_SetDeviceOnline(void)
{
	pCurrProcessClient->i2cDevOnline[pCurrProcessClient->CurrDriverIndexNumber]=0;
}
void DMgr_SetDeviceOffline(void)
{
	pCurrProcessClient->i2cDevOnline[pCurrProcessClient->CurrDriverIndexNumber]=0;
}
/*
 * Call when client just online
 */
void DMgr_ClientOnline(clientprop_t* pClientProp)
{
	pClientProp->CurrDriverIndexNumber=0;
	pClientProp->i2ccmdstep=stepstart;
}

/*
 * Call when client just offline
 */
void DMgr_ClientOffline(clientprop_t* pClientProp)
{

}

/*
 * request to send the command string.
 * return true if able to insert the cmdString into the send buffer.
 */
int DMgr_DriverSend(char *cmdString, char *attbString)
{
	char *tmpstring;
	char *tmpcmd;
	int size=0;

	if (pCurrProcessClient->i2cPandingReply==0) {
		tmpcmd=(char*)malloc(sizeof(cmdString)+sizeof(attbString)+10);
		if (tmpcmd) {
			sprintf(tmpcmd,"%s %d %s",cmdString,pCurrProcessClient->clientref,attbString);
			size=strlen(tmpcmd)+strlen(pSendBuffer);
			tmpstring=(char*)malloc(size+2);
			if (tmpstring) {
				sprintf(tmpstring,"%s%s/n",pSendBuffer,tmpcmd);
				free(pSendBuffer);
				free(tmpcmd);
				pSendBuffer=tmpstring;
				pCurrProcessClient->i2cPandingReply=1;
				pCurrProcessClient->i2cReplyWaitingCnt=0;
				return(1);
			}
			free(tmpcmd);
		}
	}
	return(0);
}

/*
 * Call during remote client reply command.
 */
void DMgr_ClientReply(char **token, int tokenCnt )
{

	int clientref=atoi(token[1]);


	clientprop_t *pClientProp=GetClientProp(clientref);
	if (pClientProp) {
		if (pClientProp->CurrDriverIndexNumber>=totalDriver) {
			//not suppose to happen, we will reset everything
			pClientProp->CurrDriverIndexNumber=0;
			pClientProp->i2ccmdstep=stepstart;
		}
		if (pClientProp->online && pDriverMgt[pClientProp->CurrDriverIndexNumber]->replyCB) {
			pCurrProcessClient=pClientProp;
			(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->replyCB)(pClientProp,token,tokenCnt);
		}
	}
	SendOutBufferNow();
}
/*
 * Call when received TIMEOUT message from remote client
 */
void DMgr_ClientCmdTimeout(clientprop_t* pClientProp)
{

	if (pClientProp) {
		if (pClientProp->CurrDriverIndexNumber>=totalDriver) {
			//not suppose to happen, we will reset everything
			pClientProp->CurrDriverIndexNumber=0;
			pClientProp->i2ccmdstep=stepstart;
		}
		if (pClientProp->online && pDriverMgt[pClientProp->CurrDriverIndexNumber]->cmdtimeoutCB) {
			pCurrProcessClient=pClientProp;
			(*pDriverMgt[pClientProp->CurrDriverIndexNumber]->cmdtimeoutCB)(pClientProp);
			pClientProp->i2cPandingReply=0;
		}
	}
}
