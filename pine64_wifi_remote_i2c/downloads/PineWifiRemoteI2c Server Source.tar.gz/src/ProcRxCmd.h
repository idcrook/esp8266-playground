/*
 * ProcRxCmd.h
 *
 *  Created on: Apr 7, 2016
 *      Author: khgoh
 */

#ifndef PROCRXCMD_H_
#define PROCRXCMD_H_

#include <inttypes.h>
/*
 * Call once to init the module
 */
int ProcStrInit(void);

/*
 * Call to process the received string from console
 * will only call string processing when detected \r or \n.
 */
void ProcStrRx(uint8_t *str, uint16_t strsize);

#endif /* PROCRXCMD_H_ */
