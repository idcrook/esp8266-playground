/*
 * clientfunction.h
 *
 *  Created on: Apr 7, 2016
 *      Author: khgoh
 */

#ifndef CLIENTFUNCTION_H_
#define CLIENTFUNCTION_H_

#include "globe.h"

/*
 * insert a new client into the memory
 */
void InsertOnlineClient(char *ref, char*macaddr, char*ipaddr, char *online, char*rssi);
/*
 * Set the client online
 */
void SetClientOnline(char *ref, char*ipaddr);
/*
 * Set the Client offline
 */
void SetClientOffline(char *ref);

int GetTotalClient(void);

clientprop_t *GetClientByIndex(int index);

/*
 * Search for the client properties structure.
 * return null if cannot find the wifi client.
 */
clientprop_t *GetClientProp(int clientref);

#endif /* CLIENTFUNCTION_H_ */
