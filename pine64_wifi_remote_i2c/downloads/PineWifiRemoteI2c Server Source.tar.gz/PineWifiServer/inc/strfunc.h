/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * strfunc.h
 *
 *  Created on: Mar 29, 2016
 *      Author: khgoh
 */

#ifndef STRFUNC_H_
#define STRFUNC_H_

#include <inttypes.h>
/*
 * Call to convert 1 byte hex string to uint8_t.
 */
uint16_t HexByteStrToByte(char *hexString, uint8_t *pByteResult);
/*
 * convert hex byte to hex string.
 */
void HexToStr(uint8_t *pByte,uint16_t size,char *pdest);


#define IPSTRFORMAT  "%d.%d.%d.%d"
#define IPVAR(pIP)   ((pIP)[0]),(pIP)[1]),(pIP)[2]),(pIP)[3]))


#define MACSTRFORMAT "%02x%02x%02x%02x%02x%02x"
#define MACVAR(pMAC) (pMAC)[0],(pMAC)[1],(pMAC)[2],(pMAC)[3],(pMAC)[4],(pMAC)[5]
#define FW4BYTEFORMAT "%02x%02x%02x%02x"
#define FW4BYTEVAR(pByte) (pByte)[0],(pByte)[1],(pByte)[2],(pByte)[3]
#define FW2BYTEFORMAT "%02x%02x"
#define FW2BYTEVAR(pByte) (pByte)[0],(pByte)[1]

#endif /* STRFUNC_H_ */
