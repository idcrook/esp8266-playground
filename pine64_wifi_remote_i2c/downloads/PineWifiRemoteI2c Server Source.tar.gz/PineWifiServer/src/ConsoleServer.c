/*
 * ConsoleServer.c
 *
 *  Created on: Mar 13, 2016
 *      Author: khgoh
 */

#include "ConsoleServer.h"
#include "ProcStringCmd.h"
#include "TcpServerConn.h"
#include "TcpSendCmd.h"
#include "usercfg.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define MaxConsole 1

/*
 * Maximum number of remote client allow to connect to this server
 */
#define MaxNumberOfRemoteClient 			100

/*
 * Period to wait for the remote to reply back when sending a command to remote client
 */
#define TimeoutWaitingRemoteClientReply 	3000 //each count is ms

/*
 * Period between check the remote client to make sure it is still alive
 */
#define TimeoutRemoteClientIdle				30000 //each count is ms

/*
 * call once during startup to init the console server
 * return true if successfully start up a console server
 */
uint16_t csref;
uint16_t tmp;

/*
 * Console Server Connected Callback
 */
void csConnectedCB(int fd,struct sockaddr* pRemoteAddr);
/*
 * Console Server Data received callback
 */
void csDataRxCB(int fd, uint8_t *pData, uint16_t size);
/*
 * Console Server connection disconnected callback
 */
void csDisconnectedCB(int fd);

uint16_t CSInit(void)
{
	//create the TCP Server
	TcpSendCmdInit(MaxNumberOfRemoteClient, TimeoutRemoteClientIdle,
			TimeoutWaitingRemoteClientReply,&ProcClientReturnResultCB);

	csref=TscCreateServer(ConsolePort,MaxConsole);
	if (csref) {
		TscRegisterCBConnected(csref,&csConnectedCB);
		TscRegisterCBRxData(csref,&csDataRxCB);
		TscRegisterCBDisconnected(csref,&csDisconnectedCB);

		//create the console server
		ProcStrInit();

		if (TscStartServer(csref)) {
			return(1);
		}
	}
	return(0);
}

/*
 * Console Server Connected Callback
 */
void csConnectedCB(int fd,struct sockaddr* pRemoteAddr)
{
	char tmpstr[100];
	sprintf(tmpstr,"Wifi Remote I2c Server Console\r\n");
	TscSendData(fd,(uint8_t*)tmpstr,strlen(tmpstr));
	sprintf(tmpstr,"version : %04x-%02x%02x%02x%02x\r\n",
			SYSID,SYSVER_YY,SYSVER_MM,SYSVER_DD,SYSVER_REV);
	TscSendData(fd,(uint8_t*)tmpstr,strlen(tmpstr));
	sprintf(tmpstr,"Type 'help' for command detail\r\n>"); //must include a prompt at the last line
	TscSendData(fd,(uint8_t*)tmpstr,strlen(tmpstr));
}

/*
 * Console Server Data received callback
 */
void csDataRxCB(int fd, uint8_t *pData, uint16_t size)
{
	ProcStrRx(fd,pData,size);
}

/*
 * Console Server connection disconnected callback
 */
void csDisconnectedCB(int fd)
{

}

