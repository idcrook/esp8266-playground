/*
 ============================================================================
 Name        : PineWifiServer.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "ConsoleServer.h"
#include "PollMgr.h"
#include "usercfg.h"
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


int CountRunningInstance(char *myProgName);

int main(int argc, char *argv[]) {


	int c;
	printf("Pine Wifi Remote I2c Server\n");
	printf("  Version : %.2x%.2x%.2x%.2x\n",SYSVER_YY,SYSVER_MM,SYSVER_DD,SYSVER_REV);
	printf("  FW ID : 0x%.4X\n",SYSID);
	printf("  Console Port Number : %d\n",ConsolePort);

	if (CountRunningInstance(argv[0])>1)
	{
		printf("Another Instance is running, exiting....\n");
		return(1);
	}
	if (argc>1){

			for (c=1;c<argc;c++)
			{
				if (strcmp(argv[c],"-d")==0)
				{
					if (daemon(0,0)==-1) {
						//error, unable to fork
						return(-1);
					}
					break;
				}
			}
	}

	//Start the TCP server

	if (CSInit()) {
		printf("Server Started.\n");
		//start the console server
		do{
			PollMgr_Refresh();
		}while(1);
	}
	else {
		printf("Unable to start server. Exiting...\n");
		return(1);
	}
	return EXIT_SUCCESS;
}




/*
 * **************************************************************************************
 */

#define MS_TMPSTRLEN 1024
#define MS_TMPSTRCMD 256
static char *pMS_PidString=0;
/*
 * Call to return the pid of the runing program
 * If program is not running, it will return zero
 * The next subsequent call with progName=NULL will get the
 * subsequent pid (program with multiple pid) and will return 0 when
 * no more pid to return.
 */
pid_t Getpid(char *progName)
{
	char line[MS_TMPSTRLEN];
	char tmpstrcmd[MS_TMPSTRCMD];
	pid_t pid;
	char *pToken;
	static char *pstrtok;

	if (progName) {
		//Clear the memory if previously already assigned
		if (pMS_PidString) free(pMS_PidString);
		pMS_PidString=0;

		//Create the command and call it.
		sprintf(tmpstrcmd,"pidof %s",progName);
		FILE *pCmd = popen(tmpstrcmd, "r");
		line[0]=0; //clear the line first
		if (!fgets(line, MS_TMPSTRLEN, pCmd)) {
			return(0);
		}
		pclose(pCmd);

		//create memory to keep the result.
		pMS_PidString=malloc(strlen(line)+1);
		if (!pMS_PidString) return(0);
		memset(pMS_PidString,0,strlen(line)+1);
		strcpy(pMS_PidString,line);

		//phase the line to each individual token
		pToken=strtok_r(pMS_PidString," ",&pstrtok);
		if (pToken){
			pid = strtoul(pToken, NULL, 10);
			return(pid);
		}
	}
	else if (pMS_PidString){
		//get the subsequent pid
		pToken=strtok_r(NULL," ",&pstrtok);
		if (pToken){
			pid = strtoul(pToken, NULL, 10);
			return(pid);
		}
	}
	return(0);
}

/*
 * return number of instance is running.
 */
int CountRunningInstance(char *myProgName)
{
	pid_t pid;
	int instance=0;
	pid=Getpid(myProgName);
	while(pid) {
		instance++;
		pid=Getpid(NULL);
	}
	//printf("Total Instance of %s is %d \n",myProgName,instance);
	return(instance);
}
