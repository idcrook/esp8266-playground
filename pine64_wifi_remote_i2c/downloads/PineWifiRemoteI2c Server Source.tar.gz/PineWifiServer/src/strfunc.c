/*
 * strfunc.c
 *
 *  Created on: Mar 29, 2016
 *      Author: khgoh
 */

#include "strfunc.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
 * Call to convert 1 byte hex string to uint8_t.
 */
uint16_t HexByteStrToByte(char *hexString, uint8_t *pByteResult)
{
	unsigned int c;

	if (sscanf(hexString, "%02X", &c) != 1) {
		return(0); // Didn't parse as expected
	}
	(*pByteResult)=(uint8_t)c;

	return(1);

}

/*
 * convert hex byte to hex string.
 */
void HexToStr(uint8_t *pByte,uint16_t size,char *pdest) {
	int c;
	sprintf(pdest," ");
	for(c=0;c<(size);c++) sprintf(&pdest[strlen(pdest)],"%02x ",(pByte)[c]);
}
