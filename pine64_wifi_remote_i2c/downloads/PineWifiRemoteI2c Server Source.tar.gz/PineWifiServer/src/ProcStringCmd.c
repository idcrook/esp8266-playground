/*
 * ProcStringCmd.c
 *
 *  Created on: Mar 13, 2016
 *      Author: khgoh
 */

#include "ProcStringCmd.h"
#include "TcpServerConn.h"
#include "TcpSendCmd.h"
#include "ConsoleServer.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "strfunc.h"

#define maxStrCmd  50 //maximum number of command.
#define InputBufSize	260


#define PrintString(fd,str) do {\
		TscSendData((fd),(uint8_t*)str, strlen(str));\
}while(0)

#define PrintPrompt(fd) do {\
		TscSendData((fd),(uint8_t*)strPrompt, strlen(strPrompt));\
}while(0)
#define PrintACK(fd) do {\
		TscSendData((fd),(uint8_t*)strAck, strlen(strAck));\
}while(0)
#define PrintNACK(fd) do {\
		TscSendData((fd),(uint8_t*)strNAck, strlen(strNAck));\
}while(0)



//command constant definition
//do not change the sequence number.
typedef enum {
	cmdID_help  	=	0,
	cmdID_list		,
	cmdID_i2cpoll	,
	cmdID_i2cread	,
	cmdID_i2cwrite	,
	cmdID_setio		,
	cmdID_setrelay	,
	cmdID_i2cstart  ,
	cmdID_i2cstop	,
	cmdID_cfgporttype ,
	cmdID_settimeout,
	cmdID_exit		,
	cmdID_unknow	,
} strcmdID;

//the command list sequence must follow strcmdID command index sequence
const char strCmd[]= {
		"help list "
		"i2cpoll i2cread i2cwrite "
		"setio setrelay i2cstart i2cstop cfgport settimeout exit"
	};

char strHelpMsg[]= {
		"*** Command Sending Remote Client\r\n"
		"help      - show this help message\r\n"
		"list      - list the currently connected client\r\n"
		"    Reply format: LIST [ClientIndex] [Mac] [IP] [Version] [FWID] [online] [rssi]\r\n"
		"i2cstart   - Start the I2c port\r\n"
		"    Send format : i2cstart [ClientIndex]\r\n"
		"    Reply format: I2CSTART [ClientIndex] [ACK/NACK]\r\n"
		"i2cpoll   - Send I2c poll command\r\n"
		"    Send format : i2cpoll [ClientIndex] [I2cID]\r\n"
		"    Reply format: I2CPOLL [ClientIndex] [ACK/NACK]\r\n"
		"i2cread   - Read I2c device memory\r\n"
		"    Send format : i2cread [ClientIndex] [I2cID] [Addr] [ByteSizeInHex]\r\n"
		"    Reply format: I2CREAD [ClientIndex] [ACK/NACK] [ByteSizeInHex] [databyteInHex]\r\n"
		"i2cwrite  - write to I2c device\r\n"
		"    Send format : i2cwrite [ClientIndex] [I2cID] [Addr] [ByteSizeInHex] [DataBytesInHex]\r\n"
		"    Reply format: I2CWRITE [ClientIndex] [ACK/NACK]\r\n"
		"setio - set the I/O port status\r\n"
		"    Send format : setio [ClientIndex] [1ByteI/OMask] [1ByteI/OStatus]\r\n"
		"    Reply format: SETIO [ClientIndex] [ACK/NACK] [ByteSizeInHex] [1ByteI/OStatus]\r\n"
		"cfgport - set the I/O pin as input or output\r\n"
		"    send format : cfgport [ClientIndex] [1BytePortType]\r\n"
		"    Reply format: CFGPORT [ClientIndex] [ACK/NACK]\r\n"
		"setrelay - set the relay on/off\r\n"
		"    Send format : setrelay [ClientIndex] [1ByteStatus]\r\n"
		"    Reply format: SETRELAY [ClientIndex] [ACK/NACK]\r\n"
		"exit - quit the console\r\n"
		"*** Message push Out from server/remote clinet\r\n"
		"OFFLINE - indicate remote client just offline\r\n"
		"    Received format : OFFLINE [ClientIndex]\r\n"
		"ONLINE - indicate remote client just online\r\n"
		"    Received format : ONLINE [ClientIndex] [MACaddr] [IPAddr]\r\n"
		"TIMEOUT - indicate last send command time out\r\n"
		"    Received format : TIMEOUT [ClientIndex] [cmd] .\r\n"
		"I2CINTR - received i2c interrupt\r\n"
		"    Received format : I2CINTR [ClientIndex]\r\n"
		"INPORTCHANGE - Input changes report\r\n"
		"    Received format : INPORTCHANGE [ClientIndex] [ChangesMask] [IOCurrStatus]\r\n"
	};

const char strPrompt[]= {">"};
const char strAck[]={"ACK\r\n"};
const char strNAck[]={"NACK\r\n"};

char *pTokenCmd[maxStrCmd];
uint16_t totalCmd=0;
char inputbuffer[InputBufSize];
extern int csref; //declare in Console Server.


//////////////////// Function Prototype //////////////////////
//match the command and convert into index
strcmdID ProcStrDecodeCmd(char *strCmd);
/*
 * Process the command string
 */
void processRxString(int fd, char *str) ;
/////////////////// Public function /////////////////////////
/*
 * Call once to init the module
 */
int ProcStrInit(void)
{
	char *tmpcmd;
	char *ptr1,*ptr2;
	tmpcmd=(char*)malloc(strlen(strCmd)+1);
	//indexing all the command from the command list
	if (tmpcmd) {
		strcpy(tmpcmd,strCmd);
		for ((ptr1=strtok_r(tmpcmd," ",&ptr2));ptr1;(ptr1=strtok_r(NULL," ",&ptr2)))
		{
			pTokenCmd[totalCmd]=(char*)malloc(strlen(ptr1)+1);
			if (pTokenCmd[totalCmd])
			{
				strcpy(pTokenCmd[totalCmd],ptr1);
				totalCmd++;
			}
			else
			{
				//cannot allocate memory, error return.
				free(tmpcmd);
				return(0);
			}

			if (totalCmd>=maxStrCmd) {
				//reach the max number of command.
				free(tmpcmd);
				return(0);
			}
		}
		//done
		free(tmpcmd);
		return(1);
	}
	return(0);
}

/*--------------------------------------------------------------------------
 * Processing input from the Console and send it to the Remote Client
 */

/*
 * Call to process the received string from console
 * will only call string processing when detected \r or \n.
 */
void ProcStrRx(int fd, uint8_t *str, uint16_t strsize)
{
	static uint8_t rxbuf[InputBufSize];
	static uint16_t index=0;
	uint16_t leftoverbyte=strsize;
	uint16_t rxindex=0;
	while(leftoverbyte) {
		if (str[rxindex]=='\n'||str[rxindex]=='\r') {
			rxbuf[index]=0; //set string end of line
			if (strlen((char*)rxbuf)>0) {
				//call to process the string
				processRxString(fd,(char*)rxbuf);
				if (!isConsoleBusy(fd)) PrintPrompt(fd);
			}

			index=0;
		}
		else {
			rxbuf[index]=str[rxindex];
			index++;
			//check for input buffer over flow
			//should not happen under normal condition.
			if (index==InputBufSize-1)
			{
				index=0;
			}
		}
		rxindex++;
		leftoverbyte--;
	}
}



//match the command and convert into index
strcmdID ProcStrDecodeCmd(char *strCmd)
{
	int c=0;
	for(c=0;c<totalCmd;c++)
	{
		if(strcmp(pTokenCmd[c],strCmd)==0)
		{
			return(c);
		}
	}
	return(cmdID_unknow);
}

/*
 * Process the command string
 */
void processRxString(int fd, char *str) {
    char *ptr1=0,*ptr2=0;
    strcmdID cmdcode;
    char *_ch_sep=" \r\n";
    remoteclient_t **pRClient;
    uint16_t totalclient;
    char tmpstr[1100]={0};
    int c=0;
    struct in_addr tmpip;
    uint8_t pData[256]={0};
    int totalbyte=0;
    int expectedbyte;
    int clientIndex;
    uint16_t value;

    if (strlen>0) {
    	ptr1=strtok_r((char*)str,_ch_sep,&ptr2);
    	if (ptr1) {
    		cmdcode=ProcStrDecodeCmd(ptr1);
    		switch(cmdcode)
			{
    		case cmdID_help  	:
    			PrintString(fd,strHelpMsg);
    			break;


    		case cmdID_list		:
    			pRClient=GetRemoteClientList(&totalclient);
    			tmpstr[0]=0;
				for (c=0;c<totalclient;c++)
				{
					tmpip.s_addr=pRClient[c]->ipaddr;
					sprintf(&tmpstr[strlen(tmpstr)],"LIST %d "MACSTRFORMAT" %s "FW4BYTEFORMAT" "FW2BYTEFORMAT" %d %ddBm\r\n",
							c,MACVAR(pRClient[c]->macaddr),inet_ntoa(tmpip),
							FW4BYTEVAR(pRClient[c]->fwVersion),FW2BYTEVAR(pRClient[c]->fwID),pRClient[c]->online,pRClient[c]->rssi);

					if (strlen(tmpstr)>1000) {
						PrintString(fd,tmpstr);
						tmpstr[0]=0;
					}
				}
				if (strlen(tmpstr)) {
					PrintString(fd,tmpstr);
					tmpstr[0]=0;
				}
    			break;
    		case cmdID_i2cstart :
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
				if (ptr1) {
					clientIndex=atol(ptr1);
					SendCmd_I2cStart(fd,clientIndex);
				}
				break;
    		case cmdID_i2cstop:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
					if (ptr1) {
						clientIndex=atol(ptr1);
						SendCmd_I2cStop(fd,clientIndex);
					}
    			break;
    		case cmdID_i2cpoll	:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
    			if (ptr1) {
					clientIndex=atol(ptr1);
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
												(ptr1 && totalbyte<1 );
												ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
					}
					SendCmd_I2cPoll(fd,clientIndex,pData[0]);
    			}
				break;
    		case cmdID_i2cread	:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
    			if (ptr1) {
					clientIndex=atol(ptr1);
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
							(ptr1 && totalbyte<3 );
							ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
					}
					Sendcmd_I2cRead(fd,clientIndex,pData[0],pData[1],pData[2]);
    			}
				break;
    		case cmdID_i2cwrite	:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
    			if (ptr1) {
					clientIndex=atol(ptr1);
					expectedbyte=3;
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
							(ptr1 && totalbyte< expectedbyte );
							ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
						//get the total datasize and update into the expectedbyte.
						if (totalbyte==(expectedbyte-1))
							expectedbyte+=pData[totalbyte];
					}
					SendCmd_I2cWrite(fd,clientIndex,pData[0],pData[1],pData[2],(&pData[3]));
    			}
				break;
    		case cmdID_setio	:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
    			if (ptr1) {
					clientIndex=atol(ptr1);
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
							(ptr1 && totalbyte< 2 );
							ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
					}
					SendCmd_SetIO(fd,clientIndex,pData[0],pData[1]);
    			}

				break;
    		case cmdID_cfgporttype :
				ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
				if (ptr1) {
					clientIndex=atol(ptr1);
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
							(ptr1 && totalbyte< 2 );
							ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
					}
					SendCmd_CfgIO(fd,clientIndex,pData[0],pData[1]);
				}

				break;
    		case cmdID_setrelay	:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the client index.
    			if (ptr1) {
					clientIndex=atol(ptr1);
					for(ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte=0;
							(ptr1 && totalbyte< 1 );
							ptr1=strtok_r(NULL,_ch_sep,&ptr2),totalbyte++)
					{
						if (!HexByteStrToByte(ptr1,&pData[totalbyte])) {
							//convert fail
							break;
						}
					}
					SendCmd_SetRelay(fd,clientIndex,pData[0]);
    			}

				break;
    		case cmdID_settimeout:
    			ptr1=strtok_r(NULL,_ch_sep,&ptr2); //get the timeout value
				if (ptr1) {
					value=atol(ptr1);
					TcpReconfigCmdReturnTimeout(value);
				}
    			break;
    		case cmdID_exit		:
    			TscCloseConnection(fd);
    			break;
    		case cmdID_unknow	:
    		default:
    			break;
			}
    	}

    }

}

/*----------------------------------------------------------------------
 * process the respond received from Remote client and print it out
 * into the current console
 */


#define RetType1Result(ptmpStr,clientIndex,pResStr,pCmdStr,size,pdata) do{\
	if (size==0) {\
		sprintf((ptmpStr),"%s %d %s\r\n",(pCmdStr),(clientIndex),(pResStr));\
	}\
	else {\
		sprintf((ptmpStr),"%s %d %s %02x",(pCmdStr),(clientIndex),(pResStr),size);\
		HexToStr(pdata,size,&((ptmpStr)[strlen((ptmpStr))]));\
		sprintf(&((ptmpStr)[strlen((ptmpStr))]),"\r\n");\
	}\
}while(0)




void ProcClientReturnResultCB(int consoleFD,uint16_t clientIndex,
					clientCmd_t cmd,clientRespond_t res,
					uint8_t size, uint8_t* pdata)
{
	char strtmp[1000]={0};
	char strRes[100]={0};
	char strcmd[100]={0};
	uint16_t printformat=0;


	switch (cmd)
	{
	case cmd_i2cpoll:
		sprintf(strcmd,"I2CPOLL");
		break;
	case cmd_i2cread:
		sprintf(strcmd,"I2CREAD");
		break;
	case cmd_i2cwrite:
		sprintf(strcmd,"I2CWRITE");
		break;
	case cmd_i2cstart:
		sprintf(strcmd,"I2CSTART");
		break;
	case cmd_i2cstop:
		sprintf(strcmd,"I2CSTOP");
		break;
	case cmd_setio:
		sprintf(strcmd,"SETIO");
		break;
	case cmd_relay:
		sprintf(strcmd,"SETRELAY");
		break;
	case cmd_cfgporttype:
		sprintf(strcmd,"CFGPORT");
		break;
	default:
		sprintf(strcmd,"");
		break;
	}

	switch (res) {
	case resAck:
		sprintf(strRes,"ACK");
		printformat=1;
		break;
	case resNack:
		sprintf(strRes,"NACK");
		printformat=1;
		break;

	case resDrvIdle: //currently the server is idle
		//Print prompt is receive an idle signal
		if (consoleFD>=0) PrintPrompt(consoleFD);
		return;

	default:
		sprintf(strRes,"");
		break;
	}

	if (printformat==1) {
		//create result reply from remote client
		RetType1Result(strtmp,clientIndex,strRes,strcmd, size,pdata);
	}
	else {
		//create the push message received from remote client
		remoteclient_t *remoteClient=GetRemoteClient(clientIndex);
		struct in_addr tmpip;
		if (remoteClient) {
			tmpip.s_addr=remoteClient->ipaddr;
			switch (res) {
			case resPush:
				if (cmd==push_i2cIntr) {
					sprintf((strtmp),"I2CINTR %d\r\n",clientIndex);
				}
				if (cmd==push_InPortChanged) {
					sprintf((strtmp),"INPORTCHANGE %d %02x %02x\r\n",clientIndex,pdata[0],pdata[1]);
				}
				break;
			case resClientOnline:
				sprintf((strtmp),"ONLINE %d "MACSTRFORMAT" %s\r\n",clientIndex,
						MACVAR(remoteClient->macaddr),inet_ntoa(tmpip));
				break;
			case resClientOffline:
				sprintf((strtmp),"OFFLINE %d\r\n",clientIndex);
				break;
			case resTimeOut:
				sprintf((strtmp),"TIMEOUT %d %s\r\n",clientIndex,strcmd);
				break;
			default:
				break;
			}
		}
	}

	//Send out the result to the console.
	if (strtmp[0]) {
		if (consoleFD>=0) {
			TscSendData(consoleFD, (uint8_t*)strtmp,strlen(strtmp));
		}
		else {
			TscBroadcast(csref,(uint8_t*)strtmp,strlen(strtmp));
		}
	}
}

