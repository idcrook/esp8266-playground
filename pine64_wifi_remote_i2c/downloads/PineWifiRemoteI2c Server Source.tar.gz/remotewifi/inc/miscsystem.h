/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * miscsystem.h
 *
 *  Created on: Jul 2, 2015
 *      Author: khgoh
 */

#ifndef INC_MISCSYSTEM_H_
#define INC_MISCSYSTEM_H_
#include <stdint.h>
#include <unistd.h>

extern char osname[]; //keeping the osname

/*
 * Call to init the system
 */
void MSystem_Init(void);

/*
 * Return true if ethernet link is up
 */
int MSystem_isEthUp(void);

/*
 * Return true if wifi link is up
 */
int MSystem_isWifiUp(void);

/*
 * Get the Mac address of the interface
 */
uint8_t *GetIfMacAddr(char *ifname);

/*
 * Call to reboot the system
 */
void RequestSystemReboot(void);
/*
 * Return the pid of the program.
 */
pid_t MSystem_Getpid(char *progName);

/*
 * Call to kill all the process with the progName
 */
void MSystem_KillProcess(char *progName);
/*
 * Call to execute a program
 */
void MSystem_ExecuteWait(const char *command);
void MSystem_Execute(const char *command);
void MSystem_Execute2(const char *command,int screen);
/*
 * return number of instance is running.
 */
int MSystem_CountRunningInstance(char *myProgName);
/*
 * Return number of path in the dirlist. Will return 0 is no path exist.
 * dirlist- Return the path of mounted VFat and under directory /media
 * each path is space separated.
 * size- Memory size provide by caller app in dirlist
 */
int MSystem_GetVFatDir(char *dirlist,uint16_t size);
/*
 * return the X11 display screen number and lightdm pid
 */
int MSystem_GetXDiplayNumber(int *pDispNumber,pid_t *pProcess);
/*
 * Return the file creation time in 2 part int long (sec and nsec) string.
 */
char *getFileCreationTime(char *fn);
/*
 * Clear the System Console screen
 */
void SysConsole_ClrScr(void);
/*
 * Output String to System Console Screen
 */
void SysConsole_WriteScr(char *text);
/*
 * find the network interface full name
 * base on text matching from ifID
 * eg. eth will produce eth0 or eth1.
 * return true if found the match.
 */
int getiface(char *pifID, char *pResult);

/*
 * Get system uptime from OS uptime command
 * User App Pass pointer of hour,min,Sec
 * if return true, the variable will contain the result
 */
int getuptime(int *pHour,int *pMin,int *pSec);
#endif /* INC_MISCSYSTEM_H_ */
