/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef __CRC_UPDATE_H__
#define __CRC_UPDATE_H__

#include <inttypes.h>
/*
 * Support 3 type of CRC calculation, CRC CCITT, CRC16 and CRC XModem (default)
 */

#if defined CRC_CCITT
#define crc_update(crc,data) crc_ccitt_update(crc,data)
uint16_t   crc_ccitt_update (uint16_t crc, uint8_t data);


#elif defined CRC16
#define crc_update(crc,data) crc16_update(crc,data)
uint16_t  crc16_update(uint16_t crc, uint8_t a);

#else
#define crc_update(crc,data) crc_xmodem_update(crc,data)
uint16_t  crc_xmodem_update (uint16_t crc, uint8_t data);
#endif

/*
 * Cal the crc and put it at the end of the packet.
 * size if the total data size including the CRC byte.
 */
void  CalCRC(uint8_t *pData, uint16_t size);
/*
 * Cal the crc and put it at pcrc.
 * size if the total data size Not including CRC byte.
 */
void  CalCRC_Location(uint8_t *pData, uint16_t size, uint8_t *pcrc);

/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
uint16_t  CheckCRC(uint8_t *data, uint16_t size);
/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
uint16_t  CheckCRC_Location(uint8_t *data, uint16_t size, uint8_t *pcrc);

#endif
