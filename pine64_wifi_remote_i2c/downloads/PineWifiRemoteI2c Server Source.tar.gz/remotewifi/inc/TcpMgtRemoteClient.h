/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * TcpMgrRemoteClient.h
 *
 *  Created on: Mar 12, 2016
 *      Author: khgoh
 */

#ifndef TCPMGTREMOTECLIENT_H_
#define TCPMGTREMOTECLIENT_H_

#include <inttypes.h>
#include "TcpSendCmd.h"

/*
 * return true if success.
 */
uint16_t MgtClientInit(uint16_t maxRemoteClient);
/*
 * Insert the client into the list, will return the
 * index of the client.
 * if fail to insert will return -1
 */
int MgtClientInsert(int clientFD,remoteclient_t *client);

/*
 * Manage the busy flag fo the client
 */
uint16_t MgtIsClientBusy(int clientIndex,clientCmd_t *lastcmd);
void MgtSetClientBusy(int clientIndex, uint8_t cmd,int consoleFD);
void MgtClrClientBusy(int clientIndex);

/*
 * Set the client offline
 */
void MgtClientOffline(int clientIndex);
/*
 * Set the client online
 */
void MgtClientOnline(int clientIndex);
/*
 * Return the array pointer to the array of remoteclient_t list
 * pTotalClient - return total number of client, caller must provide the memory space
 */
remoteclient_t **MgtClinetGetList(uint16_t *pTotalClient);
/*
 * Return the  pointer to the remoteclient_t list
 */
remoteclient_t *MgtClinetGet(uint16_t clientIndex);
/*
 * Get the connection FD of the client
 * Will return -1 if client not available or offline.
 */
int MgtClientGetFD(int clientIndex);
/*
 * Clear the Nop Pending flag once received the Nop reply
 */
void MgtClearNopPending(int clientIndex);
/*
 * Set the Nop Pending flag when sending the Nop during idle
 */
void MgtSetNopPending(int clientIndex);
/*
 * Get the client index from fd
 * return -1 if cannot find.
 */
int MgtClientGetIndex(int fd);
/*
 * Update the RSSI value of the client
 */
void MgtClientUpdRSSI(int fd,int8_t rssi);

/*
 * Set the default time out when the client is idle too long
 * idleTimeOut is in resolution of 0.1 second
 * callback function need to reset the busy timer.
 */
void MgtSetIdleTimeout(long idleTimeOut, void (*cb)(int clientIndex));

/*
 * return true if current waiting for client reply
 */
uint8_t MgtClientIsbusyNow(int consoleFD);
/*
 * Set the busy time out waiting for command to return from client.
 * busyTimeOut is in resolution of millisecond
 * callback function need to reset the busy timer.
 */
void MgtSetBusyTimeout(long busyTimeOut, void (*cb)(int clientIndex, int consoleFD, clientCmd_t lastcmd));
/*
 * Reconfigure the command send wait time without changing the callback function.
 */
void MgtResetBusyTimeout(long busyTimeOut);
/*
 * keep the last send packet into the memory.
 */
void MgtSaveLastSendPkt(int fd, uint8_t *pData, uint16_t size);
/*
 * return the saved last send packet
 * caller prove space to keep the pSize, will return ptr to the data byte.
 * every call will increase the resent counter.
 */
uint8_t* MgtGetLastSendPkt(int clientIndex,uint16_t* pSize);
/*
 * Get the number of tcp packet resent counter
 */
uint16_t MgtGetResentCount(int clientIndex);
/*
 * Register callback to handle client off-line
 */
void MgtSetClientOfflineCB(void (*cb)(uint16_t clientIndex));
/*
 * Return the current console FD
 */
int MgtGetConsoleFD(int clientIndex);

#endif /* TCPMGTREMOTECLIENT_H_ */
