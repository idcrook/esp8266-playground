/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * pktcreate.h
 *
 *  Created on: Apr 20, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_PKTCREATE_H_
#define SHAREINCLUDE_PKTCREATE_H_
#include <inttypes.h>

/*
 * Packet format
 * STX(1byte), Len(1byte), Cnt(1byte), MacAddr(6byte), Result(1byte), Cmd(1byte),Data(Variable), CRC(2byte)
 * Index Data
 * 0	STX
 * 1	Len
 * 2	Cnt
 * 3	Mac
 * 9	Result
 * 11 	CMD/Data
 * Len-2 CRC(L)
 * Len-1 CRC(H)
 */
#define STXBYTE			(0x02)

#define PKTINDEX_LEN		(1)
#define PKTINDEX_Cnt		(2)
#define PKTINDEX_MAC		(3)
#define PKTINDEX_RSSI  		(9)
#define PKTINDEX_Result		(10)
#define PKTINDEX_DATA 		(11)

//extra byte other then the CMD/data
// Which include, STR(1B), Len(1B), Cnt(1B), Mac(6B),Result(1B), RSSI(1B)
#define TXPKT_ExtraPayloadByte (13)

/*
 * Call to request memory to create the reply or push packet
 * Will return the pointer to memory to keep the payload D0..Dn.
 * datasize -> data size to send, D0 to Dn (Excluding Cmd byte)
 * return true if memory is ready
 */
uint8_t  pktc_request(int clientIndex, uint8_t **pMemorySpace,uint16_t datasize);
/*
 * Call the calculate and create the packet for sending.
 */
void  pktc_create(uint8_t result,uint8_t Cmd);
/*
 * Call after pktc_create to get the created packet for sending out.
 */
uint8_t  *pktc_Get(uint16_t *pPktSize);
/*
 * Call after finish sending the packet. no more needing the data.
 */
void  pktc_done(void);

/*
 * 			Require to create a return packet
 * 							|
 *          ## Call pktc_request to get the memory space to kept the tx data
 * 							|
 * 			Fill in the CMD D0..Dn into the memory space
 * 							|
 * 			## Call create to finish the packet creating process
 * 							|
 * 				## Call pktc_Get to get the packet pointer
 * 							|
 * 				Send out the packet
 * 							|
 * 				## Call pktc_done to free the memory
 *
 */




/*
 * Do a CRC check the Rx data.
 * return true if the data is ready for process.
 * will also return the pointer to the CMD/Data byte in the packet.
 *   CMD D0...Dn
 * pSize -> to return the total byte size of Dn byte (excluding the CMD Byte).
 */
uint8_t  pktc_rxPecket(uint8_t *pData, uint8_t **pMac,uint8_t **pResult, uint8_t **pCmdData, uint16_t *pSize, uint8_t **pRSSI);


#endif /* SHAREINCLUDE_PKTCREATE_H_ */
