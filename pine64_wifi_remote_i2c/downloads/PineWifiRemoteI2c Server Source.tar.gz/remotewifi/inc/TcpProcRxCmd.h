/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * TcpProcRxCmd.h
 *
 *  Created on: Mar 12, 2016
 *      Author: khgoh
 */

#ifndef TCPPROCRXCMD_H_
#define TCPPROCRXCMD_H_
#include <inttypes.h>
#include "TcpSendCmd.h"

/*
 * Register the device tcp cmd return callback.
 * Will do this callback when received a valid TCP packet from remote
 * client or any valid message need to return back to the upper level application.
 */
void RegTcpProcRxCmdCB(void (*cb)(int consoleFD, uint16_t clientIndex,clientCmd_t cmd,clientRespond_t res, uint8_t size, uint8_t* pdata));

/*
 * call to return command send/reply error
 */
void TcpReturnError(int consoleFD,uint16_t clientIndex, clientCmd_t cmd);

/*
 * call to return command timeout
 */
void TcpReturnTimeOut(int consoleFD, uint16_t clientIndex, clientCmd_t cmd);

/*
 * Tcp Connected Callback
 * Callback when a remote client connected
 */
void TcpConnectedCB(int fd,struct sockaddr* pRemoteAddr);

/*
 * Tcp Data received callback
 * Callback when received raw data from remote client
 */
void TcpDataRxCB(int fd, uint8_t *pData, uint16_t size);

/*
 * Tcp connection disconnected callback
 * Callback when remote client disconnected
 */
void TcpDisconnectedCB(int fd);
/*
 * Call to set remote client to off line status
 */
void TcpSetClientOffline(uint16_t clientIndex);

#endif /* TCPPROCRXCMD_H_ */
