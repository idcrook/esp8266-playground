/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * tcpCommandList.h
 *
 *  Created on: May 16, 2015
 *      Author: khgoh
 */

#ifndef SHAREINCLUDE_TCPCOMMANDLIST_H_
#define SHAREINCLUDE_TCPCOMMANDLIST_H_

typedef enum {
	TCP_ACK=0x80,	//Return result Ack
	TCP_NACK=0x81,	//Return result NACK
	TCP_ACKRT2=0x90,	//Client Push Command to Server

}tcpAckState;

/*
 * TCP Command List
 */
//System Command

#define Cmd01_Nop					(0x01)
#define Cmd02_HWINFO				(0x02)
// Data: fwid(2B),fwVer(4B)
#define Cmd03_HWSTATUS				(0x03)

#define Cmd11_I2CPOLL				(0x11)
//	Data: Addr
#define Cmd12_I2CREAD				(0x12)
//	Data: Addr, Location, Len
#define Cmd13_I2CWRITE				(0x13)
//	Data: Addr, Location, Len, Data
#define Cmd14_I2CSTART				(0x14)

#define Cmd15_I2cDisable			(0x15)

#define Cmd16_I2cIntr				(0x16)

#define Cmd20_PWMENABLE				(0x20)
#define Cmd21_PWMCFG				(0x21)

#define Cmd30_SET_IO				(0x30)
// Data: iomask, iostatus
#define Cmd31_RELAY					(0x31)
// Data: status
#define Cmd32_SET_PORT				(0x32)
// Data: PortSetting
#define Cmd33_PUSH_IP_STATUS 		(0x33) //Push input status.

#define Cmd40_SPIENABLE				(0x40)
#define Cmd41_SPICFG				(0x41)
#define Cmd42_SPIRXTX				(0x42)



#endif /* SHAREINCLUDE_TCPCOMMANDLIST_H_ */
