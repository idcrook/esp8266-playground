/*
 *  Disclaimer and terms of usage
 *  -----------------------------
 *  Redistribution and use in source and binary forms, with or without modification,
 *  are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 *  THE POSSIBILITY OF SUCH DAMAGE.
*/
/*
 * TcpSendCmd.h
 *
 *  Created on: Mar 11, 2016
 *      Author: khgoh
 */

#ifndef TCPSENDCMD_H_
#define TCPSENDCMD_H_

#include <inttypes.h>
#include <netinet/ip.h>
#include <netinet/in.h>

/*
 * System constant definition
 */
//do not change the enum number assignment.
typedef enum {
	resAck,
	resNack,
	resPush,
	resClientOnline,
	resClientOffline,
	resTimeOut,
	resDrvIdle,
}clientRespond_t;

//do not change the enum number assignment.
//the sequence number must according to cmdcode[]
typedef enum {
	cmd_pushmsg=0,
	cmd_i2cpoll, cmd_i2cread, cmd_i2cwrite, cmd_i2cstart, cmd_i2cstop, push_i2cIntr,
	cmd_setio, cmd_relay, cmd_cfgporttype, push_InPortChanged,
}clientCmd_t;

///////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Structure definition
 */
//structure keeping the detail of each client
typedef struct{
	uint8_t macaddr[6];		//remote i/o device mac address
	in_addr_t ipaddr; 	//remote i/o device ip address
	uint8_t fwVersion[4];	//remote i/o device firmware version
	uint8_t fwID[4];		//remote i/o device firmware ID
	uint8_t online; 		//0=offline, 1=online
	int8_t  rssi;
}remoteclient_t;

///////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Function prototype
 */
/*
 * Call once to init and startup the tcp server
 * maxClient - maximum number of
 *  remote client allow to connect at the same time
 * idleTimeOut - period of no activities before closing the remote client.In unit of ms per count.
 * cmdReturnTimeout - period for the Remote Client to return requested command. In unit of 0.1seccond per count.
 * rxResultCB is call when there is result return from remote client
 *   consoleFD - Command Requester FD, if -1, message is for all the console
 *   clientIndex - Remote client reference
 *   cmd - requesting command
 *   res - the command respone
 *   size - total byte point by pdata
 *   pdata - point to the return data.
 *
 * return true on success.
 */
uint16_t TcpSendCmdInit(uint16_t maxRemoteClient, uint16_t idleTimeOut,
				uint16_t cmdReturnTimeout,
				void (*rxResultCB)(int consoleFD,uint16_t clientIndex,
						clientCmd_t cmd,clientRespond_t res,
						uint8_t size, uint8_t* pdata));

/*
 * Reconfigure the cmdReturnTimeout value in millisecond.
 */
void TcpReconfigCmdReturnTimeout(uint16_t cmdReturnTimeout);
/*
 * Each remote client will be represented with and cliendindex
 * which is the index of structure remoteclient_t.
 * Will return the array pointer to the remoteclient_t pointer
 * If currently no device in the list, it will return NULL.
 */
remoteclient_t **GetRemoteClientList(uint16_t *pTotalClient);

/*
 * return the remote client info for given clientIndex
 */
remoteclient_t *GetRemoteClient(uint16_t clientIndex);


/*
 * Register the call back function when the client respond from the last
 * command send.
 * clientIndex - the index number of the remote client in GetRemoteClientList
 * cmd - command of the data return
 * res - result of the cmd. if cmd=0, will return clientonline or clientoffline result
 * size - size of the data return in pdata
 * pdata - pointer to the data return from the remote client
 */
void RegisterCmdCallBack(void (*cb)(uint16_t clientIndex,clientCmd_t
						cmd,clientRespond_t res, uint8_t size, uint8_t* pdata));

///////////////////////////////////////////////////////////////////////////////////////////////////


/*
 * Call the start the I2c bus. Once started, SendCmd_SetIO will not change the
 * status of the I2c bus.
 */
uint16_t SendCmd_I2cStart(int consoleFD, uint16_t clientIndex);
/*
 * Send I2cStop to remote client
 */
uint16_t SendCmd_I2cStop(int consoleFD, uint16_t clientIndex);
/*
 * I2c Poll for a device on the i2c bus
 */
uint16_t SendCmd_I2cPoll(int consoleFD, uint16_t clientIndex, uint8_t i2cID);
/*
 * Read the i2c device memory starting at location addr with total byte to read = size
 */
uint16_t Sendcmd_I2cRead(int consoleFD, uint16_t clientIndex, uint8_t i2cID, uint8_t addr, uint8_t datasize);
/*
 * Write data into the i2c device memory starting at location addr with total byte write=size
 * and pdata point to the data going to write into the device
 */
uint16_t SendCmd_I2cWrite(int consoleFD, uint16_t clientIndex, uint8_t i2cID,
							uint8_t addr, uint8_t datasize, uint8_t *pData);
/*
 * Set the I/O pin status of the remote I/O device
 * if the iomask bit is 1, the corresponding iostatus on the same bit will be set into the i/O port
 * It will also return the current status of the i/o port through the call back
 */
uint16_t SendCmd_SetIO(int consoleFD, uint16_t clientIndex, uint8_t iomask, uint8_t iostatus);
/*
 * Configure the I/O pin type of the remote I/O device
 * if the iomask bit is 1, the corresponding iocfg on the same bit will be configure.
 * iocfg bit=0 is Output Port, iocfg bit=1 is input port
 * It will also return the current status of the i/o port through the call back
 */
uint16_t SendCmd_CfgIO(int consoleFD, uint16_t clientIndex, uint8_t iomask, uint8_t iocfg);
/*
 * Set the relay on/off
 * status 0 = no action, just return the current status through the callback
 * status 1 = on
 * status 2 = off
 */
uint16_t SendCmd_SetRelay(int consoleFD, uint16_t clientIndex, uint8_t status);
/*
 * Return True if the console is waiting for reply.
 */
uint8_t isConsoleBusy(int fd);

#endif /* TCPSENDCMD_H_ */
