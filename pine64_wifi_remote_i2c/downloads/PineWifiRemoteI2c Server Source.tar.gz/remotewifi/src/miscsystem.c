/*
 * miscsystem.c
 *
 *  Created on: Jul 2, 2015
 *      Author: khgoh
 */
#include "miscsystem.h"

#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/reboot.h>
#include <sys/types.h>
#include <signal.h>
#include "TimerMgr.h"
#include <sys/wait.h>
#include <ctype.h>
#include <dirent.h>
#include "text.h"
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
//#include "managecfgfile.h"
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>

#if(0)
uint8_t macAddress[6];
char osname[50]={0};
char ethname[10]={0};	//keep eth interface name
char wlanname[10]={0};  //keep wlan interface name
char ethoperfile[40]={0}; //keep the eth operstate full filename
char wlanoperfile[40]={0}; //keep the wlan operstate full filename
void MSystem_CreateUSBMountDir(void);
void MSystem_SetupIfSetting(void);
/*
 * Get the Mac address of the interface
 */


static char *pMS_PidString=0;
#define MS_TMPSTRLEN 1024
#define MS_TMPSTRCMD 256
#define SHELL "/bin/sh"
char tmpReturnString[256];
void getOSName(void);


void MSystem_Init(void)
{
	getOSName();
	MSystem_CreateUSBMountDir();
	MSystem_SetupIfSetting();
}

/*
 * internal function to setup the if name and operstate filename
 */

void MSystem_SetupIfSetting(void){
	char iface[10];
	if (getiface("eth",iface)) {
		sprintf(ethoperfile,"/sys/class/net/%s/operstate",iface);
	}
	if (getiface("wlan",iface)) {
		sprintf(wlanoperfile,"/sys/class/net/%s/operstate",iface);
	}
}


/*
 * internal function to check if link is up.
 */
int MSystem_isLinkUp(char *fn_operstate)
{
	FILE * file;
	char line[MS_TMPSTRLEN];
	int result=0;

	if (fn_operstate[0]==0) return(0);
	file = fopen(fn_operstate,"r");
	if (file) {
		line[0]=0;
		if (fgets(line, MS_TMPSTRLEN, file)!=NULL)
		{
			printf("%s |%s|\r\n",fn_operstate,line);
			if(strcmp("up",strstrip(line))==0)
			{
				result=1;
			}
		}
		fclose(file);
	}
	return(result);
}

/*
 * Return true if wifi link is up
 */
int MSystem_isWifiUp(void)
{
	return(MSystem_isLinkUp(wlanoperfile));
}

/*
 * Return true if ethernet link is up
 */
int MSystem_isEthUp(void)
{
	return(MSystem_isLinkUp(ethoperfile));
}

int MSystem_isXlockfile(char *fn, int *pNumber) {
	char tmp[10];
	if (fn[0]=='.' && fn[1]=='X')
	{
		int c=2,x=0;;
		while(isdigit(fn[c]))
		{
			tmp[x]=fn[c];
			x++;c++;
		}
		tmp[x]=0;
		if (strcmp(&fn[c],"-lock")==0) {
			pNumber[0]=atoi(tmp);
			return(1);
		}
	}
	return(0);
}

/*
 * return the X11 display screen number and lightdm pid
 */
int MSystem_GetXDiplayNumber(int *pDispNumber,pid_t *pProcess)
{
	DIR           *d;
	struct dirent *dir;
	FILE * file;
	char line[MS_TMPSTRLEN];
	char fn[MS_TMPSTRCMD];
	pid_t xpid=MSystem_Getpid("X");
	if (xpid==0) return(0);

	d = opendir("/tmp");
	printf("pid:%u\r\n",xpid);

	if (d)
	{

		while ((dir = readdir(d)) != NULL)
		{


			if (strlen(dir->d_name)>=8)
			{

				if (MSystem_isXlockfile(dir->d_name,pDispNumber))
				{
					printf("filename: %s,disp#%d",dir->d_name,pDispNumber[0]);
					sprintf(fn,"/tmp/%s",dir->d_name);
					file = fopen(fn,"r");
					if (file) {
						line[0]=0;
						if (fgets(line, MS_TMPSTRLEN, file)!=NULL)
						{
							printf("|%s|\r\n",line);
							pProcess[0]=(pid_t)atol(strstrip(line));
							if (pProcess[0]==xpid){
								fclose(file);
								closedir(d);
								return(1);
							}
						}
						fclose(file);
					}
				}
			}
		}
		closedir(d);
	}

	printf("dir open error\r\n");
	return(0);
}

/*
 * return number of instance is running.
 */
int MSystem_CountRunningInstance(char *myProgName)
{
	pid_t pid;
	int instance=0;
	pid=MSystem_Getpid(myProgName);
	while(pid) {
		instance++;
		pid=MSystem_Getpid(NULL);
	}
	//printf("Total Instance of %s is %d \r\n",myProgName,instance);
	return(instance);
}
void MSystem_ExecuteWait(const char *command)
{
	pid_t pid;
	pid = fork ();
	if (pid == 0)
	{
		/* This is the child process.  Execute the shell command. */
		execl (SHELL, SHELL, "-c", command, NULL);
		_exit (EXIT_FAILURE);
	}
	else {
		/* This is the parant process. Wait until child is done */
		int status;
		pid_t result;

		do {
			result = waitpid(pid, &status, WNOHANG);
			usleep(50000);
		} while (result==0) ;
		/*
		if (result == 0) {
		  // Child still alive
		} else if (result == -1) {
		  // Error
		} else {
		  // Child exited
		}*/
	}
}
/*
 * will create the mount directory
 * under /media directory
 */
void MSystem_CreateUSBMountDir(void)
{
	char dirlist[]="usb usb0 usb1 usb2 usb3 usb4 usb5 usb6 usb7";
	char *pdir;
	char path[50];
	pdir=strtok(dirlist," ");
	do {
		sprintf(path,"/media/%s",pdir);
		DIR* dir = opendir(path);
		if (dir)
		{
			/* Directory exists. */
			closedir(dir);
		}
		else if (ENOENT == errno)
		{
			/* Directory does not exist. */
			sprintf(path,"mkdir /media/%s",pdir);
			MSystem_Execute(path);
		}
		else
		{
			/* opendir() failed for some other reason. */
		}
	}while ((pdir=strtok(NULL," ")));
}
/*
 * Call to execute a program
 */
void MSystem_Execute(const char *command)
{
	pid_t pid;
	pid = fork ();
	if (pid == 0)
	{
		/* This is the child process.  Execute the shell command. */
		execl (SHELL, SHELL, "-c", command, NULL);
		_exit (EXIT_FAILURE);
	}
}
/*
 * Require the screen number for xprogram.
 */
void MSystem_Execute2(const char *command,int screen)
{
	pid_t pid;

	pid = fork ();
	if (pid == 0)
	{
		char cmd[MS_TMPSTRLEN];
		sprintf(cmd,command,screen,screen);
		/* This is the child process.  Execute the shell command. */
		execl (SHELL, SHELL, "-c", cmd, NULL);
		_exit (EXIT_FAILURE);
	}
}
/*
 * Call to kill all the process with the progName
 */
void MSystem_KillProcess(char *progName)
{

	pid_t pid;

	pid=MSystem_Getpid(progName);
	while(pid) {
		printf("kill pid %lu\r\n",(unsigned long)pid);
		kill(pid,9);
		pid=MSystem_Getpid(NULL);
	}
}

/*
 * find the network interface full name
 * base on text matching from ifID
 * eg. eth will produce eth0 or eth1.
 * return true if found the match.
 * pResult must provide space to keep the result.
 */
int getiface(char *pifID, char *pResult)
{
	char ptmp[100];
	char cmd[100];
	int result=0;
	char *ptr1;
	sprintf(cmd,"ifconfig -a | grep %s",pifID);
	FILE *pCmd = popen(cmd , "r");

	if (fgets(ptmp,100,pCmd)!=NULL) {
		printf("result: %s\r\n",ptmp);
		ptr1=strtok(ptmp," "); //get the interface name string.
		printf("interface: %s\r\n",ptr1);
		strcpy(pResult,ptr1);
		printf("final interface: %s\r\n",pResult);
		result=1;
	}
	pclose(pCmd);
	return(result);
}
/*
 * Get system uptime from OS uptime command
 * User App Pass pointer of hour,min,Sec
 * if return true, the variable will contain the result
 */
int getuptime(int *pHour,int *pMin,int *pSec)
{
	char ptmp[50];
	FILE *pCmd = popen("uptime" , "r");
	char *ptr1,*ptr2;
	ptmp[0]=0;
	if (fgets(ptmp,50,pCmd)!=NULL) {
		pclose(pCmd);
		ptr1=strtok(ptmp," "); //get the time string.
		if (ptr1==NULL) return(0);
		ptr2=strtok(ptr1,":"); //get the hour
		pHour[0]=(int)strtol(ptr2,NULL,10);
		ptr2=strtok(NULL,":");	//get the minute
		pMin[0]=(int)strtol(ptr2,NULL,10);
		ptr2=strtok(NULL,":");	//get the second
		pSec[0]=(int)strtol(ptr2,NULL,10);
		return(1);
	}
	pclose(pCmd);
	return(0);
}
/*
 * Call to update variable osname
 */
void getOSName(void)
{
	char ptmp[50];
	int c;
	FILE *pCmd = popen("uname -r" , "r");
	ptmp[0]=0;
	if (fgets(ptmp,50,pCmd)!=NULL) {
		for (c=0;c<strlen(ptmp);c++) {
			if (ptmp[c]=='\n' || ptmp[c]=='\r') {
				ptmp[c]=0;
				break;
			}
		}
		strcpy(osname,ptmp);
	}
	pclose(pCmd);
}
/*
 * Return the file creation time in 2 part int long (sec and nsec) string.
 */
char *getFileCreationTime(char *fn)
{
    struct stat attr;
    stat(fn, &attr);
    //printf("Last modified time: %s", ctime(&attr.st_mtime));
    sprintf(tmpReturnString,"%ld %ld",attr.st_mtim.tv_sec,attr.st_mtim.tv_nsec);
    return(tmpReturnString);
}

/*
 * Return number of path in the dirlist. Will return 0 is no path exist.
 * dirlist- Return the path of mounted VFat and under directory /media
 * each path is space separated.
 * size- Memory size provide by caller app in dirlist
 */
int MSystem_GetVFatDir(char *dirlist,uint16_t size)
{
	char line[MS_TMPSTRLEN];
	char *dir;
	int totaldir=0;
	dirlist[0]=0;
	FILE *pCmd = popen("mount -l -t vfat | grep media" , "r");
	line[0]=0;
	while(fgets(line, MS_TMPSTRLEN, pCmd)!=NULL)
	{
		//printf("Line1: %s",line);
		dir=strtok(line," ");	//dev
		dir=strtok(NULL," ");	//"on"
		dir=strtok(NULL," ");	//mount directory
		if ((strlen(dir)+strlen(dirlist)+2)<=size)
		{
			sprintf(dirlist,"%s %s",dirlist,dir);
			totaldir++;
		}
	}
	pclose(pCmd);
	//printf("Result:%s\r\n",dirlist);
	return(totaldir);
}

/*
 * Call to return the pid of the runing program
 * If program is not running, it will return zero
 * The next subsequent call with progName=NULL will get the
 * subsequent pid (program with multiple pid) and will return 0 when
 * no more pid to return.
 */
pid_t MSystem_Getpid(char *progName)
{
	char line[MS_TMPSTRLEN];
	char tmpstrcmd[MS_TMPSTRCMD];
	pid_t pid;
	char *pToken;
	static char *pstrtok;

	if (progName) {
		//Clear the memory if previously already assigned
		if (pMS_PidString) free(pMS_PidString);
		pMS_PidString=0;

		//Create the command and call it.
		sprintf(tmpstrcmd,"pidof %s",progName);
		FILE *pCmd = popen(tmpstrcmd, "r");
		line[0]=0; //clear the line first
		fgets(line, MS_TMPSTRLEN, pCmd);
		pclose(pCmd);

		//create memory to keep the result.
		pMS_PidString=malloc(strlen(line)+1);
		if (!pMS_PidString) return(0);
		memset(pMS_PidString,0,strlen(line)+1);
		strcpy(pMS_PidString,line);

		//phase the line to each individual token
		pToken=strtok_r(pMS_PidString," ",&pstrtok);
		if (pToken){
			pid = strtoul(pToken, NULL, 10);
			return(pid);
		}
	}
	else if (pMS_PidString){
		//get the subsequent pid
		pToken=strtok_r(NULL," ",&pstrtok);
		if (pToken){
			pid = strtoul(pToken, NULL, 10);
			return(pid);
		}
	}
	return(0);
}



static void MSystem_RebootNow(int timerid, void *ptr)
{
	sync();
	reboot(RB_AUTOBOOT);
}
/*
 * Call to reboot the system
 */
void RequestSystemReboot(void)
{
	int timerid;
	timerid=TimerMgr_Create("Reboot",1000,0,&MSystem_RebootNow,NULL);
	TimerMgr_Start(timerid);
}
uint8_t *GetIfMacAddr(char *ifname)
{
	struct ifreq ifr;

	int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (sock == -1) { /* handle error*/ return(0);};


	strcpy(ifr.ifr_name, ifname);
	if (ioctl(sock, SIOCGIFFLAGS, &ifr) == 0) {
		if (! (ifr.ifr_flags & IFF_LOOPBACK)) { // don't count loopback
			if (ioctl(sock, SIOCGIFHWADDR, &ifr) == 0) {
				memcpy(macAddress, ifr.ifr_hwaddr.sa_data, 6);
				return(macAddress);
			}
		}
	}
	else { /* handle error */ return(0);}

    return(0);
}
/*
 * Clear the System Console screen
 */
void SysConsole_ClrScr(void)
{	char str[50];
	sprintf(str,"\033[H\033[J\r\n");
	SysConsole_WriteScr(str);
}
/*
 * Output String to System Console Screen
 */
void SysConsole_WriteScr(char *text)
{
	int fd = open("/dev/console", O_WRONLY);
    write(fd, text, strlen(text));
    close(fd);
}
#endif
