#include "crc_update.h"


#define hi8(x) ((uint8_t)((x)>>8))
#define lo8(x) ((uint8_t)((x)))    

uint16_t  crc_xmodem_update (uint16_t crc, uint8_t data)
{
    int i;
    uint16_t tmpdata=data;
    uint16_t tmpcrc=crc;
    
    tmpcrc = tmpcrc ^ ((uint16_t)tmpdata << 8);
    for (i=0; i<8; i++)
    {
        if (tmpcrc & 0x8000)
            tmpcrc = (tmpcrc << 1) ^ 0x1021;
        else
            tmpcrc <<= 1;
    }

    return tmpcrc;
}


/*
 * Cal the crc and put it at the end of the packet.
 * size if the total data size including the CRC byte.
 */
void  CalCRC(uint8_t *pData, uint16_t size)
{
	uint16_t c;
	uint16_t crcresult=0;
	for (c=0;c<size-2;c++)
	{
		crcresult=crc_update(crcresult,pData[c]);
	}
	pData[size-2]=(crcresult) ; //crc byte LSB first then MSB
	pData[size-1]=(crcresult>>8);
}

/*
 * Cal the crc and put it at pcrc.
 * size if the total data size Not including CRC byte.
 */
/*
void  CalCRC_Location(uint8_t *pData, uint16_t size, uint8_t *pcrc)
{
	uint16_t c;
	uint16_t crcresult=0;
	for (c=0;c<size;c++)
	{
		crcresult=crc_update(crcresult,pData[c]);
	}
	pcrc[0]=(crcresult) ; //crc byte LSB first then MSB
	pcrc[1]=(crcresult>>8);
}
*/


/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
uint16_t  CheckCRC(uint8_t *data, uint16_t size)
{
  uint16_t tmpcrc=0;
  uint16_t c;
  uint8_t crc1,crc2;

  for (c=0; c<(size-2); c++) {
    tmpcrc=crc_update(tmpcrc,data[c]);
  }

  crc1=(uint8_t)(tmpcrc & 0xff);
  crc2=(uint8_t)((tmpcrc>>8) & 0xff);

  if ((crc1 == data[size-2]) && (crc2 == data[size-1]))
  {
	  //compare with the original CRC byte
    return (1);
  }
  else {
    return (0);
  }
}

/*
 *Check the Rx packet CRC.
 *return true if crc is corrent
 *	else return false.
 */
/*
uint16_t  CheckCRC_Location(uint8_t *data, uint16_t size, uint8_t *pcrc)
{
  uint16_t tmpcrc=0;
  uint16_t c;

  for (c=0; c<(size); c++) {
    tmpcrc=crc_update(tmpcrc,data[c]);
  }

  if (((uint8_t)tmpcrc == pcrc[0] )&&
      (((uint8_t)(tmpcrc >> 8) ) == pcrc[1]))
  {
	  //compare with the original CRC byte
    return (1);
  }
  else {
    return (0);
  }
}
*/
