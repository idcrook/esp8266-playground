/*
 * TcpMgrRemoteClient.c
 *
 *  Created on: Mar 12, 2016
 *      Author: khgoh
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <TcpMgtRemoteClient.h>
#include "TcpSendCmd.h"
#include "TimerMgr.h"
#include "dbprint.h"

#define MgtRemoteClientRefresh 100 //in ms.
#define MgtIdleTimeOut			15000 //in ms
#define MgtbusyTimeOut			6000  //in ms

typedef struct {
	int fdClient; //list keeping the connection fd of the client
	int clientTimeOutCnt; //list of time period since last activities.
	uint8_t busy;
	clientCmd_t lastcmd;
	int consoleFD; //keep the request command console FD.
	int nopPending;
	int retrycnt;
	uint8_t *lastsendbyte; //keep the last send packet for retry
	uint16_t lastsendsize; //keep the size of the last send packet.
}clientprop_t;

void MgtTimePoll(int timerid,void*ptr);

uint16_t totalRemoteClient=0;
uint16_t maxRClient=0;
long idleTimeOutSetting=MgtIdleTimeOut; //default 15 second
long busyTimeOutSetting=MgtbusyTimeOut; //default 6 second.
void (*idleTimeOutCB)(int clientIndex)=0;
void (*busyTimeOutCB)(int clientIndex, int consoleFD, clientCmd_t lastcmd)=0;
void(*ClientOfflineCB)(uint16_t clientIndex);

//array of pointer point to the remote client
remoteclient_t **pRClient;
clientprop_t **pclientProp;
int timerMgrRef;

#define RestClientJustOnline(pClientProp,clientFD) do{\
		memset((pClientProp),0,sizeof(clientprop_t));\
		(pClientProp)->fdClient=(clientFD);\
		(pClientProp)->consoleFD=-1;\
}while(0);



/*
 * return true if success.
 */
uint16_t MgtClientInit(uint16_t maxRemoteClient)
{
	int c;
	pRClient=(remoteclient_t**)malloc(sizeof(void*)*maxRemoteClient);
	pclientProp=(clientprop_t**)malloc(sizeof(void*)*maxRemoteClient);
	maxRClient=maxRemoteClient;
	if (pRClient && pclientProp)
	{
		for (c=0;c<totalRemoteClient;c++)
		{
			pRClient[c]=NULL;
			pclientProp[c]=NULL;
		}
		timerMgrRef=TimerMgr_Create("CMgt", MgtRemoteClientRefresh, 1, &MgtTimePoll, NULL);
		TimerMgr_Start(timerMgrRef);
		return(1);
	}
	return(0);
}

/*
 * Insert the client into the list, will return the
 * index of the client.
 * if fail to insert will return -1
 */
int MgtClientInsert(int clientFD,remoteclient_t *client)
{
	uint16_t c;

	//search for duplicate
	//match base of mac address
	for (c=0;c<totalRemoteClient;c++)
	{
		if (pRClient[c]){
			if (memcmp(pRClient[c]->macaddr,client->macaddr,6)==0) {
				//found match
				memcpy(pRClient[c],client,sizeof(remoteclient_t));
				pRClient[c]->online=1;

				//free the lastsendbyte if previously got memory allocated.
				if (pclientProp[c]->lastsendbyte) {
					free(pclientProp[c]->lastsendbyte);
					pclientProp[c]->lastsendbyte=0;
				}
				RestClientJustOnline((pclientProp[c]),clientFD);

				dbPrintText("InsertClient: Found Prev Record index:%d Mac",c);
				dbPrintByte(pRClient[c]->macaddr,6);
				dbPrintNewLine();

				return(c);
			}
		}
	}

	//did not found the client in the list, just append it at the end.
	if (totalRemoteClient<maxRClient)
	{
		//allocate memory to keep the client information.
		pRClient[totalRemoteClient]=(remoteclient_t*)malloc(sizeof(remoteclient_t));
		pclientProp[totalRemoteClient]=(clientprop_t*)malloc(sizeof(clientprop_t));
		if (pRClient[totalRemoteClient] && pclientProp[totalRemoteClient])
		{
			memcpy(pRClient[totalRemoteClient],client,sizeof(remoteclient_t));
			pRClient[totalRemoteClient]->online=1;

			RestClientJustOnline((pclientProp[totalRemoteClient]),clientFD);

			dbPrintText("InsertClient: Add New Record index:%d Mac",totalRemoteClient);
			dbPrintByte(pRClient[totalRemoteClient]->macaddr,6);
			dbPrintNewLine();

			totalRemoteClient++;
			return(totalRemoteClient-1);
		}
	}
	return(-1);
}
/*
 * Manage the busy flag fo the client
 */
uint16_t MgtIsClientBusy(int clientIndex,clientCmd_t *lastcmd)
{
	if (clientIndex<totalRemoteClient)
	{
		if (lastcmd) lastcmd[0]=pclientProp[clientIndex]->lastcmd;
		return(pclientProp[clientIndex]->busy);
	}
	return(1);
}
void MgtSetClientBusy(int clientIndex, uint8_t cmd, int consoleFD){
	if (clientIndex>=0 && clientIndex<totalRemoteClient)
	{
		if (cmd!=-1) pclientProp[clientIndex]->lastcmd=cmd;
		pclientProp[clientIndex]->consoleFD=consoleFD;
		pclientProp[clientIndex]->busy=1;
		pclientProp[clientIndex]->clientTimeOutCnt=0;
	}
}

/*
 * keep the last send packet into the memory.
 */
void MgtSaveLastSendPkt(int clientIndex, uint8_t *pData, uint16_t size)
{

	if (clientIndex>=0 && clientIndex<totalRemoteClient)
	{
		if (pclientProp[clientIndex]->lastsendbyte) {
			//got data in the memory, free the memory
			free(pclientProp[clientIndex]->lastsendbyte);
			pclientProp[clientIndex]->lastsendbyte=0;
		}
		if (size==0) {
			//just malloc 1byte if size is zero, but normally this will not happen
			//since we also need to keep the result and cmd byte.
			pclientProp[clientIndex]->lastsendbyte=(uint8_t*)malloc(1);
		}
		else {
			pclientProp[clientIndex]->lastsendbyte=(uint8_t*)malloc(size);
		}
		if (pclientProp[clientIndex]->lastsendbyte) {
			memcpy(pclientProp[clientIndex]->lastsendbyte,pData,size);
			pclientProp[clientIndex]->retrycnt=0;
			pclientProp[clientIndex]->lastsendsize=size;
		}
	}
}

/*
 * return the saved last send packet
 * caller prove space to keep the pSize, will return ptr to the data byte.
 */
uint8_t *MgtGetLastSendPkt(int clientIndex,uint16_t* pSize)
{

	if (clientIndex>=0 && clientIndex<=totalRemoteClient)
	{
		if (pclientProp[clientIndex]->lastsendbyte) {
			pclientProp[clientIndex]->retrycnt++;
			pSize[0]=pclientProp[clientIndex]->lastsendsize;
			return(pclientProp[clientIndex]->lastsendbyte);
		}
	}
	pSize[0]=0;
	return(NULL);
}

/*
 * Get the number of tcp packet resent count
 */
uint16_t MgtGetResentCount(int clientIndex)
{
	if (clientIndex>=0 && clientIndex<=totalRemoteClient)
	{
		return(pclientProp[clientIndex]->retrycnt);
	}
	return(0);
}

void MgtClrClientBusy(int clientIndex){
	if (clientIndex<totalRemoteClient)
	{
		if (pclientProp[clientIndex]->busy==0) {
			dbPrintText("Clear Busy Err %d",clientIndex);dbPrintNewLine();
		}
		pclientProp[clientIndex]->busy=0;
		pclientProp[clientIndex]->clientTimeOutCnt=0;
	}
}
/*
 * Clear the Nop Pending flag once received the Nop reply
 */
void MgtClearNopPending(int clientIndex)
{
	pclientProp[clientIndex]->nopPending=0;
}
/*
 * Set the Nop Pending flag when sending the Nop during idle
 */
void MgtSetNopPending(int clientIndex)
{
	pclientProp[clientIndex]->nopPending=1;
}
/*
 * Set the client offline
 */
void MgtClientOffline(int clientIndex)
{
	dbPrintText("Set Client offline->");
	if (clientIndex<totalRemoteClient)
	{
		dbPrintText("%d",clientIndex);dbPrintNewLine();
		pRClient[clientIndex]->online=0;
		pRClient[clientIndex]->rssi=0;
	}
}
/*
 * Set the client online
 */
void MgtClientOnline(int clientIndex)
{
	if (clientIndex<totalRemoteClient)
	{
		if (pRClient[clientIndex]->online==0) {
			pRClient[clientIndex]->online=1;
			pclientProp[clientIndex]->lastcmd=0;
			pclientProp[clientIndex]->consoleFD=-1;
			pclientProp[clientIndex]->busy=0;
			pclientProp[clientIndex]->clientTimeOutCnt=0;
		}
	}
}
/*
 * Return the array pointer to the array of remoteclient_t list
 */
remoteclient_t **MgtClinetGetList(uint16_t *pTotalClient)
{
	(*pTotalClient)=totalRemoteClient;
	return(pRClient);
}
/*
 * Return the  pointer to the remoteclient_t list
 */
remoteclient_t *MgtClinetGet(uint16_t clientIndex)
{
	if (clientIndex<totalRemoteClient)
	{
		return(pRClient[clientIndex]);
	}
	return(0);
}
/*
 * Get the connection FD of the client
 * Will return -1 if client not available or offline.
 */
int MgtClientGetFD(int clientIndex)
{
	if (clientIndex<totalRemoteClient && pRClient[clientIndex]->online==1 )
	{
		return(pclientProp[clientIndex]->fdClient);
	}
	return(-1);
}
/*
 * Update the RSSI value of the client
 */
void MgtClientUpdRSSI(int fd,int8_t rssi)
{
	int index;
	if ((index=MgtClientGetIndex(fd))>=0) {
		if (pRClient[index]) {
			pRClient[index]->rssi=rssi;
		}
	}
}
/*
 * Get the client index from fd
 * return -1 if cannot find.
 */
int MgtClientGetIndex(int fd)
{
	uint16_t c;
	for (c=0;c<totalRemoteClient;c++)
	{
		//only return the online client fd. Ignore offline one.
		if (pclientProp[c]->fdClient==fd && (pRClient[c] && pRClient[c]->online))
		{
			return(c);
		}
	}
	return(-1);
}
/*
 * Set the default time out when the client is idle too long
 * idleTimeOut is in resolution of 0.1 second
 */
void MgtSetIdleTimeout(long idleTimeOut, void (*cb)(int clientIndex))
{
	idleTimeOutCB=cb;
	if (idleTimeOut<10000) {
		idleTimeOutSetting=10000; //minimum 10sec
	}
	else {
		idleTimeOutSetting=idleTimeOut;
	}
}

/*
 * Set the busy time out waiting for command to return from client.
 * busyTimeOut is in millisecond.
 */
void MgtSetBusyTimeout(long busyTimeOut, void (*cb)(int clientIndex, int consoleFD, clientCmd_t lastcmd))
{
	if (busyTimeOut<1000) {
		busyTimeOutSetting=1000; //minimum 1sec
	}
	else {
		busyTimeOutSetting=busyTimeOut;
	}
	busyTimeOutCB=cb;
}

/*
 * Reconfigure the command send wait time without changing the callback function.
 */
void MgtResetBusyTimeout(long busyTimeOut)
{
	if (busyTimeOut>1000) {
		busyTimeOutSetting=busyTimeOut;
	}
}

/*
 * Register callback to handle client offline
 */
void MgtSetClientOfflineCB(void (*cb)(uint16_t clientIndex))
{
	ClientOfflineCB=cb;
}

/*
 * return true if current waiting for client reply
 */
uint8_t MgtClientIsbusyNow(int consoleFD)
{
	int c;
	for (c=0;c<totalRemoteClient;c++) {
		if (pRClient[c]->online && pclientProp[c]->consoleFD==consoleFD) {
			if (pclientProp[c]->busy)
			{
				return(1);
			}
		}
	}
	return(0);
}

//trigger to check if the client reach the max busy time.
//or idle time.
void MgtTimePoll(int timerid,void*ptr)
{
	int c;
	for (c=0;c<totalRemoteClient;c++) {
		pclientProp[c]->clientTimeOutCnt++;
		if (pRClient[c]->online) { //only looking for online client
			if (!pclientProp[c]->busy) {
				//not busy sending comamnd
				//Checking idle period for client currently idling.
				if (pclientProp[c]->clientTimeOutCnt>(idleTimeOutSetting/MgtRemoteClientRefresh))
				{
					dbPrintText("Idle timeout Sending NOP %d",c);dbPrintNewLine();
					//idle time out, do the callback
					if (idleTimeOutCB) (*idleTimeOutCB)(c);
					pclientProp[c]->clientTimeOutCnt=0;
				}
			}
			else {
				//Checking for reply wait time if command send and waiting for reply.
				//busy sending command.
				if (pclientProp[c]->clientTimeOutCnt>busyTimeOutSetting/MgtRemoteClientRefresh)
				{
					if (pclientProp[c]->nopPending){
						//previous polling call no reply. need to close the connection
						dbPrintText("Reply timeout for NOP %d",c);dbPrintNewLine();
						pclientProp[c]->nopPending=0;
						pclientProp[c]->busy=0;
						if (ClientOfflineCB) (*ClientOfflineCB)(c);
					}
					else {
						//waiting for reply too long, Need to do command reply timeout callback.
						//busy timeout waiting for return command, do the callback.
						dbPrintText("Reply timeout %d",c);dbPrintNewLine();
						pclientProp[c]->busy=0;
						pclientProp[c]->nopPending=0;
						if (busyTimeOutCB) (*busyTimeOutCB)(c,pclientProp[c]->consoleFD,pclientProp[c]->lastcmd);
					}
					pclientProp[c]->clientTimeOutCnt=0;
				}
			}
		}
		else {
			//offline client
			pclientProp[c]->clientTimeOutCnt=0;
		}
	}
}

/*
 * Return the current console FD
 */
int MgtGetConsoleFD(int clientIndex)
{
	if (clientIndex<totalRemoteClient)
	{
		return(pclientProp[clientIndex]->consoleFD);
	}
	return(-1);
}
