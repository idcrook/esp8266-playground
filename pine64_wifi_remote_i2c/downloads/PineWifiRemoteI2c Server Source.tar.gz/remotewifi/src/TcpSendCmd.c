/*
 * TcpSendCmd.c
 *
 *  Created on: Mar 11, 2016
 *      Author: khgoh
 */
#include "TcpSendCmd.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "TcpMgtRemoteClient.h"
#include "TcpProcRxCmd.h"
#include "tcpCommandList.h"
#include "pktcreate.h"
#include "TcpServerConn.h"
#include "TimerMgr.h"
#include "dbprint.h"


typedef struct {
	clientCmd_t cmd;
	uint8_t code;
} cmdcode_t;

cmdcode_t cmdtocode[]=
{
		{cmd_pushmsg,Cmd01_Nop}, //cmd_pushmsg
		{cmd_i2cpoll,Cmd11_I2CPOLL},
		{cmd_i2cread,Cmd12_I2CREAD},
		{cmd_i2cwrite,Cmd13_I2CWRITE},
		{cmd_i2cstart,Cmd14_I2CSTART},
		{cmd_i2cstop,Cmd15_I2cDisable},
		{push_i2cIntr,Cmd16_I2cIntr},
		{cmd_setio,Cmd30_SET_IO},
		{cmd_relay,Cmd31_RELAY},
		{cmd_cfgporttype, Cmd32_SET_PORT},
		{push_InPortChanged, Cmd33_PUSH_IP_STATUS},
		/*
		{cmd_pwmenable,Cmd20_PWMENABLE},
		{cmd_pwmcfg,Cmd21_PWMCFG},
		{cmd_spienable,Cmd40_SPIENABLE},
		{cmd_spicfg,Cmd41_SPICFG},
		{cmd_spirxtx,Cmd42_SPIRXTX},*/

};

/*
 * 	cmd_pwmenable,cmd_pwmcfg,
	cmd_spienable, cmd_spicfg, cmd_spirxtx,
 */
#define CmdCodeSize (sizeof(cmdtocode)/sizeof(cmdcode_t))

uint16_t tcpServerRef;
uint16_t inited=0;
uint16_t clientIdleTimeOut;  //in 0.1 second per count
uint16_t clientBusyTimeOut;  //in 0.1 second per count

int pollTimerRef;
/*
 * Send Nop to the remote client
 */
uint16_t SendCmd_Nop(int consoleFD, uint16_t clientIndex);

void ClientIdleTimeout(int clientIndex);
void ClientBusyTimeout(int clientIndex,int consoleFD, clientCmd_t lastcmd);


/*
 * Convdrt cmd to code
 */
uint8_t CmdtoCode(clientCmd_t cmd);
/*
 * Convert code to Cmd
 */
clientCmd_t CodetoCmd(uint8_t cmdcode);


/*
 * Call once to init and startup the tcp server
 * maxClient is maximum number of
 * remote client allow to connect at the same time
 * return true on success.
 */
uint16_t TcpSendCmdInit(uint16_t maxClient, uint16_t idleTimeOut, uint16_t cmdReturnTimeout,
		void (*rxResultCB)(int consoleFD,uint16_t clientIndex,
						clientCmd_t cmd,clientRespond_t res,
						uint8_t size, uint8_t* pdata))
{
	if (!inited) {
		if (MgtClientInit(maxClient))
		{
			tcpServerRef=TscCreateServer(35000,maxClient);
			if (tcpServerRef) {
				//register all the tcp communcation callback function
				//define in TcpProcRxCmd.c
				TscRegisterCBConnected(tcpServerRef,&TcpConnectedCB);
				TscRegisterCBRxData(tcpServerRef,&TcpDataRxCB);
				TscRegisterCBDisconnected(tcpServerRef,&TcpDisconnectedCB);
				RegTcpProcRxCmdCB(rxResultCB); //set the return result callback
				if (TscStartServer(tcpServerRef)) {
					clientIdleTimeOut=idleTimeOut;
					clientBusyTimeOut=cmdReturnTimeout;
					MgtSetIdleTimeout(clientIdleTimeOut,&ClientIdleTimeout);
					MgtSetBusyTimeout(clientBusyTimeOut,&ClientBusyTimeout);
					MgtSetClientOfflineCB(&TcpSetClientOffline);
					return(1);
				}
			}
		}

	}
	return(0);
}
/*
 * Reconfigure the cmdReturnTimeout value in millisecond.
 */
void TcpReconfigCmdReturnTimeout(uint16_t cmdReturnTimeout)
{
	MgtResetBusyTimeout((long) cmdReturnTimeout);
}

/*
 * Convert code to Cmd
 */
clientCmd_t CodetoCmd(uint8_t cmdcode)
{
	int c;
	for (c=0;c<CmdCodeSize;c++)
	{
		if (cmdtocode[c].code==cmdcode) return(cmdtocode[c].cmd);
	}
	return((clientCmd_t)0);
}

/*
 * Convdrt cmd to code
 */
uint8_t CmdtoCode(clientCmd_t cmd)
{
	int c;
	for (c=0;c<CmdCodeSize;c++)
	{
		if (cmdtocode[c].cmd==cmd) return(cmdtocode[c].code);
	}
	return(0);
}

/*
 * Each remote client will be represented with and cliendindex
 * which is the index of structure remoteclient_t.
 * Will return the array pointer to the remoteclient_t pointer
 * If currently no device in the list, it will return NULL.
 */
remoteclient_t **GetRemoteClientList(uint16_t *pTotalClient)
{
	return(MgtClinetGetList(pTotalClient));
}

/*
 * return the remote client info for given clientIndex
 */
remoteclient_t *GetRemoteClient(uint16_t clientIndex)
{
	return(MgtClinetGet(clientIndex));
}

/*
 * Send Nop to the remote client
 */
uint16_t SendCmd_Nop(int consoleFD, uint16_t clientIndex)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if (((fd=MgtClientGetFD(clientIndex))>=0) && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,0))
		{
			pktc_create(0,Cmd01_Nop); //index 0 is nop
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,0,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}

	return(0);
}
/*
 * Call the start the I2c bus. Once started, SendCmd_SetIO will not change the
 * status of the I2c bus.
 */
uint16_t SendCmd_I2cStart(int consoleFD, uint16_t clientIndex)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,0))
		{
			pktc_create(0,CmdtoCode(cmd_i2cstart));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,(cmd_i2cstart),consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Send I2cStop to remote client
 */
uint16_t SendCmd_I2cStop(int consoleFD, uint16_t clientIndex)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,0))
		{
			pktc_create(0,CmdtoCode(cmd_i2cstop));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,(cmd_i2cstop),consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * I2c Poll for a device on the i2c bus
 */
uint16_t SendCmd_I2cPoll(int consoleFD, uint16_t clientIndex, uint8_t i2cID)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,1))
		{
			pdata[0]=i2cID;
			pktc_create(0,CmdtoCode(cmd_i2cpoll));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_i2cpoll,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Read the i2c device memory starting at location addr with total byte to read = size
 */
uint16_t Sendcmd_I2cRead(int consoleFD, uint16_t clientIndex, uint8_t i2cID, uint8_t addr, uint8_t datasize)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,3))
		{
			pdata[0]=i2cID;
			pdata[1]=addr;
			pdata[2]=datasize;
			pktc_create(0,CmdtoCode(cmd_i2cread));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_i2cread,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Write data into the i2c device memory starting at location addr with total byte write=size
 * and pdata point to the data going to write into the device
 */
uint16_t SendCmd_I2cWrite(int consoleFD, uint16_t clientIndex, uint8_t i2cID,
							uint8_t addr, uint8_t datasize, uint8_t *pData)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,3+datasize))
		{
			pdata[0]=i2cID;
			pdata[1]=addr;
			pdata[2]=datasize;
			memcpy(&pdata[3],pData,datasize);
			pktc_create(0,CmdtoCode(cmd_i2cwrite));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_i2cwrite,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Set the I/O pin status of the remote I/O device
 * if the iomask bit is 1, the corresponding iostatus on the same bit will be set into the i/O port
 * It will also return the current status of the i/o port through the call back
 */
uint16_t SendCmd_SetIO(int consoleFD, uint16_t clientIndex, uint8_t iomask, uint8_t iostatus)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,2))
		{
			pdata[0]=iomask;
			pdata[1]=iostatus;
			pktc_create(0,CmdtoCode(cmd_setio));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_setio,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Configure the I/O pin type of the remote I/O device
 * if the iomask bit is 1, the corresponding iocfg on the same bit will be configure.
 * iocfg bit=0 is Output Port, iocfg bit=1 is input port
 * It will also return the current status of the i/o port through the call back
 */
uint16_t SendCmd_CfgIO(int consoleFD, uint16_t clientIndex, uint8_t iomask, uint8_t iocfg)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,2))
		{
			pdata[0]=iomask;
			pdata[1]=iocfg;
			pktc_create(0,CmdtoCode(cmd_cfgporttype));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_cfgporttype,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}
/*
 * Set the relay on/off
 * status 0 = no action, just return the current status through the callback
 * status 1 = on
 * status 2 = off
 */
uint16_t SendCmd_SetRelay(int consoleFD, uint16_t clientIndex, uint8_t status)
{
	int fd;
	uint8_t *pdata;
	uint16_t size;
	uint8_t tmp;
	if ((fd=MgtClientGetFD(clientIndex))>=0 && !MgtIsClientBusy(clientIndex,NULL)){
		if (pktc_request(clientIndex,&pdata,1))
		{
			pdata[0]=status;
			pktc_create(0,CmdtoCode(cmd_relay));
			pdata=pktc_Get(&size);
			tmp=TscSendData(fd,pdata,size);
			pktc_done();
			if (tmp) {
				MgtSetClientBusy(clientIndex,cmd_relay,consoleFD);
				return(1);
			}
			else {
				TcpSetClientOffline(clientIndex);
			}
		}
	}
	return(0);
}

/*
 * Return True if the console is waiting for reply.
 */
uint8_t isConsoleBusy(int fd) {
	return(MgtClientIsbusyNow(fd));
}
/*
 * callback when the remote client reach idle time out.
 * send NOP
 */
void ClientIdleTimeout(int clientIndex)
{
	//send NOP to check if remote client still active
	SendCmd_Nop(-1,clientIndex);
	MgtSetNopPending(clientIndex);

}

/*
 * recreate the last send packet
 * will send the packet through the pTcpSendCB function.
 * return true if the packet is being send out,
 * else return false if sending fail.
 */
uint16_t pktc_recreatelast(int clientIndex)
{
	uint16_t lastSendSize;
	uint8_t *lastSendData=MgtGetLastSendPkt(clientIndex,&lastSendSize);
	uint8_t *newPacketData;
	uint16_t pktSize;
	uint8_t result=0;
	int fd;
	if (lastSendData) {
		if (pktc_request(-1,&newPacketData,lastSendSize-2))
		{
			if (lastSendSize) {
				memcpy(newPacketData,&lastSendData[2],lastSendSize-2);
			}
			pktc_create(lastSendData[0],lastSendData[1]);
			newPacketData=pktc_Get(&pktSize);

			fd=MgtClientGetFD(clientIndex);
			if (TscSendData(fd,newPacketData,pktSize)) {
				//send success
				result=1;
			}
			pktc_done();
		}
	}
	return(result);
}

void ClientBusyTimeout(int clientIndex,int consoleFD, clientCmd_t lastcmd)
{
	uint16_t tmp;
	if (MgtGetResentCount(clientIndex)>1) {
		if (CmdtoCode(lastcmd)!=Cmd01_Nop) { //skip nop timeout signal
			TcpReturnTimeOut(consoleFD,clientIndex,lastcmd);
			TcpSetClientOffline(clientIndex);
			dbPrintText("Too much retry, call disconnect %d",clientIndex);dbPrintNewLine();
		}
	}
	else {
		tmp=pktc_recreatelast(clientIndex);
		if (tmp) {
			MgtSetClientBusy(clientIndex,-1,consoleFD);
			dbPrintText("Resent done %d",clientIndex);dbPrintNewLine();
		}
		else {
			TcpSetClientOffline(clientIndex);
			dbPrintText("resent fail, call disconnect %d",clientIndex);dbPrintNewLine();
		}
	}
}
