/*
 * pktcreate.c
 *
 *  Created on: Apr 20, 2015
 *      Author: khgoh
 */

#include <string.h>
#include <stdlib.h>
#include "pktcreate.h"
#include "crc_update.h"
#include "tcpCommandList.h"
#include "TcpMgtRemoteClient.h"
#include "dbprint.h"

//define max number of byte size in multiple packet Frame.
#define PKTCREATE_MAXFRAMESIZE	1024
#define CmdIgnorePktCnt 	(Cmd02_HWINFO) //ignore pktcnt if cmd match

uint8_t *pPktMemory=0; //keep the ptr to the memory
uint16_t pktSize=0;
uint16_t pktPayloadSize=0;
uint8_t pktTxCnt=1;
uint8_t pktRxCnt=0; //keep the last received counter.
int cindex;
uint16_t userDataSize=0;

/*
 * Call to request memory to create the reply or push packet
 * Will return the pointer to memory to keep the payload.
 * datasize -> data size to send, D0 to Dn (Excluding Cmd byte)
 * return true if memory is ready
 * Will add the byte at the end of the previous packet if currently have packet already allocated previously.
 */
uint8_t  pktc_request(int clientIndex,uint8_t **pMemorySpace,uint16_t datasize)
{
	uint16_t tmpPktSize;
	//calculate the current packet byte size require
	userDataSize=datasize;
	tmpPktSize=(datasize+TXPKT_ExtraPayloadByte+1);
	cindex=clientIndex;
	if (pktSize==0) //only allow 1 packet at any one time.
	{
		//total size still below our set limit, so we append the new packet at the end of previous packet.
		pPktMemory=(uint8_t*)malloc(tmpPktSize);
		if (pPktMemory)
		{
			memset(pPktMemory,0,tmpPktSize);
			pktSize=tmpPktSize;
			(*pMemorySpace)=&(pPktMemory[PKTINDEX_DATA+1]);
			return(1);
		}
	}
	return(0);
}

/*
 * Call the calculate and create the packet for sending.
 * if pServerRef is NULL, it will set the 4byte field to zero.
 */
void  pktc_create(uint8_t result,uint8_t Cmd)
{
	uint8_t ifMacAddr[6];
	memset(ifMacAddr,0,6);
	pPktMemory[PKTINDEX_LEN]=pktSize;		//Len in factor 16, packet size
	pPktMemory[PKTINDEX_Cnt]=pktTxCnt++;			//packet counter
	pPktMemory[PKTINDEX_DATA]=Cmd;
	memcpy(&(pPktMemory[PKTINDEX_MAC]),ifMacAddr,6);
	pPktMemory[PKTINDEX_Result]=result;
	pPktMemory[0]=STXBYTE;
	CalCRC(&(pPktMemory[0]),pktSize);
	if (cindex>=0) {
		//we keep user data with result and byte)
		MgtSaveLastSendPkt(cindex, &pPktMemory[PKTINDEX_Result],userDataSize+2);

	}
}

/*
 * Call after pktc_create to get the created packet for sending out.
 */
uint8_t  *pktc_Get(uint16_t *pPktSize)
{
	(*pPktSize)=pktSize;
	return(pPktMemory);
}

/*
 * Call after finish sending the packet. no more needing the data.
 */
void  pktc_done(void)
{
	free(pPktMemory);
	pPktMemory=0;
	pktSize=0;
}


/*
 * Do a CRC check the Rx data.
 * return true if the data is ready for process.
 * will also return the pointer to the CMD/Data byte in the packet.
 *   CMD D0...Dn
 * Must provide the size of pData in pSize.
 * pSize -> to return the total byte size of Dn byte (excluding the CMD Byte).
 */
uint8_t  pktc_rxPecket(uint8_t *pData, uint8_t **pMac,uint8_t **pResult, uint8_t **pCmdData, uint16_t *pSize, uint8_t **pRSSI)
{
	if (pData[PKTINDEX_LEN]>pSize[0])
	{
		dbPrintText("Packet size Inconsistency  : ");dbPrintNewLine();
		return(0); //packet length received not correct with actual byte size received.
	}
	if (CheckCRC(pData,(pData[PKTINDEX_LEN])))
	{
		if (pktRxCnt!=pData[PKTINDEX_Cnt] || pData[PKTINDEX_DATA]==CmdIgnorePktCnt){
			pktRxCnt=pData[PKTINDEX_Cnt];	//keep the current packet counter
			(*pCmdData)=&(pData[PKTINDEX_DATA]);
			(*pRSSI)=&(pData[PKTINDEX_RSSI]);
			(*pResult)=&(pData[PKTINDEX_Result]);
			(*pMac)=&(pData[PKTINDEX_MAC]);
			(*pSize)=(pData[PKTINDEX_LEN])-TXPKT_ExtraPayloadByte-1; //need to exclude out the cmd byte.
			return(1);
		}
	}
	return(0);
}



