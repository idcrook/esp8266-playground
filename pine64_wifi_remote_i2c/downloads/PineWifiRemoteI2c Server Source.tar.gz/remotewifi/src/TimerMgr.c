/*
 * TimerMgr.c
 *
 *  Created on: Jul 9, 2015
 *      Author: khgoh
 */

#include "PollMgr.h"
#include <sys/timerfd.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

//define maximum timer array
#define MAX_TIMERMGR	50

typedef struct
{
	void (*cb)(int timerid,void*ptr);
	int fd;
	long delay_ms;
	unsigned char isRepeat;
	void *ptr;
	int timerid;
}timerprop_t;

typedef struct
{
	timerprop_t *pTimerProp;
}timer_pollcb_t;

timerprop_t timerprop[MAX_TIMERMGR];
timer_pollcb_t timer_pollcb[MAX_TIMERMGR];

int timermgr_total=0;

void TimerMgr_Callback(int fd,short int event,void*ptr);
/*
 * Call to create a time, on success, will return the timerid.
 * or else, will return zero.
 * Once trigger, will do the callback.
 */
int TimerMgr_Create(char *name, long delay_ms, unsigned char isRepeat, void (*cb)(int timerid,void*ptr), void *ptr)
{
	int fd;
	char tmp[20];
	if (timermgr_total<MAX_TIMERMGR) {
		fd = timerfd_create (CLOCK_MONOTONIC, 0);
		if (fd)
		{
			if (name!=NULL) {
				sprintf(tmp,"TM-");
				if (strlen(name)>=17) {
					memcpy(&tmp[strlen(tmp)],name,16);
					tmp[19]=0;
				}
				else {
					strcpy(&tmp[strlen(tmp)],name);
				}
			}
			else {
				sprintf(tmp,"TM-FD%d",fd);
			}

			if (PollMgr_Insert(tmp,fd,POLLIN,&TimerMgr_Callback,&(timerprop[timermgr_total])))
			{
				timerprop[timermgr_total].cb=cb;
				timerprop[timermgr_total].delay_ms=delay_ms;
				timerprop[timermgr_total].fd=fd;
				timerprop[timermgr_total].isRepeat=isRepeat;
				timerprop[timermgr_total].ptr=ptr;
				timerprop[timermgr_total].timerid=timermgr_total+1;
				timermgr_total++;
				return(timermgr_total);
			}
			close(fd);
		}
	}
	return(0);
}

/*
 * Call to start the timer
 */
int TimerMgr_Start(int timerid)
{
	struct itimerspec itval;
	long int ns;
	long int sec;
	int index=timerid-1;


	sec = timerprop[index].delay_ms/1000;
	ns = (timerprop[index].delay_ms - (sec * 1000)) * 1000000;

	itval.it_value.tv_sec = sec;
	itval.it_value.tv_nsec = ns;

	if (timerprop[index].isRepeat)
	{
		itval.it_interval.tv_sec = sec;
		itval.it_interval.tv_nsec = ns;
	}
	else
	{
		itval.it_interval.tv_sec = 0;
		itval.it_interval.tv_nsec = 0;
	}
	return(timerfd_settime (timerprop[index].fd, 0, &itval, NULL));
}

/*
 * Call to stop the timer
 */
int TimerMgr_Stop(int timerid)
{
	struct itimerspec itval;
	int index=timerid-1;

	itval.it_interval.tv_sec = 0;
	itval.it_interval.tv_nsec = 0;
	itval.it_value.tv_sec = 0;
	itval.it_value.tv_nsec = 0;
	return(timerfd_settime (timerprop[index].fd, 0, &itval, NULL));
}

void TimerMgr_Callback(int fd,short int event,void*ptr)
{
	timerprop_t *pTimerProp=(timerprop_t*)ptr;


	if (event & POLLIN)
	{
		unsigned long long missed;
		int ret;

		/* Wait for the next timer event. If we have missed any the
		   number is written to "missed" */
		ret = read (pTimerProp->fd, &missed, sizeof (missed));
		if (ret)
		{
			if (pTimerProp->cb)
			{
				//do the callback
				(*pTimerProp->cb)(pTimerProp->timerid,pTimerProp->ptr);
			}
		}
	}
}

