/*
 * tcpconn.c
 *
 *  Created on: Mar 9, 2016
 *      Author: khgoh
 */
#include "TcpServerConn.h"
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include "PollMgr.h"
#include <string.h>
#include "dbprint.h"
#include "TcpMgtRemoteClient.h"

//define max number of server allow
#ifndef TotalTcpServer
#define TotalTcpServer 10
#endif

//define max buffer size when received data from tcp buffer
//only one buffer require for all connection since we
//are using poll concept.
#ifndef TcpRxBuffsize
#define TcpRxBuffsize 2048
#endif


typedef struct {
	uint16_t ref;
	struct sockaddr_in   addr;
	int listenFD;
	void (*rxcb)(int fd, uint8_t *pData, uint16_t size);
	void (*closedcb)(int fd);
	void (*connectedcb)(int fd, struct sockaddr* pRemoteAddr);
	int *fd; //array pointer.
	uint16_t maxfd;
}tscprop_t;


/*
 * Reset all the connection FD
 */
#define Tsc_ResetFD(pTscProp) do{\
	memset(((pTscProp)->fd),-1,((pTscProp)->maxfd));\
}while(0)


tscprop_t *ptscprop[TotalTcpServer];
int totalTscServer=0;
uint8_t tscRxBuffer[TcpRxBuffsize];

//----------------- Function Prototype ------------------------------
/*
 * Poll callback when Listen socket trigger
 */
void Tsc_ListsenCB(int fd, short int event, void *ptr);
/*
 * Poll callback when Connected socket trigger
 */
void Tsc_ConnectionCB(int fd, short int event, void *ptr);
/*
 * Insert FD into the connection, return true if success
 */
uint16_t Tsc_InsertFD(tscprop_t *pTscProp, int fd);
/*
 * Return true if FD found in this connection, else return -1
 */
uint16_t Tsc_CheckFD(tscprop_t *pTscProp, int fd);
/*
 * Remove FD from the connection
 */
void Tsc_RemoveFD(int fd);
/*
 * Return the connection ptr base on fd
 * return null if not found.
 */
tscprop_t* Tsc_GetConProp(int fd);
/*
 * call to close the connection
 */
void TscCloseConnection(int fd);

//----------------- Public Function ------------------------------
/*
 * Call to create a server connection.
 * On success, it will return the reference to the tcp server
 * or else will return 0
 */
uint16_t TscCreateServer(uint16_t serverPortNo,uint16_t maxClientConn)
{
	int tmp;
	int on=1;
	int maxfd=(maxClientConn)?maxClientConn:1;
	if (totalTscServer<TotalTcpServer)
	{
		// Creating memory to keep the connection
		ptscprop[totalTscServer]=(tscprop_t*)malloc(sizeof(tscprop_t));

		if (ptscprop[totalTscServer]) {
			memset(ptscprop[totalTscServer],0,sizeof(tscprop_t));
			ptscprop[totalTscServer]->fd=(int*)malloc(sizeof(int)*maxfd);
			if (ptscprop[totalTscServer]->fd)
			{
				//reset the fd and setup the maxfd.
				for (tmp=0;tmp<maxfd;tmp++) (ptscprop[totalTscServer]->fd)[tmp]=-1;
				ptscprop[totalTscServer]->maxfd=maxfd;
				// Create Listen socket.
				ptscprop[totalTscServer]->listenFD = socket(AF_INET, SOCK_STREAM, 0);

				if (ptscprop[totalTscServer]->listenFD>=0) {
					//Allow socket descriptor to be reusable
					tmp=setsockopt(ptscprop[totalTscServer]->listenFD, SOL_SOCKET,  SO_REUSEADDR,(char *)&on, sizeof(on));

					if (tmp>=0)
					{
						//Set socket to be nonblocking.
						tmp=ioctl(ptscprop[totalTscServer]->listenFD, FIONBIO, (char *)&on);

						if (tmp>=0)
						{
							// Bind the socket.
							ptscprop[totalTscServer]->addr.sin_family=AF_INET;
							ptscprop[totalTscServer]->addr.sin_addr.s_addr=INADDR_ANY;
							ptscprop[totalTscServer]->addr.sin_port        = htons(serverPortNo);
							tmp = bind(ptscprop[totalTscServer]->listenFD,
									(struct sockaddr *)&ptscprop[totalTscServer]->addr,
									sizeof(ptscprop[totalTscServer]->addr));
							if (tmp>=0)
							{
								ptscprop[totalTscServer]->ref=totalTscServer+1;
								totalTscServer++;
								return(totalTscServer);
							}
						}
					}
				}
			}
		}
	}
	// Fail creating the socket
	// clean up
	if (ptscprop[totalTscServer]) {
		close(ptscprop[totalTscServer]->listenFD);
		free(ptscprop[totalTscServer]);
	}
	return(0);
}

/*
 * Call to start the server
 */
uint16_t TscStartServer(uint16_t ref)
{
	int tmp;
	if (ref && ref<=totalTscServer)
	{
		// start listen to the incoming connection
		tmp = listen(ptscprop[ref-1]->listenFD, 32);
		if (tmp>=0)
		{
			char name[21];
			sprintf(name,"Listen#%d",ptscprop[ref-1]->listenFD);
			if (PollMgr_Insert(name,ptscprop[ref-1]->listenFD,POLLIN,&Tsc_ListsenCB,(void*)ptscprop[ref-1]))
			{
				return(1);
			}
		}
	}
	return(0);
}

/*
 * Register tcp Connected data callback function
 */
void TscRegisterCBConnected(uint16_t ref, void (*cb)(int fd, struct sockaddr* pRemoteAddr))
{
	if (ref && ref<=totalTscServer)
	{
		ptscprop[ref-1]->connectedcb=cb;
	}
}
/*
 * Register tcp received data callback function
 */
void TscRegisterCBRxData(uint16_t ref, void (*cb)(int fd, uint8_t *pData, uint16_t size))
{
	if (ref && ref<=totalTscServer)
	{
		ptscprop[ref-1]->rxcb=cb;
	}
}
/*
 * Register tcp disconnected callback function
 */
void TscRegisterCBDisconnected(uint16_t ref, void (*cb)(int fd))
{
	if (ref && ref<=totalTscServer)
	{
		ptscprop[ref-1]->closedcb=cb;
	}
}


/*
 * Send out data to the tcp connection
 * return false if unable to send
 */
uint16_t TscSendData(int fd, uint8_t *pData, uint16_t size)
{
	int tmp;
	//dbPrintText("TxFD:%d ",fd);
	//dbPrintByte(pData,size);
	//dbPrintNewLine();
	tmp=send(fd,pData,size,0);

	if (tmp<0)
	{
		// Connection is close do callback.
		TscCloseConnection(fd);
		return(0);
	}
	if (tmp!=size) {
		return(0);
	}

	return(1);
}
/*
 * broadcast data to all the tcp connection connected under the same reference
 */
void TscBroadcast(uint16_t ref, uint8_t *pData, uint16_t size)
{
	int c;
	int tmp;
	if (ref && ref<=totalTscServer)
	{
		tscprop_t *pTscProp=ptscprop[ref-1];
		for (c=0;c<pTscProp->maxfd;c++)
		{
			if ((pTscProp->fd)[c]>=0)
			{
				tmp=send((pTscProp->fd)[c],(void*)pData,size,0);
				if (tmp<0)
				{
					TscCloseConnection((pTscProp->fd)[c]);
				}
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/*
 * Return the connection ptr base on fd
 * return null if not found.
 */
tscprop_t* Tsc_GetConProp(int fd)
{
	int c,d;
	tscprop_t *pTscProp;
	for(d=0;d<totalTscServer;d++)
	{
		pTscProp=ptscprop[d];
		for (c=0;c<pTscProp->maxfd;c++)
		{
			if ((pTscProp->fd)[c]==fd){
				return(pTscProp);
			}
		}
	}
	return(0);
}
/*
 * Return true if FD found in this connection, else return -1
 */
uint16_t Tsc_CheckFD(tscprop_t *pTscProp, int fd)
{
	int c;
	for (c=0;c<pTscProp->maxfd;c++)
	{
		if ((pTscProp->fd)[c]==fd) return(1);
	}
	return(0);
}

/*
 * Insert FD into the connection, return true if success
 */
uint16_t Tsc_InsertFD(tscprop_t *pTscProp, int fd)
{
	int c;
	for (c=0;c<pTscProp->maxfd;c++)
	{
		if ((pTscProp->fd)[c]<0) {
			(pTscProp->fd)[c]=fd;
			return(1);
		}
	}
	return(0);
}

/*
 * Remove FD from the connection
 */
void Tsc_RemoveFD(int fd)
{
	int c,d;
	tscprop_t *pTscProp;
	for(d=0;d<totalTscServer;d++)
	{
		pTscProp=ptscprop[d];
		for (c=0;c<pTscProp->maxfd;c++)
		{
			if ((pTscProp->fd)[c]==fd){
				(pTscProp->fd)[c]=-1;
				return;
			}
		}
	}
	return;
}

/*
 * call to close the connection will trigger the connection close callback
 */
void TscCloseConnection(int fd)
{
	tscprop_t *pTscProp=Tsc_GetConProp(fd);
	if (pTscProp){
		if (pTscProp->closedcb)
		{
			(*pTscProp->closedcb)(fd);
		}
		Tsc_RemoveFD(fd);
	}
	PollMgr_Remove(fd);
	close(fd);
}
/*
 * Poll callback when Listen socket trigger
 */
void Tsc_ListsenCB(int fd, short int event, void *ptr)
{
	int newFd;
	char name[21];
	struct sockaddr remoteAddr;
	socklen_t socksize;
	tscprop_t *pTscProp=(tscprop_t*)ptr;
	do
	{
		//Accept each incoming connection.
		newFd= accept(fd, NULL, NULL);
		if (newFd < 0)
		{
			if (errno != EWOULDBLOCK)
			{
			  perror("  accept() failed");
			}
			break;
		}
		if (Tsc_InsertFD(pTscProp,newFd)) {
			//insert the new accepted connection in to the poll list
			sprintf(name,"Conn#%d,%d",pTscProp->listenFD,newFd);
			PollMgr_Insert(name,newFd,POLLIN,&Tsc_ConnectionCB,ptr);
			// do the connected callback
			if (pTscProp->connectedcb)
			{
				socksize=sizeof(struct sockaddr);
				getpeername(newFd, &remoteAddr,  &socksize);
				(*pTscProp->connectedcb)(newFd,&remoteAddr);
			}
		}
		else {
			close(newFd);
		}
	}while (newFd != -1);
}

/*
 * Poll callback when Connected socket trigger
 */
void Tsc_ConnectionCB(int fd, short int event, void *ptr)
{
	tscprop_t *pTscProp=(tscprop_t*)ptr;
	int rxSize;

	rxSize = recv(fd, tscRxBuffer,(TcpRxBuffsize), 0);
	if (rxSize < 0)
	{
		if (errno != EWOULDBLOCK)
		{
			// Connection is close do callback.
			TscCloseConnection(fd);
			Tsc_RemoveFD(fd);
			PollMgr_Remove(fd);
		}
		return;
	}
	else if(rxSize==0)
	{
		//connection is closed.
		TscCloseConnection(fd);
	}
	else
	{
		// Callback to byte receive function
		//dbPrintText("RxFD:%d ",fd);
		//dbPrintByte(tscRxBuffer,tmp);
		//dbPrintNewLine();
		if (pTscProp->rxcb) {
			(*pTscProp->rxcb)(fd,tscRxBuffer,(uint16_t)rxSize);
		}
	}

}
