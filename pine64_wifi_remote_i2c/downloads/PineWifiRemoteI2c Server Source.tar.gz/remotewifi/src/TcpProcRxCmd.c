/*
 * TcpProcRxCmd.c
 *
 *  Created on: Mar 12, 2016
 *      Author: khgoh
 */
#include "TcpProcRxCmd.h"
#include "TcpServerConn.h"
#include "tcpCommandList.h"
#include "TcpMgtRemoteClient.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "pktcreate.h"
#include <unistd.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include "dbprint.h"

/*
 * Convert code to Cmd,
 * declear in TcpSendcmd.c
 */
extern clientCmd_t CodetoCmd(uint8_t cmdcode);

void (*pCmdReturnCallback)(int consoleFD, uint16_t clientIndex,clientCmd_t cmd,clientRespond_t res, uint8_t size, uint8_t* pdata)=0;

#define DoRetCB(consoleFD, clientindex,cmd,res,size,pdata) do{\
	if (pCmdReturnCallback) (*pCmdReturnCallback)((consoleFD),(clientindex),(cmd),(res),(size),(pdata));\
}while(0)

/*
 * Register the device tcp cmd return callback.
 */
void RegTcpProcRxCmdCB(void (*cb)(int consoleFD, uint16_t clientIndex,clientCmd_t cmd,clientRespond_t res, uint8_t size, uint8_t* pdata))
{
	pCmdReturnCallback=cb;
}

/*
 * call to return command send/reply error
 */
void TcpReturnError(int consoleFD, uint16_t clientIndex, clientCmd_t cmd)
{
	DoRetCB(consoleFD,clientIndex,cmd,resNack,0,0);
	//if (!MgtClientIsbusyNow(MgtGetConsoleFD(clientIndex))) {
	//	DoRetCB(MgtGetConsoleFD(clientIndex),clientIndex,0,resDrvIdle,0,0);
	//}
}

/*
 * call to return command timeout
 */
void TcpReturnTimeOut(int consoleFD, uint16_t clientIndex, clientCmd_t cmd)
{
	DoRetCB(consoleFD,clientIndex,cmd,resTimeOut,0,0);
	if (!MgtClientIsbusyNow(MgtGetConsoleFD(clientIndex))) {
		DoRetCB(MgtGetConsoleFD(clientIndex),clientIndex,0,resDrvIdle,0,0);
	}
}

/*
 * Tcp Connected Callback
 */
void TcpConnectedCB(int fd,struct sockaddr* pRemoteAddr)
{

#ifdef DEBUGMODE
	struct sockaddr_in *paddr;
	dbPrintText("Client Connected fd %d ",fd);
	paddr=(struct sockaddr_in*)pRemoteAddr;
	dbPrintText("IP Addr %s",inet_ntoa(paddr->sin_addr));
	dbPrintNewLine();
#endif

}

#define TcpReturnResult(consoleFD,clientindex,cmd,res,datasize,pcmd) do{\
			if(pResult[0]==TCP_ACK){\
				DoRetCB((consoleFD),(clientindex),(cmd),(resAck),(datasize),&(pCmd)[1]);\
			}\
			else if (pResult[0]==TCP_ACKRT2) {\
				DoRetCB((consoleFD),(clientindex),(cmd),(resPush),(datasize),&(pCmd)[1]);\
			}\
			else {\
				TcpReturnError((consoleFD),(clientindex),(cmd));\
			}\
		}while(0)



/*
 * Tcp Data received callback
 */
void TcpDataRxCB(int fd, uint8_t *pData, uint16_t size)
{
	uint8_t *pResult;
	uint8_t *pCmd;
	uint8_t *pMac;
	uint16_t datasize;
	socklen_t socksize;
	int16_t clientindex=-1;
	uint8_t *pRSSI;
	struct sockaddr remoteAddr;
	struct sockaddr_in *paddr;
	remoteclient_t rclientinfo;
	uint8_t enumcmd;

#ifdef DEBUGMODE
	//struct sockaddr_in *ptraddr;
	//socksize=sizeof(remoteAddr);
	//getpeername(fd, &remoteAddr,  &socksize);
	//char *strIpAddr;
	//ptraddr=(struct sockaddr_in*)&remoteAddr;
	//strIpAddr=inet_ntoa(ptraddr->sin_addr);
#endif
	datasize=size;
	if (pktc_rxPecket(pData,&pMac,&pResult,&pCmd,&datasize,&pRSSI)){
		//search for remote client index by fd.
		//pCmd[0] is command pCmd[1].. is Data and total size is datasize
		if (pCmd[0]==Cmd02_HWINFO)
		{
			//need to create the client
			//dbPrintText("Rx: HWInfo FD:%d IP:%s",fd,strIpAddr);dbPrintNewLine();
			memcpy(rclientinfo.macaddr,pMac,6);
			memcpy(rclientinfo.fwID,&pCmd[1],2);
			memcpy(rclientinfo.fwVersion,&pCmd[3],4);
			rclientinfo.online=1;
			socksize=sizeof(remoteAddr);
			getpeername(fd, &remoteAddr,  &socksize);
			paddr=(struct sockaddr_in*)&remoteAddr;
			rclientinfo.ipaddr=paddr->sin_addr.s_addr;
			clientindex=MgtClientInsert(fd,&rclientinfo);
			MgtClientUpdRSSI(fd, (int8_t)(pRSSI[0])); //update the rssi info.
			DoRetCB(-1,clientindex,0,resClientOnline,0,0);
		}
		else {
			MgtClientUpdRSSI(fd, (int8_t)(pRSSI[0]));
			clientindex=MgtClientGetIndex(fd);
			if (clientindex==-1) return;

			if (pResult[0]!=TCP_ACKRT2) {
				MgtClrClientBusy(clientindex);
			}

			switch (pCmd[0])
			{
			case Cmd01_Nop:
				//this command do not need to pass to upper application
				//dbPrintText("Rx: NOP FD:%d IP:%s",fd,strIpAddr);dbPrintNewLine();
				MgtClearNopPending(clientindex);
				dbPrintText("Reply NOP received %d",clientindex);dbPrintNewLine();
				break;
			case Cmd03_HWSTATUS:
				break;
			default:
				if ((enumcmd=CodetoCmd(pCmd[0]))>0) {
					TcpReturnResult(MgtGetConsoleFD(clientindex),clientindex,enumcmd,pResult[0],datasize,pcmd+1);
				}
				break;
			}
		}
	}
	else {
		dbPrintText("CRC Error fd:%d,index:%d",fd,MgtClientGetIndex(fd));dbPrintNewLine();
	}

	if (clientindex>=0 && pCmd[0]!=Cmd01_Nop && pCmd[0]!=Cmd02_HWINFO) {
		if (!MgtClientIsbusyNow(MgtGetConsoleFD(clientindex))) {
			DoRetCB(MgtGetConsoleFD(clientindex),clientindex,0,resDrvIdle,0,0);
		}
	}
}
/*
 * Call to return client offline info
 */
void TcpSetClientOffline(uint16_t clientIndex)
{
	dbPrintText("Force Client Off-line, Doing TxReturnCallBack");dbPrintNewLine();
	TscCloseConnection(MgtClientGetFD(clientIndex));

}
/*
 * Tcp connection disconnected callback
 */
void TcpDisconnectedCB(int fd)
{
	uint16_t clientindex;
	clientindex=MgtClientGetIndex(fd);
	MgtClientOffline(clientindex);
	dbPrintText("Tcp disconnected FD=%d, Doing TxReturnCallBack",fd);dbPrintNewLine();
	DoRetCB(-1,clientindex,0,resClientOffline,0,0);


}
