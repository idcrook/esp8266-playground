/*
 * text.c
 *
 *  Created on: Jul 26, 2015
 *      Author: khgoh
 */
#include "text.h"
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

/*
 * return the pointer to attribute and pointer to data
 * the expected format are as,
 * 	attribute=data
 * It will strip the comment and space at the beginning and at the end.
 * Return true if found the command format.
 */
int GetAttribute(char *src,char **attribute, char **data)
{
	char *tmpsrc;
	int c;
	tmpsrc=CommStrip(src);
	if (strlen(tmpsrc)>0){
		*attribute=tmpsrc;
		for (c=0;c<strlen(tmpsrc);c++)
		{
			if (tmpsrc[c]=='=')
			{
				if (strlen(tmpsrc)>(c+1)) {
					(*data)=&tmpsrc[c+1];
					tmpsrc[c]=0;
					(*attribute)=strstrip(*attribute);
					(*data)=strstrip(*data);
					return(1);
				}
			}
		}
	}
	return(0);
}
/*
 * Strip Comment from the given line
 */
char *CommStrip(char *s)
{
	char *ptmp;
	int c;
	if (strlen(s)>0) {
		ptmp=strstrip(s);
		if (strlen(ptmp)) {
			for (c=0;c<strlen(ptmp);c++)
			{
				if (ptmp[c]=='#' || ptmp[c]=='\n' || ptmp[c]=='\r') {
					ptmp[c]='\0';
					break;
				}
			}
		}
		return(ptmp);
	}
	return(s);
}

/*
 * remove beginig and ending space from a string.
 */
char *strstrip(char *s)
{
    size_t size;
    char *end;

    size = strlen(s);

    if (!size)
    	return s;

    end = s + size - 1;
    while (end >= s && isspace(*end))
    	end--;
    *(end + 1) = '\0';

    while (*s && isspace(*s))
    	s++;

    return s;
}

/*
 *Convert the string to upper case.
 */
char *strtoupper(char *s)
{
	int c;
	for (c=0;c<strlen(s);c++)
	{
		s[c]=toupper(s[c]);
	}
	return(s);
}

/*
 * Convert to upper case before compare.
 */
int strcmp_upper(char *s1,char *s2)
{
	char *tmps1,*tmps2;
	int result;
	tmps1=(char*)malloc(strlen(s1)+1);
	if (tmps1) {
		tmps2=(char*)malloc(strlen(s2)+1);
		if (tmps2) {
			strcpy(tmps1,s1);
			strcpy(tmps2,s2);
			result=strcmp(tmps1,tmps2);
			free(tmps1);free(tmps2);
			return(result);
		}
		free(tmps1);
	}
	return(-1);
}
