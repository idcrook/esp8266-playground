/*
 * PollMgr.c
 *
 *  Created on: Jul 9, 2015
 *      Author: khgoh
 */

#include "PollMgr.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <string.h>

//total number of fd allow for polling
#ifndef POLL_SIZE
#define POLL_SIZE 1000
#endif

//time to sleep/wait during the poll command
#ifndef PollSleep_ms
#define PollSleep_ms 10	//time to sleep on each block.
#endif

typedef struct{
	char used; //true if currently used
	char name[21];
	int fd;
	short int event;
	void (*cb)(int fd,short int event,void*ptr);
	void *ptr;
}pollcb_t;

//poll set and number of registered poll fd
struct pollfd poll_set[POLL_SIZE];
int poll_set_total=0;

//keep the index of pollcb_t with the variable index match to poll_set index
//with the poll_set_index, we can direct get the index of structure pollcb_t.
int pollcbMatchIndex[POLL_SIZE];

//keep the cb info for each fd.
pollcb_t pollcb[POLL_SIZE];



/*
 * Internal function refresh the poll_set list.
 */
void PollMgr_UpdatePollList(void)
{
	int c;
	poll_set_total=0;
	for (c=0;c<POLL_SIZE;c++)
	{
		if (pollcb[c].used)
		{
			poll_set[poll_set_total].fd=pollcb[c].fd;
			poll_set[poll_set_total].events=pollcb[c].event;
			pollcbMatchIndex[poll_set_total]=c; //keep the pollcb index into the array.
			poll_set_total++;
		}
	}
}

/*
 * call to insert a fd for poll sequence
 * name of the fd max char is 20char+1null.
 * if name is null, it will fill in with the fd.
 */
int PollMgr_Insert(char *name,int fd, short int event, void (*cb)(int,short int,void*),void *ptr)
{
	int c;
	for (c=0;c<POLL_SIZE;c++)
	{
		//loop through the array to find a blank space.
		if (!pollcb[c].used) {
			pollcb[c].used=1;
			pollcb[c].fd=fd;
			pollcb[c].event=event;
			pollcb[c].cb=cb;
			pollcb[c].ptr=ptr;
			if (name!=NULL)
			{
				if (strlen(name)>=20){
					memcpy(pollcb[c].name,name,20);
					pollcb[c].name[20]=0;
				}
				else {
					strcpy(pollcb[c].name,name);
				}
			}
			else {
				sprintf(pollcb[c].name,"FD%d",fd);
			}
			PollMgr_UpdatePollList();
			return(1);
		}
	}
	return(0);
}

/*
 * remove the poll fd from the list
 */
void PollMgr_Remove(int fd)
{
	int c;
	for (c=0;c<POLL_SIZE;c++)
	{
		if (pollcb[c].used && pollcb[c].fd==fd) {
			pollcb[c].used=0;
			PollMgr_UpdatePollList();
			break;
		}
	}
}

/*
 * Call from Main program loop routine.
 * Each call will cause the system to sleep for PollSleep_ms
 */
void PollMgr_Refresh(void)
{
	struct pollfd localPollSet[POLL_SIZE];
	int localTotalSet=poll_set_total;
	int localpollcbMatchIndex[POLL_SIZE];

	int pollresult;
	int c;

	if (localTotalSet)
	{
		//make a local copy of the poll set to use as current working copy
		//This will allow the callback to insert/remove the fd without
		//effecting the current working copy.
		memcpy(localPollSet,poll_set,sizeof(struct pollfd)*localTotalSet);
		memcpy(localpollcbMatchIndex,pollcbMatchIndex,sizeof(int)*localTotalSet);

		pollresult=poll(localPollSet,localTotalSet,PollSleep_ms); //will block to PollSleep_ms
		if (pollresult>0)
		{
			for (c=0;c<localTotalSet;c++)
			{
				if (localPollSet[c].revents & pollcb[localpollcbMatchIndex[c]].event)
				{
					if (pollcb[localpollcbMatchIndex[c]].used && pollcb[localpollcbMatchIndex[c]].cb)
					{
						//this event got trigger, need to do the event callback.
						(*pollcb[localpollcbMatchIndex[c]].cb)
									(localPollSet[c].fd,localPollSet[c].revents,pollcb[localpollcbMatchIndex[c]].ptr);
					}
				}
			}
		}
	}
	else {
		//sleep for while since no fd to poll
		usleep(PollSleep_ms*1000);
	}
}
