Programming Firmware Address Setting
-------------------------------------
blank8k.bin ADDR: 0x3E000
RemoteIOxxxxxx01.flash.bin, ADDR: 0x0000
RemoteIOxxxxxx01.irom0text.bin, ADDR: 0x40000 

Default Wifi AP after programming
SSID: wifitesting
Password: 123456789